<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE eagle SYSTEM "eagle.dtd">
<eagle version="9.3.2">
<drawing>
<settings>
<setting alwaysvectorfont="no"/>
<setting verticaltext="up"/>
</settings>
<grid distance="0.1" unitdist="inch" unit="inch" style="lines" multiple="1" display="no" altdistance="0.01" altunitdist="inch" altunit="inch"/>
<layers>
<layer number="1" name="Top" color="4" fill="1" visible="no" active="no"/>
<layer number="2" name="Route2" color="1" fill="3" visible="no" active="no"/>
<layer number="3" name="Route3" color="4" fill="3" visible="no" active="no"/>
<layer number="4" name="Route4" color="1" fill="4" visible="no" active="no"/>
<layer number="5" name="Route5" color="4" fill="4" visible="no" active="no"/>
<layer number="6" name="Route6" color="1" fill="8" visible="no" active="no"/>
<layer number="7" name="Route7" color="4" fill="8" visible="no" active="no"/>
<layer number="8" name="Route8" color="1" fill="2" visible="no" active="no"/>
<layer number="9" name="Route9" color="4" fill="2" visible="no" active="no"/>
<layer number="10" name="Route10" color="1" fill="7" visible="no" active="no"/>
<layer number="11" name="Route11" color="4" fill="7" visible="no" active="no"/>
<layer number="12" name="Route12" color="1" fill="5" visible="no" active="no"/>
<layer number="13" name="Route13" color="4" fill="5" visible="no" active="no"/>
<layer number="14" name="Route14" color="1" fill="6" visible="no" active="no"/>
<layer number="15" name="Route15" color="4" fill="6" visible="no" active="no"/>
<layer number="16" name="Bottom" color="1" fill="1" visible="no" active="no"/>
<layer number="17" name="Pads" color="2" fill="1" visible="no" active="no"/>
<layer number="18" name="Vias" color="2" fill="1" visible="no" active="no"/>
<layer number="19" name="Unrouted" color="6" fill="1" visible="no" active="no"/>
<layer number="20" name="Dimension" color="15" fill="1" visible="no" active="no"/>
<layer number="21" name="tPlace" color="7" fill="1" visible="no" active="no"/>
<layer number="22" name="bPlace" color="7" fill="1" visible="no" active="no"/>
<layer number="23" name="tOrigins" color="15" fill="1" visible="no" active="no"/>
<layer number="24" name="bOrigins" color="15" fill="1" visible="no" active="no"/>
<layer number="25" name="tNames" color="7" fill="1" visible="no" active="no"/>
<layer number="26" name="bNames" color="7" fill="1" visible="no" active="no"/>
<layer number="27" name="tValues" color="7" fill="1" visible="no" active="no"/>
<layer number="28" name="bValues" color="7" fill="1" visible="no" active="no"/>
<layer number="29" name="tStop" color="7" fill="3" visible="no" active="no"/>
<layer number="30" name="bStop" color="7" fill="6" visible="no" active="no"/>
<layer number="31" name="tCream" color="7" fill="4" visible="no" active="no"/>
<layer number="32" name="bCream" color="7" fill="5" visible="no" active="no"/>
<layer number="33" name="tFinish" color="6" fill="3" visible="no" active="no"/>
<layer number="34" name="bFinish" color="6" fill="6" visible="no" active="no"/>
<layer number="35" name="tGlue" color="7" fill="4" visible="no" active="no"/>
<layer number="36" name="bGlue" color="7" fill="5" visible="no" active="no"/>
<layer number="37" name="tTest" color="7" fill="1" visible="no" active="no"/>
<layer number="38" name="bTest" color="7" fill="1" visible="no" active="no"/>
<layer number="39" name="tKeepout" color="4" fill="11" visible="no" active="no"/>
<layer number="40" name="bKeepout" color="1" fill="11" visible="no" active="no"/>
<layer number="41" name="tRestrict" color="4" fill="10" visible="no" active="no"/>
<layer number="42" name="bRestrict" color="1" fill="10" visible="no" active="no"/>
<layer number="43" name="vRestrict" color="2" fill="10" visible="no" active="no"/>
<layer number="44" name="Drills" color="7" fill="1" visible="no" active="no"/>
<layer number="45" name="Holes" color="7" fill="1" visible="no" active="no"/>
<layer number="46" name="Milling" color="3" fill="1" visible="no" active="no"/>
<layer number="47" name="Measures" color="7" fill="1" visible="no" active="no"/>
<layer number="48" name="Document" color="7" fill="1" visible="no" active="no"/>
<layer number="49" name="Reference" color="7" fill="1" visible="no" active="no"/>
<layer number="50" name="dxf" color="7" fill="1" visible="no" active="no"/>
<layer number="51" name="tDocu" color="7" fill="1" visible="no" active="no"/>
<layer number="52" name="bDocu" color="7" fill="1" visible="no" active="no"/>
<layer number="53" name="tGND_GNDA" color="7" fill="9" visible="no" active="no"/>
<layer number="54" name="bGND_GNDA" color="1" fill="9" visible="no" active="no"/>
<layer number="56" name="wert" color="7" fill="1" visible="no" active="no"/>
<layer number="57" name="tCAD" color="7" fill="1" visible="no" active="no"/>
<layer number="58" name="bCopper" color="7" fill="1" visible="no" active="no"/>
<layer number="59" name="tCarbon" color="7" fill="1" visible="no" active="no"/>
<layer number="60" name="bCarbon" color="7" fill="1" visible="no" active="no"/>
<layer number="88" name="SimResults" color="9" fill="1" visible="yes" active="yes"/>
<layer number="89" name="SimProbes" color="9" fill="1" visible="yes" active="yes"/>
<layer number="90" name="Modules" color="5" fill="1" visible="yes" active="yes"/>
<layer number="91" name="Nets" color="2" fill="1" visible="yes" active="yes"/>
<layer number="92" name="Busses" color="1" fill="1" visible="yes" active="yes"/>
<layer number="93" name="Pins" color="2" fill="1" visible="no" active="yes"/>
<layer number="94" name="Symbols" color="4" fill="1" visible="yes" active="yes"/>
<layer number="95" name="Names" color="7" fill="1" visible="yes" active="yes"/>
<layer number="96" name="Values" color="7" fill="1" visible="yes" active="yes"/>
<layer number="97" name="Info" color="7" fill="1" visible="yes" active="yes"/>
<layer number="98" name="Guide" color="6" fill="1" visible="yes" active="yes"/>
<layer number="99" name="SpiceOrder" color="7" fill="1" visible="no" active="no"/>
<layer number="100" name="Muster" color="7" fill="1" visible="no" active="no"/>
<layer number="101" name="Patch_Top" color="12" fill="4" visible="no" active="no"/>
<layer number="102" name="Vscore" color="7" fill="1" visible="no" active="no"/>
<layer number="103" name="tMap" color="7" fill="1" visible="no" active="no"/>
<layer number="104" name="Name" color="16" fill="1" visible="no" active="no"/>
<layer number="105" name="tPlate" color="7" fill="1" visible="no" active="no"/>
<layer number="106" name="bPlate" color="7" fill="1" visible="no" active="no"/>
<layer number="107" name="Crop" color="7" fill="1" visible="no" active="no"/>
<layer number="108" name="tplace-old" color="10" fill="1" visible="no" active="no"/>
<layer number="109" name="ref-old" color="11" fill="1" visible="no" active="no"/>
<layer number="110" name="fp0" color="7" fill="1" visible="no" active="no"/>
<layer number="111" name="LPC17xx" color="7" fill="1" visible="no" active="no"/>
<layer number="112" name="tSilk" color="7" fill="1" visible="no" active="no"/>
<layer number="113" name="IDFDebug" color="4" fill="1" visible="no" active="no"/>
<layer number="114" name="Badge_Outline" color="7" fill="1" visible="no" active="no"/>
<layer number="115" name="ReferenceISLANDS" color="7" fill="1" visible="no" active="no"/>
<layer number="116" name="Patch_BOT" color="9" fill="4" visible="no" active="no"/>
<layer number="117" name="PM_Ref" color="7" fill="1" visible="no" active="no"/>
<layer number="118" name="Rect_Pads" color="7" fill="1" visible="no" active="no"/>
<layer number="119" name="PF_Ref" color="7" fill="1" visible="no" active="no"/>
<layer number="120" name="WFL_Ref" color="7" fill="1" visible="no" active="no"/>
<layer number="121" name="_tsilk" color="7" fill="1" visible="no" active="no"/>
<layer number="122" name="_bsilk" color="7" fill="1" visible="no" active="no"/>
<layer number="123" name="tTestmark" color="7" fill="1" visible="no" active="no"/>
<layer number="124" name="bTestmark" color="7" fill="1" visible="no" active="no"/>
<layer number="125" name="_tNames" color="7" fill="1" visible="no" active="no"/>
<layer number="126" name="_bNames" color="7" fill="1" visible="no" active="no"/>
<layer number="127" name="_tValues" color="7" fill="1" visible="no" active="no"/>
<layer number="128" name="_bValues" color="7" fill="1" visible="no" active="no"/>
<layer number="129" name="Mask" color="7" fill="1" visible="no" active="no"/>
<layer number="130" name="SMDSTROOK" color="7" fill="1" visible="no" active="no"/>
<layer number="131" name="tAdjust" color="7" fill="1" visible="no" active="no"/>
<layer number="132" name="bAdjust" color="7" fill="1" visible="no" active="no"/>
<layer number="133" name="bottom_silk" color="7" fill="1" visible="no" active="no"/>
<layer number="134" name="silk_top" color="7" fill="1" visible="no" active="no"/>
<layer number="135" name="silk_bottom" color="7" fill="1" visible="no" active="no"/>
<layer number="136" name="silktop" color="7" fill="1" visible="no" active="no"/>
<layer number="137" name="silkbottom" color="7" fill="1" visible="no" active="no"/>
<layer number="138" name="EEE" color="7" fill="1" visible="no" active="no"/>
<layer number="139" name="_tKeepout" color="7" fill="1" visible="no" active="no"/>
<layer number="140" name="mbKeepout" color="7" fill="1" visible="no" active="no"/>
<layer number="141" name="ASSEMBLY_TOP" color="7" fill="1" visible="no" active="no"/>
<layer number="142" name="mbRestrict" color="7" fill="1" visible="no" active="no"/>
<layer number="143" name="PLACE_BOUND_TOP" color="7" fill="1" visible="no" active="no"/>
<layer number="144" name="Drill_legend" color="7" fill="1" visible="no" active="no"/>
<layer number="145" name="DrillLegend_01-02" color="7" fill="1" visible="no" active="no"/>
<layer number="146" name="DrillLegend_01-15" color="7" fill="1" visible="no" active="no"/>
<layer number="147" name="DrillLegend_01-16" color="7" fill="1" visible="no" active="no"/>
<layer number="148" name="DrillLegend_01-20" color="7" fill="1" visible="no" active="no"/>
<layer number="149" name="DrillLegend_02-15" color="7" fill="1" visible="no" active="no"/>
<layer number="150" name="Notes" color="7" fill="1" visible="no" active="no"/>
<layer number="151" name="HeatSink" color="7" fill="1" visible="no" active="no"/>
<layer number="152" name="_bDocu" color="7" fill="1" visible="no" active="no"/>
<layer number="153" name="FabDoc1" color="7" fill="1" visible="no" active="no"/>
<layer number="154" name="FabDoc2" color="7" fill="1" visible="no" active="no"/>
<layer number="155" name="FabDoc3" color="7" fill="1" visible="no" active="no"/>
<layer number="156" name="gesam-Maß" color="1" fill="7" visible="no" active="no"/>
<layer number="157" name="FaceMchng" color="3" fill="1" visible="no" active="no"/>
<layer number="158" name="FaceMMeas" color="3" fill="1" visible="no" active="no"/>
<layer number="159" name="Geh-Bear2" color="1" fill="7" visible="no" active="no"/>
<layer number="160" name="Topologie" color="9" fill="1" visible="no" active="no"/>
<layer number="161" name="tomplace2" color="7" fill="1" visible="no" active="no"/>
<layer number="166" name="AntennaArea" color="7" fill="1" visible="no" active="no"/>
<layer number="168" name="4mmHeightArea" color="7" fill="1" visible="no" active="no"/>
<layer number="191" name="mNets" color="7" fill="1" visible="no" active="no"/>
<layer number="192" name="mBusses" color="7" fill="1" visible="no" active="no"/>
<layer number="193" name="mPins" color="7" fill="1" visible="no" active="no"/>
<layer number="194" name="mSymbols" color="7" fill="1" visible="no" active="no"/>
<layer number="195" name="mNames" color="7" fill="1" visible="no" active="no"/>
<layer number="196" name="mValues" color="7" fill="1" visible="no" active="no"/>
<layer number="199" name="Contour" color="7" fill="1" visible="no" active="no"/>
<layer number="200" name="200bmp" color="1" fill="10" visible="no" active="no"/>
<layer number="201" name="201bmp" color="2" fill="10" visible="no" active="no"/>
<layer number="202" name="202bmp" color="3" fill="10" visible="no" active="no"/>
<layer number="203" name="203bmp" color="4" fill="10" visible="no" active="no"/>
<layer number="204" name="204bmp" color="5" fill="10" visible="no" active="no"/>
<layer number="205" name="205bmp" color="6" fill="10" visible="no" active="no"/>
<layer number="206" name="206bmp" color="7" fill="10" visible="no" active="no"/>
<layer number="207" name="207bmp" color="8" fill="10" visible="no" active="no"/>
<layer number="208" name="208bmp" color="9" fill="10" visible="no" active="no"/>
<layer number="209" name="209bmp" color="7" fill="1" visible="no" active="no"/>
<layer number="210" name="210bmp" color="7" fill="1" visible="no" active="no"/>
<layer number="211" name="211bmp" color="7" fill="1" visible="no" active="no"/>
<layer number="212" name="212bmp" color="7" fill="1" visible="no" active="no"/>
<layer number="213" name="213bmp" color="7" fill="1" visible="no" active="no"/>
<layer number="214" name="214bmp" color="7" fill="1" visible="no" active="no"/>
<layer number="215" name="215bmp" color="7" fill="1" visible="no" active="no"/>
<layer number="216" name="216bmp" color="7" fill="1" visible="no" active="no"/>
<layer number="217" name="217bmp" color="18" fill="1" visible="no" active="no"/>
<layer number="218" name="218bmp" color="19" fill="1" visible="no" active="no"/>
<layer number="219" name="219bmp" color="20" fill="1" visible="no" active="no"/>
<layer number="220" name="220bmp" color="21" fill="1" visible="no" active="no"/>
<layer number="221" name="221bmp" color="22" fill="1" visible="no" active="no"/>
<layer number="222" name="222bmp" color="23" fill="1" visible="no" active="no"/>
<layer number="223" name="223bmp" color="24" fill="1" visible="no" active="no"/>
<layer number="224" name="224bmp" color="25" fill="1" visible="no" active="no"/>
<layer number="225" name="225bmp" color="7" fill="1" visible="no" active="no"/>
<layer number="226" name="226bmp" color="7" fill="1" visible="no" active="no"/>
<layer number="227" name="227bmp" color="11" fill="1" visible="no" active="no"/>
<layer number="228" name="228bmp" color="10" fill="1" visible="no" active="no"/>
<layer number="229" name="229bmp" color="14" fill="1" visible="no" active="no"/>
<layer number="230" name="230bmp" color="12" fill="1" visible="no" active="no"/>
<layer number="231" name="231bmp" color="9" fill="1" visible="no" active="no"/>
<layer number="232" name="Eagle3D_PG2" color="7" fill="1" visible="no" active="no"/>
<layer number="233" name="Eagle3D_PG3" color="7" fill="1" visible="no" active="no"/>
<layer number="248" name="Housing" color="7" fill="1" visible="no" active="no"/>
<layer number="249" name="Edge" color="7" fill="1" visible="no" active="no"/>
<layer number="250" name="Descript" color="3" fill="1" visible="no" active="no"/>
<layer number="251" name="SMDround" color="12" fill="11" visible="no" active="no"/>
<layer number="252" name="BR-BS" color="7" fill="1" visible="no" active="no"/>
<layer number="253" name="Extra" color="7" fill="1" visible="no" active="no"/>
<layer number="254" name="cooling" color="7" fill="1" visible="no" active="no"/>
<layer number="255" name="routoute" color="7" fill="1" visible="no" active="no"/>
</layers>
<schematic xreflabel="%F%N/%S.%C%R" xrefpart="/%S.%C%R">
<libraries>
<library name="SamacSys_Parts">
<description>&lt;b&gt;https://componentsearchengine.com&lt;/b&gt;&lt;p&gt;
&lt;author&gt;Created by SamacSys&lt;/author&gt;</description>
<packages>
<package name="QFP50P1600X1600X160-100N">
<description>&lt;b&gt;LQFP100 14x 14&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-7.738" y="6" dx="1.475" dy="0.3" layer="1"/>
<smd name="2" x="-7.738" y="5.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="3" x="-7.738" y="5" dx="1.475" dy="0.3" layer="1"/>
<smd name="4" x="-7.738" y="4.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="5" x="-7.738" y="4" dx="1.475" dy="0.3" layer="1"/>
<smd name="6" x="-7.738" y="3.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="7" x="-7.738" y="3" dx="1.475" dy="0.3" layer="1"/>
<smd name="8" x="-7.738" y="2.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="9" x="-7.738" y="2" dx="1.475" dy="0.3" layer="1"/>
<smd name="10" x="-7.738" y="1.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="11" x="-7.738" y="1" dx="1.475" dy="0.3" layer="1"/>
<smd name="12" x="-7.738" y="0.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="13" x="-7.738" y="0" dx="1.475" dy="0.3" layer="1"/>
<smd name="14" x="-7.738" y="-0.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="15" x="-7.738" y="-1" dx="1.475" dy="0.3" layer="1"/>
<smd name="16" x="-7.738" y="-1.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="17" x="-7.738" y="-2" dx="1.475" dy="0.3" layer="1"/>
<smd name="18" x="-7.738" y="-2.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="19" x="-7.738" y="-3" dx="1.475" dy="0.3" layer="1"/>
<smd name="20" x="-7.738" y="-3.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="21" x="-7.738" y="-4" dx="1.475" dy="0.3" layer="1"/>
<smd name="22" x="-7.738" y="-4.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="23" x="-7.738" y="-5" dx="1.475" dy="0.3" layer="1"/>
<smd name="24" x="-7.738" y="-5.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="25" x="-7.738" y="-6" dx="1.475" dy="0.3" layer="1"/>
<smd name="26" x="-6" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="27" x="-5.5" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="28" x="-5" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="29" x="-4.5" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="30" x="-4" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="31" x="-3.5" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="32" x="-3" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="33" x="-2.5" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="34" x="-2" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="35" x="-1.5" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="36" x="-1" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="37" x="-0.5" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="38" x="0" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="39" x="0.5" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="40" x="1" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="41" x="1.5" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="42" x="2" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="43" x="2.5" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="44" x="3" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="45" x="3.5" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="46" x="4" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="47" x="4.5" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="48" x="5" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="49" x="5.5" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="50" x="6" y="-7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="51" x="7.738" y="-6" dx="1.475" dy="0.3" layer="1"/>
<smd name="52" x="7.738" y="-5.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="53" x="7.738" y="-5" dx="1.475" dy="0.3" layer="1"/>
<smd name="54" x="7.738" y="-4.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="55" x="7.738" y="-4" dx="1.475" dy="0.3" layer="1"/>
<smd name="56" x="7.738" y="-3.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="57" x="7.738" y="-3" dx="1.475" dy="0.3" layer="1"/>
<smd name="58" x="7.738" y="-2.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="59" x="7.738" y="-2" dx="1.475" dy="0.3" layer="1"/>
<smd name="60" x="7.738" y="-1.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="61" x="7.738" y="-1" dx="1.475" dy="0.3" layer="1"/>
<smd name="62" x="7.738" y="-0.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="63" x="7.738" y="0" dx="1.475" dy="0.3" layer="1"/>
<smd name="64" x="7.738" y="0.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="65" x="7.738" y="1" dx="1.475" dy="0.3" layer="1"/>
<smd name="66" x="7.738" y="1.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="67" x="7.738" y="2" dx="1.475" dy="0.3" layer="1"/>
<smd name="68" x="7.738" y="2.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="69" x="7.738" y="3" dx="1.475" dy="0.3" layer="1"/>
<smd name="70" x="7.738" y="3.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="71" x="7.738" y="4" dx="1.475" dy="0.3" layer="1"/>
<smd name="72" x="7.738" y="4.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="73" x="7.738" y="5" dx="1.475" dy="0.3" layer="1"/>
<smd name="74" x="7.738" y="5.5" dx="1.475" dy="0.3" layer="1"/>
<smd name="75" x="7.738" y="6" dx="1.475" dy="0.3" layer="1"/>
<smd name="76" x="6" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="77" x="5.5" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="78" x="5" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="79" x="4.5" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="80" x="4" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="81" x="3.5" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="82" x="3" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="83" x="2.5" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="84" x="2" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="85" x="1.5" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="86" x="1" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="87" x="0.5" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="88" x="0" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="89" x="-0.5" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="90" x="-1" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="91" x="-1.5" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="92" x="-2" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="93" x="-2.5" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="94" x="-3" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="95" x="-3.5" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="96" x="-4" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="97" x="-4.5" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="98" x="-5" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="99" x="-5.5" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<smd name="100" x="-6" y="7.738" dx="1.475" dy="0.3" layer="1" rot="R90"/>
<text x="0" y="0" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="0" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-8.725" y1="8.725" x2="8.725" y2="8.725" width="0.05" layer="51"/>
<wire x1="8.725" y1="8.725" x2="8.725" y2="-8.725" width="0.05" layer="51"/>
<wire x1="8.725" y1="-8.725" x2="-8.725" y2="-8.725" width="0.05" layer="51"/>
<wire x1="-8.725" y1="-8.725" x2="-8.725" y2="8.725" width="0.05" layer="51"/>
<wire x1="-7" y1="7" x2="7" y2="7" width="0.1" layer="51"/>
<wire x1="7" y1="7" x2="7" y2="-7" width="0.1" layer="51"/>
<wire x1="7" y1="-7" x2="-7" y2="-7" width="0.1" layer="51"/>
<wire x1="-7" y1="-7" x2="-7" y2="7" width="0.1" layer="51"/>
<wire x1="-7" y1="6.5" x2="-6.5" y2="7" width="0.1" layer="51"/>
<wire x1="-6.65" y1="6.65" x2="6.65" y2="6.65" width="0.2" layer="21"/>
<wire x1="6.65" y1="6.65" x2="6.65" y2="-6.65" width="0.2" layer="21"/>
<wire x1="6.65" y1="-6.65" x2="-6.65" y2="-6.65" width="0.2" layer="21"/>
<wire x1="-6.65" y1="-6.65" x2="-6.65" y2="6.65" width="0.2" layer="21"/>
<circle x="-8.225" y="6.75" radius="0.125" width="0.25" layer="25"/>
</package>
<package name="SOT95P237X112-3N">
<description>&lt;b&gt;SOT95P237X112-3N&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-0.9398" y="-1.0414" dx="1.27" dy="0.5588" layer="1" rot="R90"/>
<smd name="2" x="0.9398" y="-1.0414" dx="1.27" dy="0.5588" layer="1" rot="R90"/>
<smd name="3" x="0" y="1.0414" dx="1.27" dy="0.5588" layer="1" rot="R90"/>
<text x="-4.5212" y="2.159" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="-5.461" y="-4.2418" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-0.6858" y1="-0.7112" x2="-1.1938" y2="-0.7112" width="0.1524" layer="51"/>
<wire x1="-1.1938" y1="-0.7112" x2="-1.1938" y2="-1.3208" width="0.1524" layer="51"/>
<wire x1="-1.1938" y1="-1.3208" x2="-0.6858" y2="-1.3208" width="0.1524" layer="51"/>
<wire x1="-0.6858" y1="-1.3208" x2="-0.6858" y2="-0.7112" width="0.1524" layer="51"/>
<wire x1="1.1938" y1="-0.7112" x2="0.6858" y2="-0.7112" width="0.1524" layer="51"/>
<wire x1="0.6858" y1="-0.7112" x2="0.6858" y2="-1.3208" width="0.1524" layer="51"/>
<wire x1="0.6858" y1="-1.3208" x2="1.1938" y2="-1.3208" width="0.1524" layer="51"/>
<wire x1="1.1938" y1="-1.3208" x2="1.1938" y2="-0.7112" width="0.1524" layer="51"/>
<wire x1="-0.254" y1="0.7112" x2="0.254" y2="0.7112" width="0.1524" layer="51"/>
<wire x1="0.254" y1="0.7112" x2="0.254" y2="1.3208" width="0.1524" layer="51"/>
<wire x1="0.254" y1="1.3208" x2="-0.254" y2="1.3208" width="0.1524" layer="51"/>
<wire x1="-0.254" y1="1.3208" x2="-0.254" y2="0.7112" width="0.1524" layer="51"/>
<wire x1="-1.524" y1="-0.7112" x2="1.524" y2="-0.7112" width="0.1524" layer="51"/>
<wire x1="1.524" y1="-0.7112" x2="1.524" y2="0.7112" width="0.1524" layer="51"/>
<wire x1="1.524" y1="0.7112" x2="-1.524" y2="0.7112" width="0.1524" layer="51"/>
<wire x1="-1.524" y1="0.7112" x2="-1.524" y2="-0.7112" width="0.1524" layer="51"/>
<wire x1="-0.6096" y1="0.7112" x2="-1.524" y2="0.7112" width="0.1524" layer="21"/>
<wire x1="-0.3302" y1="-0.7112" x2="0.3302" y2="-0.7112" width="0.1524" layer="21"/>
<wire x1="1.524" y1="-0.254" x2="1.524" y2="0.7112" width="0.1524" layer="21"/>
<wire x1="1.524" y1="0.7112" x2="0.6096" y2="0.7112" width="0.1524" layer="21"/>
<wire x1="-1.524" y1="0.7112" x2="-1.524" y2="-0.254" width="0.1524" layer="21"/>
</package>
<package name="RESC3216X74N">
<description>&lt;b&gt;CRMA1206&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-1.45" y="0" dx="1.8" dy="1.15" layer="1" rot="R90"/>
<smd name="2" x="1.45" y="0" dx="1.8" dy="1.15" layer="1" rot="R90"/>
<text x="0" y="0" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="0" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-2.275" y1="1.15" x2="2.275" y2="1.15" width="0.05" layer="51"/>
<wire x1="2.275" y1="1.15" x2="2.275" y2="-1.15" width="0.05" layer="51"/>
<wire x1="2.275" y1="-1.15" x2="-2.275" y2="-1.15" width="0.05" layer="51"/>
<wire x1="-2.275" y1="-1.15" x2="-2.275" y2="1.15" width="0.05" layer="51"/>
<wire x1="-1.59" y1="0.8" x2="1.59" y2="0.8" width="0.1" layer="51"/>
<wire x1="1.59" y1="0.8" x2="1.59" y2="-0.8" width="0.1" layer="51"/>
<wire x1="1.59" y1="-0.8" x2="-1.59" y2="-0.8" width="0.1" layer="51"/>
<wire x1="-1.59" y1="-0.8" x2="-1.59" y2="0.8" width="0.1" layer="51"/>
<wire x1="0" y1="0.7" x2="0" y2="-0.7" width="0.2" layer="21"/>
</package>
<package name="4TPE220MBB">
<description>&lt;b&gt;4TPE220MBB&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-1.5" y="0" dx="2.7" dy="1.6" layer="1" rot="R90"/>
<smd name="2" x="1.5" y="0" dx="2.7" dy="1.6" layer="1" rot="R90"/>
<text x="0" y="0" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="0" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-1.75" y1="-1.4" x2="1.75" y2="-1.4" width="0.1" layer="51"/>
<wire x1="1.75" y1="-1.4" x2="1.75" y2="1.4" width="0.1" layer="51"/>
<wire x1="1.75" y1="1.4" x2="-1.75" y2="1.4" width="0.1" layer="51"/>
<wire x1="-1.75" y1="1.4" x2="-1.75" y2="-1.4" width="0.1" layer="51"/>
<wire x1="-3.3" y1="2.4" x2="3.3" y2="2.4" width="0.1" layer="51"/>
<wire x1="3.3" y1="2.4" x2="3.3" y2="-2.4" width="0.1" layer="51"/>
<wire x1="3.3" y1="-2.4" x2="-3.3" y2="-2.4" width="0.1" layer="51"/>
<wire x1="-3.3" y1="-2.4" x2="-3.3" y2="2.4" width="0.1" layer="51"/>
<wire x1="-0.3" y1="1.4" x2="0.3" y2="1.4" width="0.2" layer="21"/>
<wire x1="-0.3" y1="-1.4" x2="0.3" y2="-1.4" width="0.2" layer="21"/>
<wire x1="-2.8" y1="0" x2="-2.8" y2="0" width="0.2" layer="21"/>
<wire x1="-2.8" y1="0" x2="-2.7" y2="0" width="0.2" layer="21" curve="180"/>
<wire x1="-2.7" y1="0" x2="-2.7" y2="0" width="0.2" layer="21"/>
<wire x1="-2.7" y1="0" x2="-2.8" y2="0" width="0.2" layer="21" curve="180"/>
<wire x1="-2.8" y1="0" x2="-2.8" y2="0" width="0.2" layer="21"/>
<wire x1="-2.8" y1="0" x2="-2.7" y2="0" width="0.2" layer="21" curve="180"/>
</package>
<package name="QFN40P300X300X105-25N">
<description>&lt;b&gt;24 Lead QFN 3.0x3.0x0.9&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-1.5" y="1" dx="0.75" dy="0.2" layer="1"/>
<smd name="2" x="-1.5" y="0.6" dx="0.75" dy="0.2" layer="1"/>
<smd name="3" x="-1.5" y="0.2" dx="0.75" dy="0.2" layer="1"/>
<smd name="4" x="-1.5" y="-0.2" dx="0.75" dy="0.2" layer="1"/>
<smd name="5" x="-1.5" y="-0.6" dx="0.75" dy="0.2" layer="1"/>
<smd name="6" x="-1.5" y="-1" dx="0.75" dy="0.2" layer="1"/>
<smd name="7" x="-1" y="-1.5" dx="0.75" dy="0.2" layer="1" rot="R90"/>
<smd name="8" x="-0.6" y="-1.5" dx="0.75" dy="0.2" layer="1" rot="R90"/>
<smd name="9" x="-0.2" y="-1.5" dx="0.75" dy="0.2" layer="1" rot="R90"/>
<smd name="10" x="0.2" y="-1.5" dx="0.75" dy="0.2" layer="1" rot="R90"/>
<smd name="11" x="0.6" y="-1.5" dx="0.75" dy="0.2" layer="1" rot="R90"/>
<smd name="12" x="1" y="-1.5" dx="0.75" dy="0.2" layer="1" rot="R90"/>
<smd name="13" x="1.5" y="-1" dx="0.75" dy="0.2" layer="1"/>
<smd name="14" x="1.5" y="-0.6" dx="0.75" dy="0.2" layer="1"/>
<smd name="15" x="1.5" y="-0.2" dx="0.75" dy="0.2" layer="1"/>
<smd name="16" x="1.5" y="0.2" dx="0.75" dy="0.2" layer="1"/>
<smd name="17" x="1.5" y="0.6" dx="0.75" dy="0.2" layer="1"/>
<smd name="18" x="1.5" y="1" dx="0.75" dy="0.2" layer="1"/>
<smd name="19" x="1" y="1.5" dx="0.75" dy="0.2" layer="1" rot="R90"/>
<smd name="20" x="0.6" y="1.5" dx="0.75" dy="0.2" layer="1" rot="R90"/>
<smd name="21" x="0.2" y="1.5" dx="0.75" dy="0.2" layer="1" rot="R90"/>
<smd name="22" x="-0.2" y="1.5" dx="0.75" dy="0.2" layer="1" rot="R90"/>
<smd name="23" x="-0.6" y="1.5" dx="0.75" dy="0.2" layer="1" rot="R90"/>
<smd name="24" x="-1" y="1.5" dx="0.75" dy="0.2" layer="1" rot="R90"/>
<smd name="25" x="0" y="0" dx="1.75" dy="1.59" layer="1" rot="R90"/>
<text x="0" y="0" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="0" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-2.125" y1="2.125" x2="2.125" y2="2.125" width="0.05" layer="51"/>
<wire x1="2.125" y1="2.125" x2="2.125" y2="-2.125" width="0.05" layer="51"/>
<wire x1="2.125" y1="-2.125" x2="-2.125" y2="-2.125" width="0.05" layer="51"/>
<wire x1="-2.125" y1="-2.125" x2="-2.125" y2="2.125" width="0.05" layer="51"/>
<wire x1="-1.5" y1="1.5" x2="1.5" y2="1.5" width="0.1" layer="51"/>
<wire x1="1.5" y1="1.5" x2="1.5" y2="-1.5" width="0.1" layer="51"/>
<wire x1="1.5" y1="-1.5" x2="-1.5" y2="-1.5" width="0.1" layer="51"/>
<wire x1="-1.5" y1="-1.5" x2="-1.5" y2="1.5" width="0.1" layer="51"/>
<wire x1="-1.5" y1="1.1" x2="-1.1" y2="1.5" width="0.1" layer="51"/>
<circle x="-1.875" y="1.6" radius="0.1" width="0.2" layer="25"/>
</package>
<package name="MS561101BA03-50">
<description>&lt;b&gt;MS561101BA03-50&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-1.1" y="1.875" dx="1.1" dy="0.6" layer="1"/>
<smd name="2" x="-1.1" y="0.625" dx="1.1" dy="0.6" layer="1"/>
<smd name="3" x="-1.1" y="-0.625" dx="1.1" dy="0.6" layer="1"/>
<smd name="4" x="-1.1" y="-1.875" dx="1.1" dy="0.6" layer="1"/>
<smd name="5" x="1.1" y="-1.875" dx="1.1" dy="0.6" layer="1"/>
<smd name="6" x="1.1" y="-0.625" dx="1.1" dy="0.6" layer="1"/>
<smd name="7" x="1.1" y="0.625" dx="1.1" dy="0.6" layer="1"/>
<smd name="8" x="1.1" y="1.875" dx="1.1" dy="0.6" layer="1"/>
<text x="-0.372" y="0.006" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="-0.372" y="0.006" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-1.5" y1="2.35" x2="1.5" y2="2.35" width="0.254" layer="51"/>
<wire x1="1.5" y1="2.35" x2="1.5" y2="-2.35" width="0.254" layer="51"/>
<wire x1="1.5" y1="-2.35" x2="-1.5" y2="-2.35" width="0.254" layer="51"/>
<wire x1="-1.5" y1="-2.35" x2="-1.5" y2="2.35" width="0.254" layer="51"/>
<wire x1="-1.5" y1="2.35" x2="1.5" y2="2.35" width="0.254" layer="21"/>
<wire x1="-1.5" y1="-2.35" x2="1.5" y2="-2.35" width="0.254" layer="21"/>
<circle x="-2.032" y="2.297" radius="0.045" width="0.254" layer="25"/>
</package>
<package name="SOT95P280X145-5N">
<description>&lt;b&gt;SOT-23 5 LEAD CASE 527AH-01 ISSUE O&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-1.25" y="0.95" dx="1.15" dy="0.6" layer="1"/>
<smd name="2" x="-1.25" y="0" dx="1.15" dy="0.6" layer="1"/>
<smd name="3" x="-1.25" y="-0.95" dx="1.15" dy="0.6" layer="1"/>
<smd name="4" x="1.25" y="-0.95" dx="1.15" dy="0.6" layer="1"/>
<smd name="5" x="1.25" y="0.95" dx="1.15" dy="0.6" layer="1"/>
<text x="0" y="0" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="0" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-2.075" y1="1.7" x2="2.075" y2="1.7" width="0.05" layer="51"/>
<wire x1="2.075" y1="1.7" x2="2.075" y2="-1.7" width="0.05" layer="51"/>
<wire x1="2.075" y1="-1.7" x2="-2.075" y2="-1.7" width="0.05" layer="51"/>
<wire x1="-2.075" y1="-1.7" x2="-2.075" y2="1.7" width="0.05" layer="51"/>
<wire x1="-0.8" y1="1.45" x2="0.8" y2="1.45" width="0.1" layer="51"/>
<wire x1="0.8" y1="1.45" x2="0.8" y2="-1.45" width="0.1" layer="51"/>
<wire x1="0.8" y1="-1.45" x2="-0.8" y2="-1.45" width="0.1" layer="51"/>
<wire x1="-0.8" y1="-1.45" x2="-0.8" y2="1.45" width="0.1" layer="51"/>
<wire x1="-0.8" y1="0.5" x2="0.15" y2="1.45" width="0.1" layer="51"/>
<wire x1="-0.325" y1="1.45" x2="0.325" y2="1.45" width="0.2" layer="21"/>
<wire x1="0.325" y1="1.45" x2="0.325" y2="-1.45" width="0.2" layer="21"/>
<wire x1="0.325" y1="-1.45" x2="-0.325" y2="-1.45" width="0.2" layer="21"/>
<wire x1="-0.325" y1="-1.45" x2="-0.325" y2="1.45" width="0.2" layer="21"/>
<wire x1="-1.825" y1="1.5" x2="-0.675" y2="1.5" width="0.2" layer="21"/>
</package>
<package name="FA20H160000MF12ZAC3">
<description>&lt;b&gt;FA-20H 16.0000MF12Z-AC3-3&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-0.85" y="-0.7" dx="1.2" dy="1.1" layer="1"/>
<smd name="2" x="0.85" y="-0.7" dx="1.2" dy="1.1" layer="1"/>
<smd name="3" x="0.85" y="0.7" dx="1.2" dy="1.1" layer="1"/>
<smd name="4" x="-0.85" y="0.7" dx="1.2" dy="1.1" layer="1"/>
<text x="0" y="-0.275" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="-0.275" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-1.25" y1="-1" x2="1.25" y2="-1" width="0.2" layer="51"/>
<wire x1="1.25" y1="-1" x2="1.25" y2="1" width="0.2" layer="51"/>
<wire x1="1.25" y1="1" x2="-1.25" y2="1" width="0.2" layer="51"/>
<wire x1="-1.25" y1="1" x2="-1.25" y2="-1" width="0.2" layer="51"/>
<wire x1="-2.45" y1="2.25" x2="2.45" y2="2.25" width="0.1" layer="51"/>
<wire x1="2.45" y1="2.25" x2="2.45" y2="-2.8" width="0.1" layer="51"/>
<wire x1="2.45" y1="-2.8" x2="-2.45" y2="-2.8" width="0.1" layer="51"/>
<wire x1="-2.45" y1="-2.8" x2="-2.45" y2="2.25" width="0.1" layer="51"/>
<wire x1="-0.9" y1="-1.8" x2="-0.9" y2="-1.8" width="0.2" layer="21"/>
<wire x1="-0.9" y1="-1.8" x2="-0.9" y2="-1.7" width="0.2" layer="21" curve="180"/>
<wire x1="-0.9" y1="-1.7" x2="-0.9" y2="-1.7" width="0.2" layer="21"/>
<wire x1="-0.9" y1="-1.7" x2="-0.9" y2="-1.8" width="0.2" layer="21" curve="180"/>
<wire x1="-0.9" y1="-1.8" x2="-0.9" y2="-1.8" width="0.2" layer="21"/>
<wire x1="-0.9" y1="-1.8" x2="-0.9" y2="-1.7" width="0.2" layer="21" curve="180"/>
</package>
<package name="47346-0001">
<description>&lt;b&gt;47346-0001&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="1.3" y="-4.81" dx="1.38" dy="0.45" layer="1" rot="R90"/>
<smd name="2" x="0.65" y="-4.81" dx="1.38" dy="0.45" layer="1" rot="R90"/>
<smd name="3" x="0" y="-4.81" dx="1.38" dy="0.45" layer="1" rot="R90"/>
<smd name="4" x="-0.65" y="-4.81" dx="1.38" dy="0.45" layer="1" rot="R90"/>
<smd name="5" x="-1.3" y="-4.81" dx="1.38" dy="0.45" layer="1" rot="R90"/>
<smd name="6" x="-2.4525" y="-4.45" dx="2.1" dy="1.475" layer="1" rot="R90"/>
<smd name="7" x="2.4525" y="-4.45" dx="2.1" dy="1.475" layer="1" rot="R90"/>
<smd name="8" x="0.8375" y="-2.15" dx="1.9" dy="1.175" layer="1" rot="R90"/>
<smd name="9" x="-0.8375" y="-2.15" dx="1.9" dy="1.175" layer="1" rot="R90"/>
<smd name="10" x="2.9125" y="-2.15" dx="2.375" dy="1.9" layer="1"/>
<smd name="11" x="-2.9125" y="-2.15" dx="2.375" dy="1.9" layer="1"/>
<text x="-0.313" y="-3.58" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="-0.313" y="-3.58" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-3.75" y1="0" x2="3.75" y2="0" width="0.2" layer="51"/>
<wire x1="3.75" y1="0" x2="3.75" y2="-5" width="0.2" layer="51"/>
<wire x1="3.75" y1="-5" x2="-3.75" y2="-5" width="0.2" layer="51"/>
<wire x1="-3.75" y1="-5" x2="-3.75" y2="0" width="0.2" layer="51"/>
<wire x1="-3.75" y1="0" x2="3.75" y2="0" width="0.2" layer="21"/>
<wire x1="3.75" y1="-5" x2="3.75" y2="-3.373" width="0.2" layer="21"/>
<wire x1="-3.75" y1="-5" x2="-3.75" y2="-3.373" width="0.2" layer="21"/>
<circle x="1.572" y="-5.79" radius="0.045890625" width="0.2" layer="25"/>
</package>
<package name="SM06B-GHS-TB">
<description>&lt;b&gt;SM06B-GHS-TB&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="2.25" y="4.3" dx="1.7" dy="0.6" layer="1" rot="R90"/>
<smd name="2" x="3.5" y="4.3" dx="1.7" dy="0.6" layer="1" rot="R90"/>
<smd name="3" x="4.75" y="4.3" dx="1.7" dy="0.6" layer="1" rot="R90"/>
<smd name="4" x="6" y="4.3" dx="1.7" dy="0.6" layer="1" rot="R90"/>
<smd name="5" x="7.25" y="4.3" dx="1.7" dy="0.6" layer="1" rot="R90"/>
<smd name="6" x="8.5" y="4.3" dx="1.7" dy="0.6" layer="1" rot="R90"/>
<smd name="7" x="0.4" y="1.1" dx="2.7" dy="1" layer="1" rot="R90"/>
<smd name="8" x="10.35" y="1.1" dx="2.7" dy="1" layer="1" rot="R90"/>
<text x="4.91666875" y="1.78566875" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="4.91666875" y="1.78566875" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="0" y1="4.05" x2="10.75" y2="4.05" width="0.254" layer="51"/>
<wire x1="10.75" y1="4.05" x2="10.75" y2="0" width="0.254" layer="51"/>
<wire x1="10.75" y1="0" x2="0" y2="0" width="0.254" layer="51"/>
<wire x1="0" y1="0" x2="0" y2="4.05" width="0.254" layer="51"/>
<wire x1="1.26333125" y1="0" x2="9.519" y2="0" width="0.254" layer="21"/>
<wire x1="0" y1="4.05" x2="0" y2="2.67766875" width="0.254" layer="21"/>
<wire x1="10.75" y1="4.05" x2="10.75" y2="2.706" width="0.254" layer="21"/>
<wire x1="10.75" y1="4.05" x2="8.995" y2="4.05" width="0.254" layer="21"/>
<wire x1="0" y1="4.05" x2="1.73066875" y2="4.05" width="0.254" layer="21"/>
<circle x="1.249" y="5.41066875" radius="0.0601" width="0.254" layer="25"/>
</package>
<package name="PJS00821200">
<description>&lt;b&gt;PJS008-2120-0-2&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="14" y="2.625" dx="1.4" dy="0.8" layer="1"/>
<smd name="2" x="14" y="1.525" dx="1.4" dy="0.8" layer="1"/>
<smd name="3" x="14" y="0.425" dx="1.4" dy="0.8" layer="1"/>
<smd name="4" x="14" y="-0.675" dx="1.4" dy="0.8" layer="1"/>
<smd name="5" x="14" y="-1.775" dx="1.4" dy="0.8" layer="1"/>
<smd name="6" x="14" y="-2.875" dx="1.4" dy="0.8" layer="1"/>
<smd name="7" x="14" y="-3.975" dx="1.4" dy="0.8" layer="1"/>
<smd name="8" x="14" y="-5.075" dx="1.4" dy="0.8" layer="1"/>
<smd name="G1" x="12" y="7.375" dx="2.6" dy="1.45" layer="1"/>
<smd name="G2" x="1.1" y="7.05" dx="2.4" dy="1.4" layer="1"/>
<smd name="G3" x="0.36" y="-1.4" dx="1.72" dy="1.4" layer="1"/>
<smd name="CD1" x="9.45" y="-7" dx="1.5" dy="1.3" layer="1" rot="R90"/>
<smd name="MP1" x="0.335" y="-3.75" dx="1.67" dy="1.1" layer="1"/>
<text x="7.35" y="0.175" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="7.35" y="0.175" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="0" y1="7.25" x2="15.2" y2="7.25" width="0.2" layer="51"/>
<wire x1="15.2" y1="7.25" x2="15.2" y2="-7.25" width="0.2" layer="51"/>
<wire x1="15.2" y1="-7.25" x2="0" y2="-7.25" width="0.2" layer="51"/>
<wire x1="0" y1="-7.25" x2="0" y2="7.25" width="0.2" layer="51"/>
<wire x1="-1.5" y1="9.1" x2="16.2" y2="9.1" width="0.1" layer="51"/>
<wire x1="16.2" y1="9.1" x2="16.2" y2="-8.75" width="0.1" layer="51"/>
<wire x1="16.2" y1="-8.75" x2="-1.5" y2="-8.75" width="0.1" layer="51"/>
<wire x1="-1.5" y1="-8.75" x2="-1.5" y2="9.1" width="0.1" layer="51"/>
<wire x1="13.9" y1="7.25" x2="15.2" y2="7.25" width="0.1" layer="21"/>
<wire x1="15.2" y1="7.25" x2="15.2" y2="-7.25" width="0.1" layer="21"/>
<wire x1="15.2" y1="-7.25" x2="10.5" y2="-7.25" width="0.1" layer="21"/>
<wire x1="0" y1="-5" x2="0" y2="-7.25" width="0.1" layer="21"/>
<wire x1="0" y1="-7.25" x2="8" y2="-7.25" width="0.1" layer="21"/>
<wire x1="8" y1="-7.25" x2="8.5" y2="-7.25" width="0.1" layer="21"/>
<wire x1="0" y1="-0.5" x2="0" y2="6" width="0.1" layer="21"/>
<wire x1="2.7" y1="7.25" x2="10" y2="7.25" width="0.1" layer="21"/>
<wire x1="9.5" y1="7.25" x2="10" y2="7.25" width="0.1" layer="21"/>
<wire x1="10" y1="7.25" x2="10.3" y2="7.25" width="0.1" layer="21"/>
</package>
<package name="SON65P300X300X100-9N">
<description>&lt;b&gt;hvson sot782-1 8 lead&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-1.45" y="0.975" dx="0.85" dy="0.35" layer="1"/>
<smd name="2" x="-1.45" y="0.325" dx="0.85" dy="0.35" layer="1"/>
<smd name="3" x="-1.45" y="-0.325" dx="0.85" dy="0.35" layer="1"/>
<smd name="4" x="-1.45" y="-0.975" dx="0.85" dy="0.35" layer="1"/>
<smd name="5" x="1.45" y="-0.975" dx="0.85" dy="0.35" layer="1"/>
<smd name="6" x="1.45" y="-0.325" dx="0.85" dy="0.35" layer="1"/>
<smd name="7" x="1.45" y="0.325" dx="0.85" dy="0.35" layer="1"/>
<smd name="8" x="1.45" y="0.975" dx="0.85" dy="0.35" layer="1"/>
<smd name="9" x="0" y="0" dx="2.45" dy="1.65" layer="1" rot="R90"/>
<text x="0" y="0" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="0" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-2.125" y1="1.8" x2="2.125" y2="1.8" width="0.05" layer="51"/>
<wire x1="2.125" y1="1.8" x2="2.125" y2="-1.8" width="0.05" layer="51"/>
<wire x1="2.125" y1="-1.8" x2="-2.125" y2="-1.8" width="0.05" layer="51"/>
<wire x1="-2.125" y1="-1.8" x2="-2.125" y2="1.8" width="0.05" layer="51"/>
<wire x1="-1.5" y1="1.5" x2="1.5" y2="1.5" width="0.1" layer="51"/>
<wire x1="1.5" y1="1.5" x2="1.5" y2="-1.5" width="0.1" layer="51"/>
<wire x1="1.5" y1="-1.5" x2="-1.5" y2="-1.5" width="0.1" layer="51"/>
<wire x1="-1.5" y1="-1.5" x2="-1.5" y2="1.5" width="0.1" layer="51"/>
<wire x1="-1.5" y1="0.75" x2="-0.75" y2="1.5" width="0.1" layer="51"/>
<circle x="-1.875" y="1.65" radius="0.125" width="0.25" layer="25"/>
</package>
<package name="SM04B-GHS-TB">
<description>&lt;b&gt;SM04B-GHS-TB&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-1.875" y="0.2" dx="1.7" dy="0.6" layer="1" rot="R90"/>
<smd name="2" x="-0.625" y="0.2" dx="1.7" dy="0.6" layer="1" rot="R90"/>
<smd name="3" x="0.625" y="0.2" dx="1.7" dy="0.6" layer="1" rot="R90"/>
<smd name="4" x="1.875" y="0.2" dx="1.7" dy="0.6" layer="1" rot="R90"/>
<smd name="5" x="-3.725" y="-3" dx="2.7" dy="1" layer="1" rot="R90"/>
<smd name="6" x="3.725" y="-3" dx="2.7" dy="1" layer="1" rot="R90"/>
<text x="-0.33321875" y="-2.8343" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="-0.33321875" y="-2.8343" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-4.125" y1="0" x2="4.125" y2="0" width="0.2" layer="51"/>
<wire x1="4.125" y1="0" x2="4.125" y2="-4.25" width="0.2" layer="51"/>
<wire x1="4.125" y1="-4.25" x2="-4.125" y2="-4.25" width="0.2" layer="51"/>
<wire x1="-4.125" y1="-4.25" x2="-4.125" y2="0" width="0.2" layer="51"/>
<wire x1="-2.9" y1="-4.25" x2="2.9" y2="-4.25" width="0.2" layer="21"/>
<wire x1="-4.125" y1="0" x2="-4.125" y2="-1.4" width="0.2" layer="21"/>
<wire x1="4.125" y1="0" x2="4.125" y2="-1.4" width="0.2" layer="21"/>
<wire x1="-4.125" y1="0" x2="-2.5" y2="0" width="0.2" layer="21"/>
<wire x1="4.125" y1="0" x2="2.5" y2="0" width="0.2" layer="21"/>
</package>
<package name="SM05B-GHS-TB">
<description>&lt;b&gt;SM05B-GHS-TB&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-2.5" y="0.2" dx="1.7" dy="0.6" layer="1" rot="R90"/>
<smd name="2" x="-1.25" y="0.2" dx="1.7" dy="0.6" layer="1" rot="R90"/>
<smd name="3" x="0" y="0.2" dx="1.7" dy="0.6" layer="1" rot="R90"/>
<smd name="4" x="1.25" y="0.2" dx="1.7" dy="0.6" layer="1" rot="R90"/>
<smd name="5" x="2.5" y="0.2" dx="1.7" dy="0.6" layer="1" rot="R90"/>
<smd name="6" x="-4.35" y="-3" dx="2.7" dy="1" layer="1" rot="R90"/>
<smd name="7" x="4.35" y="-3" dx="2.7" dy="1" layer="1" rot="R90"/>
<text x="-0.273" y="-3.019" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="-0.273" y="-3.019" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-4.75" y1="0.2" x2="4.75" y2="0.2" width="0.2" layer="51"/>
<wire x1="4.75" y1="0.2" x2="4.75" y2="-4.05" width="0.2" layer="51"/>
<wire x1="4.75" y1="-4.05" x2="-4.75" y2="-4.05" width="0.2" layer="51"/>
<wire x1="-4.75" y1="-4.05" x2="-4.75" y2="0.2" width="0.2" layer="51"/>
<wire x1="-3.5" y1="-4.05" x2="3.5" y2="-4.05" width="0.2" layer="21"/>
<wire x1="-4.75" y1="0.2" x2="-4.75" y2="-1.429" width="0.2" layer="21"/>
<wire x1="-4.75" y1="0.2" x2="-3.153" y2="0.2" width="0.2" layer="21"/>
<wire x1="4.75" y1="0.2" x2="3.153" y2="0.2" width="0.2" layer="21"/>
<wire x1="4.75" y1="0.2" x2="4.75" y2="-1.429" width="0.2" layer="21"/>
<circle x="-3.263" y="1.288" radius="0.036" width="0.2" layer="25"/>
</package>
<package name="SOT65P210X110-5N">
<description>&lt;b&gt;74LVC1G86SE-7&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-1" y="0.65" dx="1" dy="0.4" layer="1"/>
<smd name="2" x="-1" y="0" dx="1" dy="0.4" layer="1"/>
<smd name="3" x="-1" y="-0.65" dx="1" dy="0.4" layer="1"/>
<smd name="4" x="1" y="-0.65" dx="1" dy="0.4" layer="1"/>
<smd name="5" x="1" y="0.65" dx="1" dy="0.4" layer="1"/>
<text x="0" y="0" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="0" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-1.75" y1="1.35" x2="1.75" y2="1.35" width="0.05" layer="51"/>
<wire x1="1.75" y1="1.35" x2="1.75" y2="-1.35" width="0.05" layer="51"/>
<wire x1="1.75" y1="-1.35" x2="-1.75" y2="-1.35" width="0.05" layer="51"/>
<wire x1="-1.75" y1="-1.35" x2="-1.75" y2="1.35" width="0.05" layer="51"/>
<wire x1="-0.625" y1="1" x2="0.625" y2="1" width="0.1" layer="51"/>
<wire x1="0.625" y1="1" x2="0.625" y2="-1" width="0.1" layer="51"/>
<wire x1="0.625" y1="-1" x2="-0.625" y2="-1" width="0.1" layer="51"/>
<wire x1="-0.625" y1="-1" x2="-0.625" y2="1" width="0.1" layer="51"/>
<wire x1="-0.625" y1="0.35" x2="0.025" y2="1" width="0.1" layer="51"/>
<wire x1="-0.15" y1="1" x2="0.15" y2="1" width="0.2" layer="21"/>
<wire x1="0.15" y1="1" x2="0.15" y2="-1" width="0.2" layer="21"/>
<wire x1="0.15" y1="-1" x2="-0.15" y2="-1" width="0.2" layer="21"/>
<wire x1="-0.15" y1="-1" x2="-0.15" y2="1" width="0.2" layer="21"/>
<wire x1="-1.5" y1="1.1" x2="-0.5" y2="1.1" width="0.2" layer="21"/>
</package>
<package name="SOP50P310X100-8N">
<description>&lt;b&gt;SOT765-1&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-1.575" y="0.75" dx="0.85" dy="0.3" layer="1"/>
<smd name="2" x="-1.575" y="0.25" dx="0.85" dy="0.3" layer="1"/>
<smd name="3" x="-1.575" y="-0.25" dx="0.85" dy="0.3" layer="1"/>
<smd name="4" x="-1.575" y="-0.75" dx="0.85" dy="0.3" layer="1"/>
<smd name="5" x="1.575" y="-0.75" dx="0.85" dy="0.3" layer="1"/>
<smd name="6" x="1.575" y="-0.25" dx="0.85" dy="0.3" layer="1"/>
<smd name="7" x="1.575" y="0.25" dx="0.85" dy="0.3" layer="1"/>
<smd name="8" x="1.575" y="0.75" dx="0.85" dy="0.3" layer="1"/>
<text x="0" y="0" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="0" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-2.25" y1="1.3" x2="2.25" y2="1.3" width="0.05" layer="51"/>
<wire x1="2.25" y1="1.3" x2="2.25" y2="-1.3" width="0.05" layer="51"/>
<wire x1="2.25" y1="-1.3" x2="-2.25" y2="-1.3" width="0.05" layer="51"/>
<wire x1="-2.25" y1="-1.3" x2="-2.25" y2="1.3" width="0.05" layer="51"/>
<wire x1="-1.15" y1="1" x2="1.15" y2="1" width="0.1" layer="51"/>
<wire x1="1.15" y1="1" x2="1.15" y2="-1" width="0.1" layer="51"/>
<wire x1="1.15" y1="-1" x2="-1.15" y2="-1" width="0.1" layer="51"/>
<wire x1="-1.15" y1="-1" x2="-1.15" y2="1" width="0.1" layer="51"/>
<wire x1="-1.15" y1="0.5" x2="-0.65" y2="1" width="0.1" layer="51"/>
<wire x1="-0.8" y1="1" x2="0.8" y2="1" width="0.2" layer="21"/>
<wire x1="0.8" y1="1" x2="0.8" y2="-1" width="0.2" layer="21"/>
<wire x1="0.8" y1="-1" x2="-0.8" y2="-1" width="0.2" layer="21"/>
<wire x1="-0.8" y1="-1" x2="-0.8" y2="1" width="0.2" layer="21"/>
<wire x1="-2" y1="1.25" x2="-1.15" y2="1.25" width="0.2" layer="21"/>
</package>
<package name="SM06B-SRSS-TB">
<description>&lt;b&gt;SM06B-SRSS-TB&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-2.5" y="0.4" dx="1.55" dy="0.6" layer="1" rot="R90"/>
<smd name="2" x="-1.5" y="0.4" dx="1.55" dy="0.6" layer="1" rot="R90"/>
<smd name="3" x="-0.5" y="0.4" dx="1.55" dy="0.6" layer="1" rot="R90"/>
<smd name="4" x="0.5" y="0.4" dx="1.55" dy="0.6" layer="1" rot="R90"/>
<smd name="5" x="1.5" y="0.4" dx="1.55" dy="0.6" layer="1" rot="R90"/>
<smd name="6" x="2.5" y="0.4" dx="1.55" dy="0.6" layer="1" rot="R90"/>
<smd name="7" x="3.8" y="-3.475" dx="1.8" dy="1.2" layer="1" rot="R90"/>
<smd name="8" x="-3.8" y="-3.475" dx="1.8" dy="1.2" layer="1" rot="R90"/>
<text x="-0.362" y="-1.462" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="-0.362" y="-1.462" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-4" y1="0" x2="4" y2="0" width="0.2" layer="51"/>
<wire x1="4" y1="0" x2="4" y2="-4.25" width="0.2" layer="51"/>
<wire x1="4" y1="-4.25" x2="-4" y2="-4.25" width="0.2" layer="51"/>
<wire x1="-4" y1="-4.25" x2="-4" y2="0" width="0.2" layer="51"/>
<wire x1="-4" y1="0" x2="-4" y2="-2.125" width="0.2" layer="21"/>
<wire x1="4" y1="0" x2="4" y2="-2.125" width="0.2" layer="21"/>
<wire x1="4" y1="0" x2="3.1" y2="0" width="0.2" layer="21"/>
<wire x1="-4" y1="0" x2="-3.1" y2="0" width="0.2" layer="21"/>
<wire x1="-2.9" y1="-4.25" x2="2.9" y2="-4.25" width="0.2" layer="21"/>
<circle x="-3.204" y="1.523" radius="0.06395" width="0.2" layer="25"/>
</package>
<package name="PMEG2020CPASX">
<description>&lt;b&gt;PMEG2020CPASX-2&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-0.65" y="-0.85" dx="0.6" dy="0.4" layer="1" rot="R90"/>
<smd name="2" x="0.65" y="-0.85" dx="0.6" dy="0.4" layer="1" rot="R90"/>
<smd name="3" x="0" y="0.25" dx="1.6" dy="1.1" layer="1"/>
<smd name="4" x="0" y="0.975" dx="0.4" dy="0.35" layer="1"/>
<text x="0" y="-0.35" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="-0.35" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-1" y1="1" x2="1" y2="1" width="0.2" layer="51"/>
<wire x1="1" y1="1" x2="1" y2="-1" width="0.2" layer="51"/>
<wire x1="1" y1="-1" x2="-1" y2="-1" width="0.2" layer="51"/>
<wire x1="-1" y1="-1" x2="-1" y2="1" width="0.2" layer="51"/>
<wire x1="-2" y1="-2.85" x2="2" y2="-2.85" width="0.1" layer="51"/>
<wire x1="2" y1="-2.85" x2="2" y2="2.15" width="0.1" layer="51"/>
<wire x1="2" y1="2.15" x2="-2" y2="2.15" width="0.1" layer="51"/>
<wire x1="-2" y1="2.15" x2="-2" y2="-2.85" width="0.1" layer="51"/>
<wire x1="-0.7" y1="-1.8" x2="-0.7" y2="-1.8" width="0.2" layer="21"/>
<wire x1="-0.7" y1="-1.8" x2="-0.6" y2="-1.8" width="0.2" layer="21" curve="180"/>
<wire x1="-0.6" y1="-1.8" x2="-0.6" y2="-1.8" width="0.2" layer="21"/>
<wire x1="-0.6" y1="-1.8" x2="-0.7" y2="-1.8" width="0.2" layer="21" curve="180"/>
<wire x1="-0.7" y1="-1.8" x2="-0.7" y2="-1.8" width="0.2" layer="21"/>
<wire x1="-0.7" y1="-1.8" x2="-0.6" y2="-1.8" width="0.2" layer="21" curve="180"/>
</package>
<package name="LEDC1608X28N">
<description>&lt;b&gt;APG1608ZGCK&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-0.85" y="0" dx="0.95" dy="0.8" layer="1" rot="R90"/>
<smd name="2" x="0.85" y="0" dx="0.95" dy="0.8" layer="1" rot="R90"/>
<text x="0" y="0" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="0" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-1.7" y1="0.925" x2="1.7" y2="0.925" width="0.05" layer="51"/>
<wire x1="1.7" y1="0.925" x2="1.7" y2="-0.925" width="0.05" layer="51"/>
<wire x1="1.7" y1="-0.925" x2="-1.7" y2="-0.925" width="0.05" layer="51"/>
<wire x1="-1.7" y1="-0.925" x2="-1.7" y2="0.925" width="0.05" layer="51"/>
<wire x1="-0.8" y1="0.4" x2="0.8" y2="0.4" width="0.1" layer="51"/>
<wire x1="0.8" y1="0.4" x2="0.8" y2="-0.4" width="0.1" layer="51"/>
<wire x1="0.8" y1="-0.4" x2="-0.8" y2="-0.4" width="0.1" layer="51"/>
<wire x1="-0.8" y1="-0.4" x2="-0.8" y2="0.4" width="0.1" layer="51"/>
<wire x1="-0.8" y1="0.133" x2="-0.533" y2="0.4" width="0.1" layer="51"/>
<wire x1="0.85" y1="0.825" x2="-1.6" y2="0.825" width="0.2" layer="21"/>
<wire x1="-1.6" y1="0.825" x2="-1.6" y2="-0.825" width="0.2" layer="21"/>
<wire x1="-1.6" y1="-0.825" x2="0.85" y2="-0.825" width="0.2" layer="21"/>
</package>
<package name="SODFL2512X80N">
<description>&lt;b&gt;SOD323F (SC-90)_12&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-1.15" y="0" dx="0.84" dy="0.46" layer="1"/>
<smd name="2" x="1.15" y="0" dx="0.84" dy="0.46" layer="1"/>
<text x="0" y="0" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="0" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-1.72" y1="0.825" x2="1.72" y2="0.825" width="0.05" layer="51"/>
<wire x1="1.72" y1="0.825" x2="1.72" y2="-0.825" width="0.05" layer="51"/>
<wire x1="1.72" y1="-0.825" x2="-1.72" y2="-0.825" width="0.05" layer="51"/>
<wire x1="-1.72" y1="-0.825" x2="-1.72" y2="0.825" width="0.05" layer="51"/>
<wire x1="-0.85" y1="0.625" x2="0.85" y2="0.625" width="0.1" layer="51"/>
<wire x1="0.85" y1="0.625" x2="0.85" y2="-0.625" width="0.1" layer="51"/>
<wire x1="0.85" y1="-0.625" x2="-0.85" y2="-0.625" width="0.1" layer="51"/>
<wire x1="-0.85" y1="-0.625" x2="-0.85" y2="0.625" width="0.1" layer="51"/>
<wire x1="-0.85" y1="0.205" x2="-0.43" y2="0.625" width="0.1" layer="51"/>
<wire x1="-1.57" y1="0.625" x2="0.85" y2="0.625" width="0.2" layer="21"/>
<wire x1="-0.85" y1="-0.625" x2="0.85" y2="-0.625" width="0.2" layer="21"/>
</package>
<package name="0603L050SLYR">
<description>&lt;b&gt;0603L050SLYR&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-0.9" y="0" dx="1" dy="1" layer="1" rot="R90"/>
<smd name="2" x="0.9" y="0" dx="1" dy="1" layer="1" rot="R90"/>
<text x="-0.012" y="0" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="-0.012" y="0" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-0.8" y1="0.4" x2="0.8" y2="0.4" width="0.1" layer="51"/>
<wire x1="0.8" y1="0.4" x2="0.8" y2="-0.4" width="0.1" layer="51"/>
<wire x1="0.8" y1="-0.4" x2="-0.8" y2="-0.4" width="0.1" layer="51"/>
<wire x1="-0.8" y1="-0.4" x2="-0.8" y2="0.4" width="0.1" layer="51"/>
<wire x1="-2.4" y1="1.5" x2="2.375" y2="1.5" width="0.1" layer="51"/>
<wire x1="2.375" y1="1.5" x2="2.375" y2="-1.5" width="0.1" layer="51"/>
<wire x1="2.375" y1="-1.5" x2="-2.4" y2="-1.5" width="0.1" layer="51"/>
<wire x1="-2.4" y1="-1.5" x2="-2.4" y2="1.5" width="0.1" layer="51"/>
<wire x1="0" y1="0.3" x2="0" y2="-0.3" width="0.2" layer="21"/>
<wire x1="-1.9" y1="0.1" x2="-1.9" y2="0.1" width="0.2" layer="21"/>
<wire x1="-1.9" y1="0.1" x2="-1.9" y2="-0.1" width="0.2" layer="21" curve="180"/>
<wire x1="-1.9" y1="-0.1" x2="-1.9" y2="-0.1" width="0.2" layer="21"/>
<wire x1="-1.9" y1="-0.1" x2="-1.9" y2="0.1" width="0.2" layer="21" curve="180"/>
</package>
<package name="1N4448XTP">
<description>&lt;b&gt;1N4448X-TP-5&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-0.85" y="0" dx="0.8" dy="0.6" layer="1" rot="R90"/>
<smd name="2" x="0.85" y="0" dx="0.8" dy="0.6" layer="1" rot="R90"/>
<text x="0" y="0" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="0" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-0.6" y1="0.4" x2="0.6" y2="0.4" width="0.1" layer="51"/>
<wire x1="0.6" y1="0.4" x2="0.6" y2="-0.4" width="0.1" layer="51"/>
<wire x1="0.6" y1="-0.4" x2="-0.6" y2="-0.4" width="0.1" layer="51"/>
<wire x1="-0.6" y1="-0.4" x2="-0.6" y2="0.4" width="0.1" layer="51"/>
<wire x1="-2.15" y1="1.4" x2="2.15" y2="1.4" width="0.1" layer="51"/>
<wire x1="2.15" y1="1.4" x2="2.15" y2="-1.4" width="0.1" layer="51"/>
<wire x1="2.15" y1="-1.4" x2="-2.15" y2="-1.4" width="0.1" layer="51"/>
<wire x1="-2.15" y1="-1.4" x2="-2.15" y2="1.4" width="0.1" layer="51"/>
<wire x1="-0.2" y1="0.4" x2="0.2" y2="0.4" width="0.2" layer="21"/>
<wire x1="-0.2" y1="-0.4" x2="0.2" y2="-0.4" width="0.2" layer="21"/>
</package>
<package name="LTST-C19HE1WT">
<description>&lt;b&gt;LTST-C19HE1WT&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-0.425" y="0.725" dx="0.85" dy="0.65" layer="1" rot="R90"/>
<smd name="2" x="0.425" y="0.725" dx="0.85" dy="0.65" layer="1" rot="R90"/>
<smd name="3" x="0.425" y="-0.725" dx="0.85" dy="0.65" layer="1" rot="R90"/>
<smd name="4" x="-0.425" y="-0.725" dx="0.85" dy="0.65" layer="1" rot="R90"/>
<text x="-0.386" y="0.118" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="-0.386" y="0.118" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-0.8" y1="0.8" x2="0.8" y2="0.8" width="0.254" layer="51"/>
<wire x1="0.8" y1="0.8" x2="0.8" y2="-0.8" width="0.254" layer="51"/>
<wire x1="0.8" y1="-0.8" x2="-0.8" y2="-0.8" width="0.254" layer="51"/>
<wire x1="-0.8" y1="-0.8" x2="-0.8" y2="0.8" width="0.254" layer="51"/>
</package>
<package name="SOT95P285X130-5N">
<description>&lt;b&gt;SOT25&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-1.3" y="0.95" dx="1.15" dy="0.6" layer="1"/>
<smd name="2" x="-1.3" y="0" dx="1.15" dy="0.6" layer="1"/>
<smd name="3" x="-1.3" y="-0.95" dx="1.15" dy="0.6" layer="1"/>
<smd name="4" x="1.3" y="-0.95" dx="1.15" dy="0.6" layer="1"/>
<smd name="5" x="1.3" y="0.95" dx="1.15" dy="0.6" layer="1"/>
<text x="0" y="0" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="0" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-2.125" y1="1.8" x2="2.125" y2="1.8" width="0.05" layer="51"/>
<wire x1="2.125" y1="1.8" x2="2.125" y2="-1.8" width="0.05" layer="51"/>
<wire x1="2.125" y1="-1.8" x2="-2.125" y2="-1.8" width="0.05" layer="51"/>
<wire x1="-2.125" y1="-1.8" x2="-2.125" y2="1.8" width="0.05" layer="51"/>
<wire x1="-0.8" y1="1.5" x2="0.8" y2="1.5" width="0.1" layer="51"/>
<wire x1="0.8" y1="1.5" x2="0.8" y2="-1.5" width="0.1" layer="51"/>
<wire x1="0.8" y1="-1.5" x2="-0.8" y2="-1.5" width="0.1" layer="51"/>
<wire x1="-0.8" y1="-1.5" x2="-0.8" y2="1.5" width="0.1" layer="51"/>
<wire x1="-0.8" y1="0.55" x2="0.15" y2="1.5" width="0.1" layer="51"/>
<wire x1="-0.375" y1="1.5" x2="0.375" y2="1.5" width="0.2" layer="21"/>
<wire x1="0.375" y1="1.5" x2="0.375" y2="-1.5" width="0.2" layer="21"/>
<wire x1="0.375" y1="-1.5" x2="-0.375" y2="-1.5" width="0.2" layer="21"/>
<wire x1="-0.375" y1="-1.5" x2="-0.375" y2="1.5" width="0.2" layer="21"/>
<wire x1="-1.875" y1="1.5" x2="-0.725" y2="1.5" width="0.2" layer="21"/>
</package>
<package name="DIOM179X85N">
<description>&lt;b&gt;0603/SOD-523F_1&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-0.85" y="0" dx="1.15" dy="0.75" layer="1"/>
<smd name="2" x="0.85" y="0" dx="1.15" dy="0.75" layer="1"/>
<text x="0" y="0" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="0" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-1.675" y1="0.75" x2="1.675" y2="0.75" width="0.05" layer="51"/>
<wire x1="1.675" y1="0.75" x2="1.675" y2="-0.75" width="0.05" layer="51"/>
<wire x1="1.675" y1="-0.75" x2="-1.675" y2="-0.75" width="0.05" layer="51"/>
<wire x1="-1.675" y1="-0.75" x2="-1.675" y2="0.75" width="0.05" layer="51"/>
<wire x1="-0.85" y1="0.45" x2="0.85" y2="0.45" width="0.1" layer="51"/>
<wire x1="0.85" y1="0.45" x2="0.85" y2="-0.45" width="0.1" layer="51"/>
<wire x1="0.85" y1="-0.45" x2="-0.85" y2="-0.45" width="0.1" layer="51"/>
<wire x1="-0.85" y1="-0.45" x2="-0.85" y2="0.45" width="0.1" layer="51"/>
<wire x1="-0.85" y1="0.075" x2="-0.475" y2="0.45" width="0.1" layer="51"/>
<wire x1="0.85" y1="0.45" x2="-1.225" y2="0.45" width="0.2" layer="21"/>
<wire x1="-0.85" y1="-0.45" x2="0.85" y2="-0.45" width="0.2" layer="21"/>
</package>
<package name="W2H13C1048AT1A">
<description>&lt;b&gt;W2H 0805&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-1.225" y="0" dx="1.02" dy="1.27" layer="1"/>
<smd name="2" x="1.225" y="0" dx="1.02" dy="1.27" layer="1"/>
<smd name="3" x="0" y="0.635" dx="0.51" dy="0.51" layer="1"/>
<smd name="4" x="0" y="-0.635" dx="0.51" dy="0.51" layer="1"/>
<text x="0" y="0" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="0" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-1.005" y1="0.625" x2="1.005" y2="0.625" width="0.2" layer="51"/>
<wire x1="1.005" y1="0.625" x2="1.005" y2="-0.625" width="0.2" layer="51"/>
<wire x1="1.005" y1="-0.625" x2="-1.005" y2="-0.625" width="0.2" layer="51"/>
<wire x1="-1.005" y1="-0.625" x2="-1.005" y2="0.625" width="0.2" layer="51"/>
<wire x1="-2.735" y1="1.89" x2="2.735" y2="1.89" width="0.1" layer="51"/>
<wire x1="2.735" y1="1.89" x2="2.735" y2="-1.89" width="0.1" layer="51"/>
<wire x1="2.735" y1="-1.89" x2="-2.735" y2="-1.89" width="0.1" layer="51"/>
<wire x1="-2.735" y1="-1.89" x2="-2.735" y2="1.89" width="0.1" layer="51"/>
<wire x1="-0.5" y1="0.635" x2="-0.4" y2="0.635" width="0.1" layer="21"/>
<wire x1="-0.4" y1="-0.625" x2="-0.5" y2="-0.625" width="0.1" layer="21"/>
<wire x1="0.4" y1="0.635" x2="0.5" y2="0.635" width="0.1" layer="21"/>
<wire x1="0.4" y1="-0.635" x2="0.5" y2="-0.635" width="0.1" layer="21"/>
</package>
<package name="SOT95P280X130-3N">
<description>&lt;b&gt;SOT-23&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-1.4" y="0.95" dx="0.9" dy="0.6" layer="1"/>
<smd name="2" x="-1.4" y="-0.95" dx="0.9" dy="0.6" layer="1"/>
<smd name="3" x="1.4" y="0" dx="0.9" dy="0.6" layer="1"/>
<text x="0" y="0" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="0" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-2.1" y1="1.8" x2="2.1" y2="1.8" width="0.05" layer="51"/>
<wire x1="2.1" y1="1.8" x2="2.1" y2="-1.8" width="0.05" layer="51"/>
<wire x1="2.1" y1="-1.8" x2="-2.1" y2="-1.8" width="0.05" layer="51"/>
<wire x1="-2.1" y1="-1.8" x2="-2.1" y2="1.8" width="0.05" layer="51"/>
<wire x1="-0.825" y1="1.45" x2="0.825" y2="1.45" width="0.1" layer="51"/>
<wire x1="0.825" y1="1.45" x2="0.825" y2="-1.45" width="0.1" layer="51"/>
<wire x1="0.825" y1="-1.45" x2="-0.825" y2="-1.45" width="0.1" layer="51"/>
<wire x1="-0.825" y1="-1.45" x2="-0.825" y2="1.45" width="0.1" layer="51"/>
<wire x1="-0.825" y1="0.5" x2="0.125" y2="1.45" width="0.1" layer="51"/>
<wire x1="-0.6" y1="1.45" x2="0.6" y2="1.45" width="0.2" layer="21"/>
<wire x1="0.6" y1="1.45" x2="0.6" y2="-1.45" width="0.2" layer="21"/>
<wire x1="0.6" y1="-1.45" x2="-0.6" y2="-1.45" width="0.2" layer="21"/>
<wire x1="-0.6" y1="-1.45" x2="-0.6" y2="1.45" width="0.2" layer="21"/>
<wire x1="-1.85" y1="1.5" x2="-0.95" y2="1.5" width="0.2" layer="21"/>
</package>
<package name="SOT65P210X100-3N">
<description>&lt;b&gt;SOT-323-3&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-1.1" y="0.65" dx="0.75" dy="0.5" layer="1"/>
<smd name="2" x="-1.1" y="-0.65" dx="0.75" dy="0.5" layer="1"/>
<smd name="3" x="1.1" y="0" dx="0.75" dy="0.5" layer="1"/>
<text x="0" y="0" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="0" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-1.725" y1="1.35" x2="1.725" y2="1.35" width="0.05" layer="51"/>
<wire x1="1.725" y1="1.35" x2="1.725" y2="-1.35" width="0.05" layer="51"/>
<wire x1="1.725" y1="-1.35" x2="-1.725" y2="-1.35" width="0.05" layer="51"/>
<wire x1="-1.725" y1="-1.35" x2="-1.725" y2="1.35" width="0.05" layer="51"/>
<wire x1="-0.625" y1="1" x2="0.625" y2="1" width="0.1" layer="51"/>
<wire x1="0.625" y1="1" x2="0.625" y2="-1" width="0.1" layer="51"/>
<wire x1="0.625" y1="-1" x2="-0.625" y2="-1" width="0.1" layer="51"/>
<wire x1="-0.625" y1="-1" x2="-0.625" y2="1" width="0.1" layer="51"/>
<wire x1="-0.625" y1="0.35" x2="0.025" y2="1" width="0.1" layer="51"/>
<wire x1="-0.375" y1="1" x2="0.375" y2="1" width="0.2" layer="21"/>
<wire x1="0.375" y1="1" x2="0.375" y2="-1" width="0.2" layer="21"/>
<wire x1="0.375" y1="-1" x2="-0.375" y2="-1" width="0.2" layer="21"/>
<wire x1="-0.375" y1="-1" x2="-0.375" y2="1" width="0.2" layer="21"/>
<wire x1="-1.475" y1="1.15" x2="-0.725" y2="1.15" width="0.2" layer="21"/>
</package>
<package name="IAM20680HP">
<description>&lt;b&gt;16 Lead LGA (3x3x0.75)-1-1&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-1.2" y="1" dx="0.5" dy="0.3" layer="1"/>
<smd name="2" x="-1.2" y="0.5" dx="0.5" dy="0.3" layer="1"/>
<smd name="3" x="-1.2" y="0" dx="0.5" dy="0.3" layer="1"/>
<smd name="4" x="-1.2" y="-0.5" dx="0.5" dy="0.3" layer="1"/>
<smd name="5" x="-1.2" y="-1" dx="0.5" dy="0.3" layer="1"/>
<smd name="6" x="-0.5" y="-1.2" dx="0.5" dy="0.3" layer="1" rot="R90"/>
<smd name="7" x="0" y="-1.2" dx="0.5" dy="0.3" layer="1" rot="R90"/>
<smd name="8" x="0.5" y="-1.2" dx="0.5" dy="0.3" layer="1" rot="R90"/>
<smd name="9" x="1.2" y="-1" dx="0.5" dy="0.3" layer="1"/>
<smd name="10" x="1.2" y="-0.5" dx="0.5" dy="0.3" layer="1"/>
<smd name="11" x="1.2" y="0" dx="0.5" dy="0.3" layer="1"/>
<smd name="12" x="1.2" y="0.5" dx="0.5" dy="0.3" layer="1"/>
<smd name="13" x="1.2" y="1" dx="0.5" dy="0.3" layer="1"/>
<smd name="14" x="0.5" y="1.2" dx="0.5" dy="0.3" layer="1" rot="R90"/>
<smd name="15" x="0" y="1.2" dx="0.5" dy="0.3" layer="1" rot="R90"/>
<smd name="16" x="-0.5" y="1.2" dx="0.5" dy="0.3" layer="1" rot="R90"/>
<text x="0" y="0" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="0" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-1.5" y1="1.5" x2="1.5" y2="1.5" width="0.2" layer="51"/>
<wire x1="1.5" y1="1.5" x2="1.5" y2="-1.5" width="0.2" layer="51"/>
<wire x1="1.5" y1="-1.5" x2="-1.5" y2="-1.5" width="0.2" layer="51"/>
<wire x1="-1.5" y1="-1.5" x2="-1.5" y2="1.5" width="0.2" layer="51"/>
<wire x1="-2.5" y1="2.5" x2="2.5" y2="2.5" width="0.1" layer="51"/>
<wire x1="2.5" y1="2.5" x2="2.5" y2="-2.5" width="0.1" layer="51"/>
<wire x1="2.5" y1="-2.5" x2="-2.5" y2="-2.5" width="0.1" layer="51"/>
<wire x1="-2.5" y1="-2.5" x2="-2.5" y2="2.5" width="0.1" layer="51"/>
<wire x1="-1.891" y1="1.1" x2="-1.891" y2="1.1" width="0.2" layer="21"/>
<wire x1="-1.891" y1="1.1" x2="-1.891" y2="0.9" width="0.2" layer="21" curve="180"/>
<wire x1="-1.891" y1="0.9" x2="-1.891" y2="0.9" width="0.2" layer="21"/>
<wire x1="-1.891" y1="0.9" x2="-1.891" y2="1.1" width="0.2" layer="21" curve="180"/>
</package>
<package name="SOIC127P602X173-8N">
<description>&lt;b&gt;FM25V02A-GTR&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-2.725" y="1.905" dx="1.551" dy="0.65" layer="1"/>
<smd name="2" x="-2.725" y="0.635" dx="1.551" dy="0.65" layer="1"/>
<smd name="3" x="-2.725" y="-0.635" dx="1.551" dy="0.65" layer="1"/>
<smd name="4" x="-2.725" y="-1.905" dx="1.551" dy="0.65" layer="1"/>
<smd name="5" x="2.725" y="-1.905" dx="1.551" dy="0.65" layer="1"/>
<smd name="6" x="2.725" y="-0.635" dx="1.551" dy="0.65" layer="1"/>
<smd name="7" x="2.725" y="0.635" dx="1.551" dy="0.65" layer="1"/>
<smd name="8" x="2.725" y="1.905" dx="1.551" dy="0.65" layer="1"/>
<text x="0" y="0" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="0" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-3.75" y1="2.739" x2="3.75" y2="2.739" width="0.05" layer="51"/>
<wire x1="3.75" y1="2.739" x2="3.75" y2="-2.739" width="0.05" layer="51"/>
<wire x1="3.75" y1="-2.739" x2="-3.75" y2="-2.739" width="0.05" layer="51"/>
<wire x1="-3.75" y1="-2.739" x2="-3.75" y2="2.739" width="0.05" layer="51"/>
<wire x1="-1.949" y1="2.444" x2="1.949" y2="2.444" width="0.1" layer="51"/>
<wire x1="1.949" y1="2.444" x2="1.949" y2="-2.444" width="0.1" layer="51"/>
<wire x1="1.949" y1="-2.444" x2="-1.949" y2="-2.444" width="0.1" layer="51"/>
<wire x1="-1.949" y1="-2.444" x2="-1.949" y2="2.444" width="0.1" layer="51"/>
<wire x1="-1.949" y1="1.174" x2="-0.679" y2="2.444" width="0.1" layer="51"/>
<wire x1="-1.599" y1="2.444" x2="1.599" y2="2.444" width="0.2" layer="21"/>
<wire x1="1.599" y1="2.444" x2="1.599" y2="-2.444" width="0.2" layer="21"/>
<wire x1="1.599" y1="-2.444" x2="-1.599" y2="-2.444" width="0.2" layer="21"/>
<wire x1="-1.599" y1="-2.444" x2="-1.599" y2="2.444" width="0.2" layer="21"/>
<wire x1="-3.5" y1="2.58" x2="-1.949" y2="2.58" width="0.2" layer="21"/>
</package>
</packages>
<symbols>
<symbol name="STM32F427VIT6">
<wire x1="5.08" y1="12.7" x2="71.12" y2="12.7" width="0.254" layer="94"/>
<wire x1="71.12" y1="-73.66" x2="71.12" y2="12.7" width="0.254" layer="94"/>
<wire x1="71.12" y1="-73.66" x2="5.08" y2="-73.66" width="0.254" layer="94"/>
<wire x1="5.08" y1="12.7" x2="5.08" y2="-73.66" width="0.254" layer="94"/>
<text x="72.39" y="17.78" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="72.39" y="15.24" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="PE2" x="0" y="0" length="middle"/>
<pin name="PE3" x="0" y="-2.54" length="middle"/>
<pin name="PE4" x="0" y="-5.08" length="middle"/>
<pin name="PE5" x="0" y="-7.62" length="middle"/>
<pin name="PE6" x="0" y="-10.16" length="middle"/>
<pin name="VBAT" x="0" y="-12.7" length="middle"/>
<pin name="PC13" x="0" y="-15.24" length="middle"/>
<pin name="PC14" x="0" y="-17.78" length="middle"/>
<pin name="PC15" x="0" y="-20.32" length="middle"/>
<pin name="VSS_1" x="0" y="-22.86" length="middle"/>
<pin name="VDD_1" x="0" y="-25.4" length="middle"/>
<pin name="PH0" x="0" y="-27.94" length="middle"/>
<pin name="PH1" x="0" y="-30.48" length="middle"/>
<pin name="NRST" x="0" y="-33.02" length="middle"/>
<pin name="PC0" x="0" y="-35.56" length="middle"/>
<pin name="PC1" x="0" y="-38.1" length="middle"/>
<pin name="PC2" x="0" y="-40.64" length="middle"/>
<pin name="PC3" x="0" y="-43.18" length="middle"/>
<pin name="VDD_2" x="0" y="-45.72" length="middle"/>
<pin name="VSSA" x="0" y="-48.26" length="middle"/>
<pin name="VREF+" x="0" y="-50.8" length="middle"/>
<pin name="VDDA" x="0" y="-53.34" length="middle"/>
<pin name="PA0" x="0" y="-55.88" length="middle"/>
<pin name="PA1" x="0" y="-58.42" length="middle"/>
<pin name="PA2" x="0" y="-60.96" length="middle"/>
<pin name="PA3" x="7.62" y="-78.74" length="middle" rot="R90"/>
<pin name="VSS_2" x="10.16" y="-78.74" length="middle" rot="R90"/>
<pin name="VDD_3" x="12.7" y="-78.74" length="middle" rot="R90"/>
<pin name="PA4" x="15.24" y="-78.74" length="middle" rot="R90"/>
<pin name="PA5" x="17.78" y="-78.74" length="middle" rot="R90"/>
<pin name="PA6" x="20.32" y="-78.74" length="middle" rot="R90"/>
<pin name="PA7" x="22.86" y="-78.74" length="middle" rot="R90"/>
<pin name="PC4" x="25.4" y="-78.74" length="middle" rot="R90"/>
<pin name="PC5" x="27.94" y="-78.74" length="middle" rot="R90"/>
<pin name="PB0" x="30.48" y="-78.74" length="middle" rot="R90"/>
<pin name="PB1" x="33.02" y="-78.74" length="middle" rot="R90"/>
<pin name="PB2" x="35.56" y="-78.74" length="middle" rot="R90"/>
<pin name="PE7" x="38.1" y="-78.74" length="middle" rot="R90"/>
<pin name="PE8" x="40.64" y="-78.74" length="middle" rot="R90"/>
<pin name="PE9" x="43.18" y="-78.74" length="middle" rot="R90"/>
<pin name="PE10" x="45.72" y="-78.74" length="middle" rot="R90"/>
<pin name="PE11" x="48.26" y="-78.74" length="middle" rot="R90"/>
<pin name="PE12" x="50.8" y="-78.74" length="middle" rot="R90"/>
<pin name="PE13" x="53.34" y="-78.74" length="middle" rot="R90"/>
<pin name="PE14" x="55.88" y="-78.74" length="middle" rot="R90"/>
<pin name="PE15" x="58.42" y="-78.74" length="middle" rot="R90"/>
<pin name="PB10" x="60.96" y="-78.74" length="middle" rot="R90"/>
<pin name="PB11" x="63.5" y="-78.74" length="middle" rot="R90"/>
<pin name="VCAP_1" x="66.04" y="-78.74" length="middle" rot="R90"/>
<pin name="VDD_4" x="68.58" y="-78.74" length="middle" rot="R90"/>
<pin name="VDD_5" x="76.2" y="0" length="middle" rot="R180"/>
<pin name="VSS_3" x="76.2" y="-2.54" length="middle" rot="R180"/>
<pin name="VCAP_2" x="76.2" y="-5.08" length="middle" rot="R180"/>
<pin name="PA13" x="76.2" y="-7.62" length="middle" rot="R180"/>
<pin name="PA12" x="76.2" y="-10.16" length="middle" rot="R180"/>
<pin name="PA11" x="76.2" y="-12.7" length="middle" rot="R180"/>
<pin name="PA10" x="76.2" y="-15.24" length="middle" rot="R180"/>
<pin name="PA9" x="76.2" y="-17.78" length="middle" rot="R180"/>
<pin name="PA8" x="76.2" y="-20.32" length="middle" rot="R180"/>
<pin name="PC9" x="76.2" y="-22.86" length="middle" rot="R180"/>
<pin name="PC8" x="76.2" y="-25.4" length="middle" rot="R180"/>
<pin name="PC7" x="76.2" y="-27.94" length="middle" rot="R180"/>
<pin name="PC6" x="76.2" y="-30.48" length="middle" rot="R180"/>
<pin name="PD15" x="76.2" y="-33.02" length="middle" rot="R180"/>
<pin name="PD14" x="76.2" y="-35.56" length="middle" rot="R180"/>
<pin name="PD13" x="76.2" y="-38.1" length="middle" rot="R180"/>
<pin name="PD12" x="76.2" y="-40.64" length="middle" rot="R180"/>
<pin name="PD11" x="76.2" y="-43.18" length="middle" rot="R180"/>
<pin name="PD10" x="76.2" y="-45.72" length="middle" rot="R180"/>
<pin name="PD9" x="76.2" y="-48.26" length="middle" rot="R180"/>
<pin name="PD8" x="76.2" y="-50.8" length="middle" rot="R180"/>
<pin name="PB15" x="76.2" y="-53.34" length="middle" rot="R180"/>
<pin name="PB14" x="76.2" y="-55.88" length="middle" rot="R180"/>
<pin name="PB13" x="76.2" y="-58.42" length="middle" rot="R180"/>
<pin name="PB12" x="76.2" y="-60.96" length="middle" rot="R180"/>
<pin name="VDD_6" x="7.62" y="17.78" length="middle" rot="R270"/>
<pin name="VSS_4" x="10.16" y="17.78" length="middle" rot="R270"/>
<pin name="PE1" x="12.7" y="17.78" length="middle" rot="R270"/>
<pin name="PE0" x="15.24" y="17.78" length="middle" rot="R270"/>
<pin name="PB9" x="17.78" y="17.78" length="middle" rot="R270"/>
<pin name="PB8" x="20.32" y="17.78" length="middle" rot="R270"/>
<pin name="BOOT0" x="22.86" y="17.78" length="middle" rot="R270"/>
<pin name="PB7" x="25.4" y="17.78" length="middle" rot="R270"/>
<pin name="PB6" x="27.94" y="17.78" length="middle" rot="R270"/>
<pin name="PB5" x="30.48" y="17.78" length="middle" rot="R270"/>
<pin name="PB4" x="33.02" y="17.78" length="middle" rot="R270"/>
<pin name="PB3" x="35.56" y="17.78" length="middle" rot="R270"/>
<pin name="PD7" x="38.1" y="17.78" length="middle" rot="R270"/>
<pin name="PD6" x="40.64" y="17.78" length="middle" rot="R270"/>
<pin name="PD5" x="43.18" y="17.78" length="middle" rot="R270"/>
<pin name="PD4" x="45.72" y="17.78" length="middle" rot="R270"/>
<pin name="PD3" x="48.26" y="17.78" length="middle" rot="R270"/>
<pin name="PD2" x="50.8" y="17.78" length="middle" rot="R270"/>
<pin name="PD1" x="53.34" y="17.78" length="middle" rot="R270"/>
<pin name="PD0" x="55.88" y="17.78" length="middle" rot="R270"/>
<pin name="PC12" x="58.42" y="17.78" length="middle" rot="R270"/>
<pin name="PC11" x="60.96" y="17.78" length="middle" rot="R270"/>
<pin name="PC10" x="63.5" y="17.78" length="middle" rot="R270"/>
<pin name="PA15" x="66.04" y="17.78" length="middle" rot="R270"/>
<pin name="PA14" x="68.58" y="17.78" length="middle" rot="R270"/>
</symbol>
<symbol name="MCP131T-300E_TT">
<wire x1="5.08" y1="2.54" x2="22.86" y2="2.54" width="0.254" layer="94"/>
<wire x1="22.86" y1="-5.08" x2="22.86" y2="2.54" width="0.254" layer="94"/>
<wire x1="22.86" y1="-5.08" x2="5.08" y2="-5.08" width="0.254" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-5.08" width="0.254" layer="94"/>
<text x="24.13" y="7.62" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="24.13" y="5.08" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="~RST" x="0" y="0" length="middle"/>
<pin name="VDD" x="0" y="-2.54" length="middle"/>
<pin name="VSS" x="27.94" y="0" length="middle" rot="R180"/>
</symbol>
<symbol name="CRMA1206AF10K0FKEF">
<wire x1="5.08" y1="1.27" x2="12.7" y2="1.27" width="0.254" layer="94"/>
<wire x1="12.7" y1="-1.27" x2="12.7" y2="1.27" width="0.254" layer="94"/>
<wire x1="12.7" y1="-1.27" x2="5.08" y2="-1.27" width="0.254" layer="94"/>
<wire x1="5.08" y1="1.27" x2="5.08" y2="-1.27" width="0.254" layer="94"/>
<text x="13.97" y="6.35" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="13.97" y="3.81" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="1" x="0" y="0" visible="pad" length="middle"/>
<pin name="2" x="17.78" y="0" visible="pad" length="middle" rot="R180"/>
</symbol>
<symbol name="4TPE220MBB">
<wire x1="5.08" y1="2.54" x2="5.08" y2="-2.54" width="0.254" layer="94"/>
<wire x1="5.842" y1="-2.54" x2="5.08" y2="-2.54" width="0.254" layer="94"/>
<wire x1="5.842" y1="-2.54" x2="5.842" y2="2.54" width="0.254" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.842" y2="2.54" width="0.254" layer="94"/>
<wire x1="4.572" y1="1.27" x2="3.556" y2="1.27" width="0.254" layer="94"/>
<wire x1="4.064" y1="1.778" x2="4.064" y2="0.762" width="0.254" layer="94"/>
<wire x1="2.54" y1="0" x2="5.08" y2="0" width="0.254" layer="94"/>
<wire x1="7.62" y1="0" x2="10.16" y2="0" width="0.254" layer="94"/>
<text x="8.89" y="6.35" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="8.89" y="3.81" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="+" x="0" y="0" visible="pad" length="short"/>
<pin name="-" x="12.7" y="0" visible="pad" length="short" rot="R180"/>
<polygon width="0.254" layer="94">
<vertex x="7.62" y="2.54"/>
<vertex x="7.62" y="-2.54"/>
<vertex x="6.858" y="-2.54"/>
<vertex x="6.858" y="2.54"/>
</polygon>
</symbol>
<symbol name="ICM-20948">
<wire x1="5.08" y1="17.78" x2="25.4" y2="17.78" width="0.254" layer="94"/>
<wire x1="25.4" y1="-30.48" x2="25.4" y2="17.78" width="0.254" layer="94"/>
<wire x1="25.4" y1="-30.48" x2="5.08" y2="-30.48" width="0.254" layer="94"/>
<wire x1="5.08" y1="17.78" x2="5.08" y2="-30.48" width="0.254" layer="94"/>
<text x="26.67" y="22.86" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="26.67" y="20.32" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="NC_1" x="0" y="0" length="middle"/>
<pin name="NC_2" x="0" y="-2.54" length="middle"/>
<pin name="NC_3" x="0" y="-5.08" length="middle"/>
<pin name="NC_4" x="0" y="-7.62" length="middle"/>
<pin name="NC_5" x="0" y="-10.16" length="middle"/>
<pin name="NC_6" x="0" y="-12.7" length="middle"/>
<pin name="AUX_CL" x="7.62" y="-35.56" length="middle" rot="R90"/>
<pin name="VDDIO" x="10.16" y="-35.56" length="middle" rot="R90"/>
<pin name="SDO_/_AD0" x="12.7" y="-35.56" length="middle" rot="R90"/>
<pin name="REGOUT" x="15.24" y="-35.56" length="middle" rot="R90"/>
<pin name="FSYNC" x="17.78" y="-35.56" length="middle" rot="R90"/>
<pin name="INT1" x="20.32" y="-35.56" length="middle" rot="R90"/>
<pin name="GND" x="30.48" y="0" length="middle" rot="R180"/>
<pin name="NC_10" x="30.48" y="-2.54" length="middle" rot="R180"/>
<pin name="NC_9" x="30.48" y="-5.08" length="middle" rot="R180"/>
<pin name="NC_8" x="30.48" y="-7.62" length="middle" rot="R180"/>
<pin name="NC_7" x="30.48" y="-10.16" length="middle" rot="R180"/>
<pin name="VDD" x="30.48" y="-12.7" length="middle" rot="R180"/>
<pin name="EP" x="7.62" y="22.86" length="middle" rot="R270"/>
<pin name="SDA_/_SDI" x="10.16" y="22.86" length="middle" rot="R270"/>
<pin name="SCL_/_SCLK" x="12.7" y="22.86" length="middle" rot="R270"/>
<pin name="NCS" x="15.24" y="22.86" length="middle" rot="R270"/>
<pin name="AUX_DA" x="17.78" y="22.86" length="middle" rot="R270"/>
<pin name="RESV_2" x="20.32" y="22.86" length="middle" rot="R270"/>
<pin name="RESV_1" x="22.86" y="22.86" length="middle" rot="R270"/>
</symbol>
<symbol name="MS561101BA03-50">
<wire x1="5.08" y1="2.54" x2="27.94" y2="2.54" width="0.254" layer="94"/>
<wire x1="27.94" y1="-10.16" x2="27.94" y2="2.54" width="0.254" layer="94"/>
<wire x1="27.94" y1="-10.16" x2="5.08" y2="-10.16" width="0.254" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-10.16" width="0.254" layer="94"/>
<text x="29.21" y="7.62" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="29.21" y="5.08" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="VDD" x="0" y="0" length="middle" direction="pwr"/>
<pin name="PS" x="0" y="-2.54" length="middle" direction="in"/>
<pin name="GND" x="0" y="-5.08" length="middle" direction="pwr"/>
<pin name="CSB_1" x="0" y="-7.62" length="middle" direction="in"/>
<pin name="CSB_2" x="33.02" y="-7.62" length="middle" direction="in" rot="R180"/>
<pin name="SDO" x="33.02" y="-5.08" length="middle" direction="out" rot="R180"/>
<pin name="SDI/SDA" x="33.02" y="-2.54" length="middle" rot="R180"/>
<pin name="SCLK" x="33.02" y="0" length="middle" direction="in" rot="R180"/>
</symbol>
<symbol name="NCP163ASN180T1G">
<wire x1="5.08" y1="2.54" x2="20.32" y2="2.54" width="0.254" layer="94"/>
<wire x1="20.32" y1="-7.62" x2="20.32" y2="2.54" width="0.254" layer="94"/>
<wire x1="20.32" y1="-7.62" x2="5.08" y2="-7.62" width="0.254" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-7.62" width="0.254" layer="94"/>
<text x="21.59" y="7.62" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="21.59" y="5.08" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="IN" x="0" y="0" length="middle"/>
<pin name="GND" x="0" y="-2.54" length="middle"/>
<pin name="EN" x="0" y="-5.08" length="middle"/>
<pin name="NC" x="25.4" y="0" length="middle" direction="nc" rot="R180"/>
<pin name="OUT" x="25.4" y="-2.54" length="middle" rot="R180"/>
</symbol>
<symbol name="FA-20H_24.0000MF20X-K3">
<wire x1="5.08" y1="2.54" x2="35.56" y2="2.54" width="0.254" layer="94"/>
<wire x1="35.56" y1="-5.08" x2="35.56" y2="2.54" width="0.254" layer="94"/>
<wire x1="35.56" y1="-5.08" x2="5.08" y2="-5.08" width="0.254" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-5.08" width="0.254" layer="94"/>
<text x="36.83" y="7.62" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="36.83" y="5.08" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="CRYSTAL_1" x="0" y="-2.54" length="middle"/>
<pin name="GND_1" x="40.64" y="-2.54" length="middle" rot="R180"/>
<pin name="CRYSTAL_2" x="40.64" y="0" length="middle" rot="R180"/>
<pin name="GND_2" x="0" y="0" length="middle"/>
</symbol>
<symbol name="47346-0001">
<wire x1="-2.54" y1="17.78" x2="12.7" y2="17.78" width="0.254" layer="94"/>
<wire x1="12.7" y1="5.08" x2="12.7" y2="17.78" width="0.254" layer="94"/>
<wire x1="12.7" y1="5.08" x2="-2.54" y2="5.08" width="0.254" layer="94"/>
<wire x1="-2.54" y1="17.78" x2="-2.54" y2="5.08" width="0.254" layer="94"/>
<text x="13.97" y="22.86" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="13.97" y="20.32" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="VBUS" x="10.16" y="0" length="middle" rot="R90"/>
<pin name="D-" x="7.62" y="0" length="middle" rot="R90"/>
<pin name="D+" x="5.08" y="0" length="middle" rot="R90"/>
<pin name="ID" x="2.54" y="0" length="middle" rot="R90"/>
<pin name="GND" x="0" y="0" length="middle" rot="R90"/>
</symbol>
<symbol name="SM06B-GHS-TB_LF__SN_">
<wire x1="5.08" y1="2.54" x2="15.24" y2="2.54" width="0.254" layer="94"/>
<wire x1="15.24" y1="-7.62" x2="15.24" y2="2.54" width="0.254" layer="94"/>
<wire x1="15.24" y1="-7.62" x2="5.08" y2="-7.62" width="0.254" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-7.62" width="0.254" layer="94"/>
<text x="16.51" y="7.62" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="16.51" y="5.08" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="1" x="0" y="0" length="middle"/>
<pin name="2" x="0" y="-2.54" length="middle"/>
<pin name="3" x="0" y="-5.08" length="middle"/>
<pin name="4" x="20.32" y="0" length="middle" rot="R180"/>
<pin name="5" x="20.32" y="-2.54" length="middle" rot="R180"/>
<pin name="6" x="20.32" y="-5.08" length="middle" rot="R180"/>
</symbol>
<symbol name="PJS008-2120-0">
<wire x1="5.08" y1="2.54" x2="33.02" y2="2.54" width="0.254" layer="94"/>
<wire x1="33.02" y1="-17.78" x2="33.02" y2="2.54" width="0.254" layer="94"/>
<wire x1="33.02" y1="-17.78" x2="5.08" y2="-17.78" width="0.254" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-17.78" width="0.254" layer="94"/>
<text x="34.29" y="7.62" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="34.29" y="5.08" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="1" x="0" y="0" length="middle"/>
<pin name="2" x="0" y="-2.54" length="middle"/>
<pin name="3" x="0" y="-5.08" length="middle"/>
<pin name="4" x="0" y="-7.62" length="middle"/>
<pin name="5" x="0" y="-10.16" length="middle"/>
<pin name="6" x="0" y="-12.7" length="middle"/>
<pin name="7" x="0" y="-15.24" length="middle"/>
<pin name="8" x="38.1" y="0" length="middle" rot="R180"/>
<pin name="GND_1" x="38.1" y="-2.54" length="middle" rot="R180"/>
<pin name="GND_2" x="38.1" y="-5.08" length="middle" rot="R180"/>
<pin name="GND_3" x="38.1" y="-7.62" length="middle" rot="R180"/>
<pin name="CARD_DETECT_SW1" x="38.1" y="-10.16" length="middle" rot="R180"/>
<pin name="MP1" x="38.1" y="-12.7" length="middle" rot="R180"/>
</symbol>
<symbol name="TJA1051TK_3,118">
<wire x1="5.08" y1="2.54" x2="22.86" y2="2.54" width="0.254" layer="94"/>
<wire x1="22.86" y1="-12.7" x2="22.86" y2="2.54" width="0.254" layer="94"/>
<wire x1="22.86" y1="-12.7" x2="5.08" y2="-12.7" width="0.254" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-12.7" width="0.254" layer="94"/>
<text x="24.13" y="7.62" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="24.13" y="5.08" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="TXD" x="0" y="0" length="middle"/>
<pin name="GND" x="0" y="-2.54" length="middle"/>
<pin name="VCC" x="0" y="-5.08" length="middle"/>
<pin name="RXD" x="0" y="-7.62" length="middle"/>
<pin name="VIO" x="0" y="-10.16" length="middle"/>
<pin name="CANL" x="27.94" y="0" length="middle" rot="R180"/>
<pin name="CANH" x="27.94" y="-2.54" length="middle" rot="R180"/>
<pin name="S" x="27.94" y="-5.08" length="middle" rot="R180"/>
<pin name="EP" x="27.94" y="-7.62" length="middle" rot="R180"/>
</symbol>
<symbol name="SM04B-GHS-TB_LF__SN_">
<wire x1="5.08" y1="2.54" x2="15.24" y2="2.54" width="0.254" layer="94"/>
<wire x1="15.24" y1="-5.08" x2="15.24" y2="2.54" width="0.254" layer="94"/>
<wire x1="15.24" y1="-5.08" x2="5.08" y2="-5.08" width="0.254" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-5.08" width="0.254" layer="94"/>
<text x="16.51" y="7.62" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="16.51" y="5.08" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="1" x="0" y="0" length="middle"/>
<pin name="2" x="0" y="-2.54" length="middle"/>
<pin name="3" x="20.32" y="0" length="middle" rot="R180"/>
<pin name="4" x="20.32" y="-2.54" length="middle" rot="R180"/>
</symbol>
<symbol name="SM05B-GHS-TB_LF__SN_">
<wire x1="5.08" y1="2.54" x2="15.24" y2="2.54" width="0.254" layer="94"/>
<wire x1="15.24" y1="-7.62" x2="15.24" y2="2.54" width="0.254" layer="94"/>
<wire x1="15.24" y1="-7.62" x2="5.08" y2="-7.62" width="0.254" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-7.62" width="0.254" layer="94"/>
<text x="16.51" y="7.62" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="16.51" y="5.08" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="1" x="0" y="0" length="middle"/>
<pin name="2" x="0" y="-2.54" length="middle"/>
<pin name="3" x="0" y="-5.08" length="middle"/>
<pin name="4" x="20.32" y="0" length="middle" rot="R180"/>
<pin name="5" x="20.32" y="-2.54" length="middle" rot="R180"/>
</symbol>
<symbol name="74LVC1G86SE-7">
<wire x1="5.08" y1="2.54" x2="20.32" y2="2.54" width="0.254" layer="94"/>
<wire x1="20.32" y1="-7.62" x2="20.32" y2="2.54" width="0.254" layer="94"/>
<wire x1="20.32" y1="-7.62" x2="5.08" y2="-7.62" width="0.254" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-7.62" width="0.254" layer="94"/>
<text x="21.59" y="7.62" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="21.59" y="5.08" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="A" x="0" y="0" length="middle"/>
<pin name="B" x="0" y="-2.54" length="middle"/>
<pin name="GND" x="0" y="-5.08" length="middle"/>
<pin name="Y" x="25.4" y="0" length="middle" rot="R180"/>
<pin name="VCC" x="25.4" y="-2.54" length="middle" rot="R180"/>
</symbol>
<symbol name="74LVC2G86DC,125">
<wire x1="5.08" y1="2.54" x2="20.32" y2="2.54" width="0.254" layer="94"/>
<wire x1="20.32" y1="-10.16" x2="20.32" y2="2.54" width="0.254" layer="94"/>
<wire x1="20.32" y1="-10.16" x2="5.08" y2="-10.16" width="0.254" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-10.16" width="0.254" layer="94"/>
<text x="21.59" y="7.62" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="21.59" y="5.08" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="1A" x="0" y="0" length="middle"/>
<pin name="1B" x="0" y="-2.54" length="middle"/>
<pin name="2Y" x="0" y="-5.08" length="middle"/>
<pin name="GND" x="0" y="-7.62" length="middle"/>
<pin name="VCC" x="25.4" y="0" length="middle" rot="R180"/>
<pin name="1Y" x="25.4" y="-2.54" length="middle" rot="R180"/>
<pin name="2B" x="25.4" y="-5.08" length="middle" rot="R180"/>
<pin name="2A" x="25.4" y="-7.62" length="middle" rot="R180"/>
</symbol>
<symbol name="SM06B-SRSS-TB__LF__SN_">
<wire x1="5.08" y1="2.54" x2="15.24" y2="2.54" width="0.254" layer="94"/>
<wire x1="15.24" y1="-7.62" x2="15.24" y2="2.54" width="0.254" layer="94"/>
<wire x1="15.24" y1="-7.62" x2="5.08" y2="-7.62" width="0.254" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-7.62" width="0.254" layer="94"/>
<text x="16.51" y="7.62" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="16.51" y="5.08" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="1" x="0" y="0" length="middle"/>
<pin name="2" x="0" y="-2.54" length="middle"/>
<pin name="3" x="0" y="-5.08" length="middle"/>
<pin name="4" x="20.32" y="0" length="middle" rot="R180"/>
<pin name="5" x="20.32" y="-2.54" length="middle" rot="R180"/>
<pin name="6" x="20.32" y="-5.08" length="middle" rot="R180"/>
</symbol>
<symbol name="PMEG2020CPASX">
<wire x1="5.08" y1="2.54" x2="20.32" y2="2.54" width="0.254" layer="94"/>
<wire x1="20.32" y1="-5.08" x2="20.32" y2="2.54" width="0.254" layer="94"/>
<wire x1="20.32" y1="-5.08" x2="5.08" y2="-5.08" width="0.254" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-5.08" width="0.254" layer="94"/>
<text x="21.59" y="7.62" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="21.59" y="5.08" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="A1" x="0" y="0" length="middle"/>
<pin name="A2" x="0" y="-2.54" length="middle"/>
<pin name="K_1" x="25.4" y="0" length="middle" rot="R180"/>
<pin name="K_2" x="25.4" y="-2.54" length="middle" rot="R180"/>
</symbol>
<symbol name="APG1608ZGCK">
<wire x1="5.08" y1="2.54" x2="5.08" y2="-2.54" width="0.254" layer="94"/>
<wire x1="6.35" y1="2.54" x2="3.81" y2="5.08" width="0.254" layer="94"/>
<wire x1="8.89" y1="2.54" x2="6.35" y2="5.08" width="0.254" layer="94"/>
<wire x1="2.54" y1="0" x2="5.08" y2="0" width="0.254" layer="94"/>
<wire x1="10.16" y1="0" x2="12.7" y2="0" width="0.254" layer="94"/>
<text x="12.7" y="8.89" size="1.778" layer="95">&gt;NAME</text>
<text x="12.7" y="6.35" size="1.778" layer="96">&gt;VALUE</text>
<pin name="K" x="0" y="0" visible="pad" length="short"/>
<pin name="A" x="15.24" y="0" visible="pad" length="short" rot="R180"/>
<polygon width="0.254" layer="94">
<vertex x="5.08" y="0"/>
<vertex x="10.16" y="2.54"/>
<vertex x="10.16" y="-2.54"/>
</polygon>
<polygon width="0.254" layer="94">
<vertex x="5.334" y="4.318"/>
<vertex x="4.572" y="3.556"/>
<vertex x="3.81" y="5.08"/>
</polygon>
<polygon width="0.254" layer="94">
<vertex x="7.874" y="4.318"/>
<vertex x="7.112" y="3.556"/>
<vertex x="6.35" y="5.08"/>
</polygon>
</symbol>
<symbol name="PMEG1030EJ,115">
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="8.636" y2="2.54" width="0.254" layer="94"/>
<wire x1="8.636" y1="1.524" x2="8.636" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="6.604" y2="-2.54" width="0.254" layer="94"/>
<wire x1="6.604" y1="-1.524" x2="6.604" y2="-2.54" width="0.254" layer="94"/>
<wire x1="5.08" y1="0" x2="7.62" y2="0" width="0.254" layer="94"/>
<wire x1="12.7" y1="0" x2="15.24" y2="0" width="0.254" layer="94"/>
<text x="12.7" y="8.89" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="12.7" y="6.35" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="K" x="2.54" y="0" visible="pad" length="short"/>
<pin name="A" x="17.78" y="0" visible="pad" length="short" rot="R180"/>
<polygon width="0.254" layer="94">
<vertex x="7.62" y="0"/>
<vertex x="12.7" y="2.54"/>
<vertex x="12.7" y="-2.54"/>
</polygon>
</symbol>
<symbol name="0603L100SLYR">
<wire x1="5.08" y1="1.27" x2="12.7" y2="1.27" width="0.254" layer="94"/>
<wire x1="12.7" y1="-1.27" x2="12.7" y2="1.27" width="0.254" layer="94"/>
<wire x1="12.7" y1="-1.27" x2="5.08" y2="-1.27" width="0.254" layer="94"/>
<wire x1="5.08" y1="1.27" x2="5.08" y2="-1.27" width="0.254" layer="94"/>
<wire x1="5.588" y1="-2.032" x2="7.112" y2="-2.032" width="0.254" layer="94"/>
<wire x1="10.668" y1="2.032" x2="7.112" y2="-2.032" width="0.254" layer="94"/>
<wire x1="10.668" y1="2.032" x2="12.192" y2="2.032" width="0.254" layer="94"/>
<text x="13.97" y="6.35" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="13.97" y="3.81" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="1" x="0" y="0" visible="pad" length="middle"/>
<pin name="2" x="17.78" y="0" visible="pad" length="middle" rot="R180"/>
</symbol>
<symbol name="1N4448X-TP">
<wire x1="5.08" y1="2.54" x2="5.08" y2="-2.54" width="0.254" layer="94"/>
<wire x1="2.54" y1="0" x2="5.08" y2="0" width="0.254" layer="94"/>
<wire x1="10.16" y1="0" x2="12.7" y2="0" width="0.254" layer="94"/>
<text x="11.43" y="5.08" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="11.43" y="2.54" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="K" x="0" y="0" visible="pad" length="short"/>
<pin name="A" x="15.24" y="0" visible="pad" length="short" rot="R180"/>
<polygon width="0.254" layer="94">
<vertex x="5.08" y="0"/>
<vertex x="10.16" y="2.54"/>
<vertex x="10.16" y="-2.54"/>
</polygon>
</symbol>
<symbol name="LTST-C19HE1WT">
<wire x1="5.08" y1="2.54" x2="30.48" y2="2.54" width="0.254" layer="94"/>
<wire x1="30.48" y1="-5.08" x2="30.48" y2="2.54" width="0.254" layer="94"/>
<wire x1="30.48" y1="-5.08" x2="5.08" y2="-5.08" width="0.254" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-5.08" width="0.254" layer="94"/>
<text x="31.75" y="7.62" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="31.75" y="5.08" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="RED" x="0" y="0" length="middle"/>
<pin name="GREEN" x="35.56" y="0" length="middle" rot="R180"/>
<pin name="BLUE" x="35.56" y="-2.54" length="middle" rot="R180"/>
<pin name="POLARITY" x="0" y="-2.54" length="middle"/>
</symbol>
<symbol name="AP7365-33WG-7">
<wire x1="5.08" y1="2.54" x2="20.32" y2="2.54" width="0.254" layer="94"/>
<wire x1="20.32" y1="-7.62" x2="20.32" y2="2.54" width="0.254" layer="94"/>
<wire x1="20.32" y1="-7.62" x2="5.08" y2="-7.62" width="0.254" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-7.62" width="0.254" layer="94"/>
<text x="21.59" y="7.62" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="21.59" y="5.08" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="IN" x="0" y="0" length="middle"/>
<pin name="GND" x="0" y="-2.54" length="middle"/>
<pin name="EN" x="0" y="-5.08" length="middle"/>
<pin name="ADJ" x="25.4" y="0" length="middle" rot="R180"/>
<pin name="OUT" x="25.4" y="-2.54" length="middle" rot="R180"/>
</symbol>
<symbol name="CDBU70">
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="8.636" y2="2.54" width="0.254" layer="94"/>
<wire x1="8.636" y1="1.524" x2="8.636" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="6.604" y2="-2.54" width="0.254" layer="94"/>
<wire x1="6.604" y1="-1.524" x2="6.604" y2="-2.54" width="0.254" layer="94"/>
<wire x1="5.08" y1="0" x2="7.62" y2="0" width="0.254" layer="94"/>
<wire x1="12.7" y1="0" x2="15.24" y2="0" width="0.254" layer="94"/>
<text x="12.7" y="8.89" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="12.7" y="6.35" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="K" x="2.54" y="0" visible="pad" length="short"/>
<pin name="A" x="17.78" y="0" visible="pad" length="short" rot="R180"/>
<polygon width="0.254" layer="94">
<vertex x="7.62" y="0"/>
<vertex x="12.7" y="2.54"/>
<vertex x="12.7" y="-2.54"/>
</polygon>
</symbol>
<symbol name="W2H13C1048AT1F">
<wire x1="5.08" y1="15.24" x2="45.72" y2="15.24" width="0.254" layer="94"/>
<wire x1="45.72" y1="-15.24" x2="45.72" y2="15.24" width="0.254" layer="94"/>
<wire x1="45.72" y1="-15.24" x2="5.08" y2="-15.24" width="0.254" layer="94"/>
<wire x1="5.08" y1="15.24" x2="5.08" y2="-15.24" width="0.254" layer="94"/>
<text x="46.99" y="20.32" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="46.99" y="17.78" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="SIGNAL/VCC_1" x="0" y="0" length="middle"/>
<pin name="SIGNAL/VCC_2" x="50.8" y="0" length="middle" rot="R180"/>
<pin name="GROUND_1" x="25.4" y="20.32" length="middle" rot="R270"/>
<pin name="GROUND_2" x="25.4" y="-20.32" length="middle" rot="R90"/>
</symbol>
<symbol name="XP151A12A2MR-G">
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="5.08" x2="7.62" y2="7.62" width="0.254" layer="94"/>
<wire x1="2.54" y1="0" x2="5.08" y2="0" width="0.254" layer="94"/>
<wire x1="5.08" y1="5.08" x2="5.08" y2="0" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="5.842" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="5.08" x2="5.842" y2="5.08" width="0.254" layer="94"/>
<wire x1="5.842" y1="0" x2="7.62" y2="0" width="0.254" layer="94"/>
<wire x1="5.842" y1="5.588" x2="5.842" y2="4.572" width="0.254" layer="94"/>
<wire x1="5.842" y1="-0.508" x2="5.842" y2="0.508" width="0.254" layer="94"/>
<wire x1="5.842" y1="2.032" x2="5.842" y2="3.048" width="0.254" layer="94"/>
<circle x="6.35" y="2.54" radius="3.81" width="0.254" layer="94"/>
<text x="11.43" y="3.81" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="11.43" y="1.27" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="G" x="0" y="0" visible="pad" length="short"/>
<pin name="D" x="7.62" y="10.16" visible="pad" length="short" rot="R270"/>
<pin name="S" x="7.62" y="-5.08" visible="pad" length="short" rot="R90"/>
<polygon width="0.254" layer="94">
<vertex x="5.842" y="2.54"/>
<vertex x="6.858" y="3.048"/>
<vertex x="6.858" y="2.032"/>
</polygon>
</symbol>
<symbol name="BSS209PW_H6327">
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="5.08" x2="7.62" y2="7.62" width="0.254" layer="94"/>
<wire x1="2.54" y1="0" x2="5.08" y2="0" width="0.254" layer="94"/>
<wire x1="5.08" y1="5.08" x2="5.08" y2="0" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="5.842" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="5.08" x2="5.842" y2="5.08" width="0.254" layer="94"/>
<wire x1="5.842" y1="0" x2="7.62" y2="0" width="0.254" layer="94"/>
<wire x1="5.842" y1="5.588" x2="5.842" y2="4.572" width="0.254" layer="94"/>
<wire x1="5.842" y1="-0.508" x2="5.842" y2="0.508" width="0.254" layer="94"/>
<wire x1="5.842" y1="2.032" x2="5.842" y2="3.048" width="0.254" layer="94"/>
<circle x="6.35" y="2.54" radius="3.81" width="0.254" layer="94"/>
<text x="11.43" y="3.81" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="11.43" y="1.27" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="G" x="0" y="0" visible="pad" length="short"/>
<pin name="D" x="7.62" y="10.16" visible="pad" length="short" rot="R270"/>
<pin name="S" x="7.62" y="-5.08" visible="pad" length="short" rot="R90"/>
<polygon width="0.254" layer="94">
<vertex x="7.62" y="2.54"/>
<vertex x="6.604" y="3.048"/>
<vertex x="6.604" y="2.032"/>
</polygon>
</symbol>
<symbol name="ICM-20602">
<wire x1="5.08" y1="12.7" x2="30.48" y2="12.7" width="0.254" layer="94"/>
<wire x1="30.48" y1="-22.86" x2="30.48" y2="12.7" width="0.254" layer="94"/>
<wire x1="30.48" y1="-22.86" x2="5.08" y2="-22.86" width="0.254" layer="94"/>
<wire x1="5.08" y1="12.7" x2="5.08" y2="-22.86" width="0.254" layer="94"/>
<text x="31.75" y="17.78" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="31.75" y="15.24" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="VDDIO" x="0" y="0" length="middle"/>
<pin name="SCL/SPC" x="0" y="-2.54" length="middle"/>
<pin name="SDA/SDI" x="0" y="-5.08" length="middle"/>
<pin name="SA0/SDO" x="0" y="-7.62" length="middle"/>
<pin name="CS" x="0" y="-10.16" length="middle"/>
<pin name="INT" x="15.24" y="-27.94" length="middle" rot="R90"/>
<pin name="RESV_1" x="17.78" y="-27.94" length="middle" rot="R90"/>
<pin name="FSYNC" x="20.32" y="-27.94" length="middle" rot="R90"/>
<pin name="RESV_2" x="35.56" y="-10.16" length="middle" rot="R180"/>
<pin name="RESV_3" x="35.56" y="-7.62" length="middle" rot="R180"/>
<pin name="RESV_4" x="35.56" y="-5.08" length="middle" rot="R180"/>
<pin name="RESV_5" x="35.56" y="-2.54" length="middle" rot="R180"/>
<pin name="GND" x="35.56" y="0" length="middle" rot="R180"/>
<pin name="REGOUT" x="20.32" y="17.78" length="middle" rot="R270"/>
<pin name="RESV_6" x="17.78" y="17.78" length="middle" rot="R270"/>
<pin name="VDD" x="15.24" y="17.78" length="middle" rot="R270"/>
</symbol>
<symbol name="FM25V02A-GTR">
<wire x1="5.08" y1="2.54" x2="22.86" y2="2.54" width="0.254" layer="94"/>
<wire x1="22.86" y1="-10.16" x2="22.86" y2="2.54" width="0.254" layer="94"/>
<wire x1="22.86" y1="-10.16" x2="5.08" y2="-10.16" width="0.254" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-10.16" width="0.254" layer="94"/>
<text x="24.13" y="7.62" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="24.13" y="5.08" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="!CS" x="0" y="0" length="middle"/>
<pin name="SO" x="0" y="-2.54" length="middle"/>
<pin name="!WP" x="0" y="-5.08" length="middle"/>
<pin name="VSS" x="0" y="-7.62" length="middle"/>
<pin name="VDD" x="27.94" y="0" length="middle" rot="R180"/>
<pin name="!HOLD" x="27.94" y="-2.54" length="middle" rot="R180"/>
<pin name="SCK" x="27.94" y="-5.08" length="middle" rot="R180"/>
<pin name="SI" x="27.94" y="-7.62" length="middle" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="STM32F427VIT6" prefix="IC">
<description>&lt;b&gt;NewSTM32F427VIT6 32bit ARM Cortex M4 MCU, 180MHz, 2048 kB Flash, 256 (System) kB, 4 (Backup) kB RAM, 100-pin LQFP&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://datasheet.datasheetarchive.com/originals/distributors/Datasheets-DGA25/1728510.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="STM32F427VIT6" x="0" y="0"/>
</gates>
<devices>
<device name="" package="QFP50P1600X1600X160-100N">
<connects>
<connect gate="G$1" pin="BOOT0" pad="94"/>
<connect gate="G$1" pin="NRST" pad="14"/>
<connect gate="G$1" pin="PA0" pad="23"/>
<connect gate="G$1" pin="PA1" pad="24"/>
<connect gate="G$1" pin="PA10" pad="69"/>
<connect gate="G$1" pin="PA11" pad="70"/>
<connect gate="G$1" pin="PA12" pad="71"/>
<connect gate="G$1" pin="PA13" pad="72"/>
<connect gate="G$1" pin="PA14" pad="76"/>
<connect gate="G$1" pin="PA15" pad="77"/>
<connect gate="G$1" pin="PA2" pad="25"/>
<connect gate="G$1" pin="PA3" pad="26"/>
<connect gate="G$1" pin="PA4" pad="29"/>
<connect gate="G$1" pin="PA5" pad="30"/>
<connect gate="G$1" pin="PA6" pad="31"/>
<connect gate="G$1" pin="PA7" pad="32"/>
<connect gate="G$1" pin="PA8" pad="67"/>
<connect gate="G$1" pin="PA9" pad="68"/>
<connect gate="G$1" pin="PB0" pad="35"/>
<connect gate="G$1" pin="PB1" pad="36"/>
<connect gate="G$1" pin="PB10" pad="47"/>
<connect gate="G$1" pin="PB11" pad="48"/>
<connect gate="G$1" pin="PB12" pad="51"/>
<connect gate="G$1" pin="PB13" pad="52"/>
<connect gate="G$1" pin="PB14" pad="53"/>
<connect gate="G$1" pin="PB15" pad="54"/>
<connect gate="G$1" pin="PB2" pad="37"/>
<connect gate="G$1" pin="PB3" pad="89"/>
<connect gate="G$1" pin="PB4" pad="90"/>
<connect gate="G$1" pin="PB5" pad="91"/>
<connect gate="G$1" pin="PB6" pad="92"/>
<connect gate="G$1" pin="PB7" pad="93"/>
<connect gate="G$1" pin="PB8" pad="95"/>
<connect gate="G$1" pin="PB9" pad="96"/>
<connect gate="G$1" pin="PC0" pad="15"/>
<connect gate="G$1" pin="PC1" pad="16"/>
<connect gate="G$1" pin="PC10" pad="78"/>
<connect gate="G$1" pin="PC11" pad="79"/>
<connect gate="G$1" pin="PC12" pad="80"/>
<connect gate="G$1" pin="PC13" pad="7"/>
<connect gate="G$1" pin="PC14" pad="8"/>
<connect gate="G$1" pin="PC15" pad="9"/>
<connect gate="G$1" pin="PC2" pad="17"/>
<connect gate="G$1" pin="PC3" pad="18"/>
<connect gate="G$1" pin="PC4" pad="33"/>
<connect gate="G$1" pin="PC5" pad="34"/>
<connect gate="G$1" pin="PC6" pad="63"/>
<connect gate="G$1" pin="PC7" pad="64"/>
<connect gate="G$1" pin="PC8" pad="65"/>
<connect gate="G$1" pin="PC9" pad="66"/>
<connect gate="G$1" pin="PD0" pad="81"/>
<connect gate="G$1" pin="PD1" pad="82"/>
<connect gate="G$1" pin="PD10" pad="57"/>
<connect gate="G$1" pin="PD11" pad="58"/>
<connect gate="G$1" pin="PD12" pad="59"/>
<connect gate="G$1" pin="PD13" pad="60"/>
<connect gate="G$1" pin="PD14" pad="61"/>
<connect gate="G$1" pin="PD15" pad="62"/>
<connect gate="G$1" pin="PD2" pad="83"/>
<connect gate="G$1" pin="PD3" pad="84"/>
<connect gate="G$1" pin="PD4" pad="85"/>
<connect gate="G$1" pin="PD5" pad="86"/>
<connect gate="G$1" pin="PD6" pad="87"/>
<connect gate="G$1" pin="PD7" pad="88"/>
<connect gate="G$1" pin="PD8" pad="55"/>
<connect gate="G$1" pin="PD9" pad="56"/>
<connect gate="G$1" pin="PE0" pad="97"/>
<connect gate="G$1" pin="PE1" pad="98"/>
<connect gate="G$1" pin="PE10" pad="41"/>
<connect gate="G$1" pin="PE11" pad="42"/>
<connect gate="G$1" pin="PE12" pad="43"/>
<connect gate="G$1" pin="PE13" pad="44"/>
<connect gate="G$1" pin="PE14" pad="45"/>
<connect gate="G$1" pin="PE15" pad="46"/>
<connect gate="G$1" pin="PE2" pad="1"/>
<connect gate="G$1" pin="PE3" pad="2"/>
<connect gate="G$1" pin="PE4" pad="3"/>
<connect gate="G$1" pin="PE5" pad="4"/>
<connect gate="G$1" pin="PE6" pad="5"/>
<connect gate="G$1" pin="PE7" pad="38"/>
<connect gate="G$1" pin="PE8" pad="39"/>
<connect gate="G$1" pin="PE9" pad="40"/>
<connect gate="G$1" pin="PH0" pad="12"/>
<connect gate="G$1" pin="PH1" pad="13"/>
<connect gate="G$1" pin="VBAT" pad="6"/>
<connect gate="G$1" pin="VCAP_1" pad="49"/>
<connect gate="G$1" pin="VCAP_2" pad="73"/>
<connect gate="G$1" pin="VDDA" pad="22"/>
<connect gate="G$1" pin="VDD_1" pad="11"/>
<connect gate="G$1" pin="VDD_2" pad="19"/>
<connect gate="G$1" pin="VDD_3" pad="28"/>
<connect gate="G$1" pin="VDD_4" pad="50"/>
<connect gate="G$1" pin="VDD_5" pad="75"/>
<connect gate="G$1" pin="VDD_6" pad="100"/>
<connect gate="G$1" pin="VREF+" pad="21"/>
<connect gate="G$1" pin="VSSA" pad="20"/>
<connect gate="G$1" pin="VSS_1" pad="10"/>
<connect gate="G$1" pin="VSS_2" pad="27"/>
<connect gate="G$1" pin="VSS_3" pad="74"/>
<connect gate="G$1" pin="VSS_4" pad="99"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="NewSTM32F427VIT6 32bit ARM Cortex M4 MCU, 180MHz, 2048 kB Flash, 256 (System) kB, 4 (Backup) kB RAM, 100-pin LQFP" constant="no"/>
<attribute name="HEIGHT" value="1.6mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="STMicroelectronics" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="STM32F427VIT6" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="511-STM32F427VIT6" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/STMicroelectronics/STM32F427VIT6?qs=GlLcxsc1hfFxlQzXIfPRUw%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="MCP131T-300E_TT" prefix="IC">
<description>&lt;b&gt;Microchip MCP131T-300E/TT, Voltage Supervisor 2.857  3.003 V, 3-Pin SOT-23B&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://componentsearchengine.com/Datasheets/1/MCP131T-300E_TT.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="MCP131T-300E_TT" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SOT95P237X112-3N">
<connects>
<connect gate="G$1" pin="VDD" pad="2"/>
<connect gate="G$1" pin="VSS" pad="3"/>
<connect gate="G$1" pin="~RST" pad="1"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="Microchip MCP131T-300E/TT, Voltage Supervisor 2.857  3.003 V, 3-Pin SOT-23B" constant="no"/>
<attribute name="HEIGHT" value="mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Microchip" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="MCP131T-300E/TT" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="579-MCP131T-300E/TT" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.com/Search/Refine.aspx?Keyword=579-MCP131T-300E%2FTT" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="CRMA1206AF10K0FKEF" prefix="R">
<description>&lt;b&gt;Thick Film Resistors - SMD 0.30W 10Kohm 1% AEC-Q200&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://componentsearchengine.com/Datasheets/2/CRMA1206AF10K0FKEF.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="CRMA1206AF10K0FKEF" x="0" y="0"/>
</gates>
<devices>
<device name="" package="RESC3216X74N">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="Thick Film Resistors - SMD 0.30W 10Kohm 1% AEC-Q200" constant="no"/>
<attribute name="HEIGHT" value="0.74mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Vishay" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="CRMA1206AF10K0FKEF" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="71-CRMA1206AF10K0FKF" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/Vishay/CRMA1206AF10K0FKEF?qs=TiOZkKH1s2Q81nOs5FD1Wg%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="4TPE220MBB" prefix="C">
<description>&lt;b&gt;Tantalum Capacitors - Polymer 4VDC 220uF 20% ESR 70mOhm&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://industrial.panasonic.com/cdbs/www-data/pdf/AAA8000/AAA8000C36.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="4TPE220MBB" x="0" y="0"/>
</gates>
<devices>
<device name="" package="4TPE220MBB">
<connects>
<connect gate="G$1" pin="+" pad="1"/>
<connect gate="G$1" pin="-" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="Tantalum Capacitors - Polymer 4VDC 220uF 20% ESR 70mOhm" constant="no"/>
<attribute name="HEIGHT" value="2mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Panasonic" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="4TPE220MBB" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="667-4TPE220MBB" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/Panasonic/4TPE220MBB?qs=4qgZ1GHix0V27BnmRtQYow%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="ICM-20948" prefix="IC">
<description>&lt;b&gt;IMUs - Inertial Measurement Units World's Lowest Power 9-Axis MEMS MotionTracking Device&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://product.tdk.com/system/files/dam/doc/product/sensor/mortion-inertial/imu/data_sheet/ds-000189-icm-20948-v1.3.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="ICM-20948" x="0" y="0"/>
</gates>
<devices>
<device name="" package="QFN40P300X300X105-25N">
<connects>
<connect gate="G$1" pin="AUX_CL" pad="7"/>
<connect gate="G$1" pin="AUX_DA" pad="21"/>
<connect gate="G$1" pin="EP" pad="25"/>
<connect gate="G$1" pin="FSYNC" pad="11"/>
<connect gate="G$1" pin="GND" pad="18"/>
<connect gate="G$1" pin="INT1" pad="12"/>
<connect gate="G$1" pin="NCS" pad="22"/>
<connect gate="G$1" pin="NC_1" pad="1"/>
<connect gate="G$1" pin="NC_10" pad="17"/>
<connect gate="G$1" pin="NC_2" pad="2"/>
<connect gate="G$1" pin="NC_3" pad="3"/>
<connect gate="G$1" pin="NC_4" pad="4"/>
<connect gate="G$1" pin="NC_5" pad="5"/>
<connect gate="G$1" pin="NC_6" pad="6"/>
<connect gate="G$1" pin="NC_7" pad="14"/>
<connect gate="G$1" pin="NC_8" pad="15"/>
<connect gate="G$1" pin="NC_9" pad="16"/>
<connect gate="G$1" pin="REGOUT" pad="10"/>
<connect gate="G$1" pin="RESV_1" pad="19"/>
<connect gate="G$1" pin="RESV_2" pad="20"/>
<connect gate="G$1" pin="SCL_/_SCLK" pad="23"/>
<connect gate="G$1" pin="SDA_/_SDI" pad="24"/>
<connect gate="G$1" pin="SDO_/_AD0" pad="9"/>
<connect gate="G$1" pin="VDD" pad="13"/>
<connect gate="G$1" pin="VDDIO" pad="8"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="IMUs - Inertial Measurement Units World's Lowest Power 9-Axis MEMS MotionTracking Device" constant="no"/>
<attribute name="HEIGHT" value="1.05mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="TDK" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="ICM-20948" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="410-ICM-20948" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/TDK-InvenSense/ICM-20948?qs=u4fy%2FsgLU9OtGc31yF%2Friw%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="MS561101BA03-50" prefix="IC">
<description>&lt;b&gt;Sensor Pressure 1.2bar Barometric SMD MS561101BA03-50, Barometric Pressure Sensor, 1200mbar 0  3.6 V Output, 8-Pin QFN&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="http://www.te.com/usa-en/search.html?q=ms5611&amp;source=header"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="MS561101BA03-50" x="0" y="0"/>
</gates>
<devices>
<device name="" package="MS561101BA03-50">
<connects>
<connect gate="G$1" pin="CSB_1" pad="4"/>
<connect gate="G$1" pin="CSB_2" pad="5"/>
<connect gate="G$1" pin="GND" pad="3"/>
<connect gate="G$1" pin="PS" pad="2"/>
<connect gate="G$1" pin="SCLK" pad="8"/>
<connect gate="G$1" pin="SDI/SDA" pad="7"/>
<connect gate="G$1" pin="SDO" pad="6"/>
<connect gate="G$1" pin="VDD" pad="1"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="Sensor Pressure 1.2bar Barometric SMD MS561101BA03-50, Barometric Pressure Sensor, 1200mbar 0  3.6 V Output, 8-Pin QFN" constant="no"/>
<attribute name="HEIGHT" value="mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="TE Connectivity" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="MS561101BA03-50" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="824-MS561101BA03-50" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/Measurement-Specialties/MS561101BA03-50?qs=%252BgKeJhng5iV%252BnCz6Qd5iDw%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="NCP163ASN180T1G" prefix="IC">
<description>&lt;b&gt;LDO Voltage Regulators LDO Reg, Ultra-Low Noise High PSRR 1.8V&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://componentsearchengine.com/Datasheets/1/NCP163ASN180T1G.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="NCP163ASN180T1G" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SOT95P280X145-5N">
<connects>
<connect gate="G$1" pin="EN" pad="3"/>
<connect gate="G$1" pin="GND" pad="2"/>
<connect gate="G$1" pin="IN" pad="1"/>
<connect gate="G$1" pin="NC" pad="4"/>
<connect gate="G$1" pin="OUT" pad="5"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="LDO Voltage Regulators LDO Reg, Ultra-Low Noise High PSRR 1.8V" constant="no"/>
<attribute name="HEIGHT" value="1.45mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="onsemi" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="NCP163ASN180T1G" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="863-NCP163ASN180T1G" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/onsemi/NCP163ASN180T1G?qs=vLWxofP3U2z0o2tJM%252BNAYw%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="FA-20H_24.0000MF20X-K3" prefix="Y">
<description>&lt;b&gt;&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://support.epson.biz/td/api/doc_check.php?dl=brief_FA-20H&amp;lang=en"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="FA-20H_24.0000MF20X-K3" x="0" y="0"/>
</gates>
<devices>
<device name="" package="FA20H160000MF12ZAC3">
<connects>
<connect gate="G$1" pin="CRYSTAL_1" pad="1"/>
<connect gate="G$1" pin="CRYSTAL_2" pad="3"/>
<connect gate="G$1" pin="GND_1" pad="2"/>
<connect gate="G$1" pin="GND_2" pad="4"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="" constant="no"/>
<attribute name="HEIGHT" value="0.55mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Epson Timing" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="FA-20H 24.0000MF20X-K3" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="732-FA20H-24F20X-K3" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/Epson-Timing/FA-20H-240000MF20X-K3?qs=CANAagUtPAp2w31393daZQ%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="47346-0001" prefix="J">
<description>&lt;b&gt;Micro USB B Receptacle Bottom Mount Assy Molex Right Angle SMT Type B Version 2.0 Micro USB Connector Socket, 30 V ac, 1A 47352 MICRO-USB&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="http://www.molex.com/pdm_docs/sd/473460001_sd.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="47346-0001" x="0" y="0"/>
</gates>
<devices>
<device name="" package="47346-0001">
<connects>
<connect gate="G$1" pin="D+" pad="3"/>
<connect gate="G$1" pin="D-" pad="2"/>
<connect gate="G$1" pin="GND" pad="5"/>
<connect gate="G$1" pin="ID" pad="4"/>
<connect gate="G$1" pin="VBUS" pad="1"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="Micro USB B Receptacle Bottom Mount Assy Molex Right Angle SMT Type B Version 2.0 Micro USB Connector Socket, 30 V ac, 1A 47352 MICRO-USB" constant="no"/>
<attribute name="HEIGHT" value="mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Molex" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="47346-0001" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="538-47346-0001" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/Molex/47346-0001?qs=c2CV6XM0DweJBWaSeyWeCw%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="SM06B-GHS-TB_LF__SN_" prefix="J">
<description>&lt;b&gt;GH 1.25mm header side entry 6 way JST GH Series, 1.25mm Pitch 6 Way Right Angle PCB Header, Solder Termination, 1A&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="http://uk.rs-online.com/web/p/products/7521800P"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="SM06B-GHS-TB_LF__SN_" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SM06B-GHS-TB">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="GH 1.25mm header side entry 6 way JST GH Series, 1.25mm Pitch 6 Way Right Angle PCB Header, Solder Termination, 1A" constant="no"/>
<attribute name="HEIGHT" value="mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="JST (JAPAN SOLDERLESS TERMINALS)" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="SM06B-GHS-TB(LF)(SN)" constant="no"/>
<attribute name="RS_PART_NUMBER" value="7521800P" constant="no"/>
<attribute name="RS_PRICE-STOCK" value="http://uk.rs-online.com/web/p/products/7521800P" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="PJS008-2120-0" prefix="J">
<description>&lt;b&gt;Memory Card Connectors STD MNT MICRO SD PUSH-PUSH, SMT CONN&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://componentsearchengine.com/Datasheets/1/PJS008-2120-0.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="PJS008-2120-0" x="0" y="0"/>
</gates>
<devices>
<device name="" package="PJS00821200">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
<connect gate="G$1" pin="7" pad="7"/>
<connect gate="G$1" pin="8" pad="8"/>
<connect gate="G$1" pin="CARD_DETECT_SW1" pad="CD1"/>
<connect gate="G$1" pin="GND_1" pad="G1"/>
<connect gate="G$1" pin="GND_2" pad="G2"/>
<connect gate="G$1" pin="GND_3" pad="G3"/>
<connect gate="G$1" pin="MP1" pad="MP1"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="Memory Card Connectors STD MNT MICRO SD PUSH-PUSH, SMT CONN" constant="no"/>
<attribute name="HEIGHT" value="1.5mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Yamaichi" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="PJS008-2120-0" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="945-PJS008-2120-0" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/Yamaichi-Electronics/PJS008-2120-0?qs=pDnM3xHIg41mTHT1wk7bvQ%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="TJA1051TK_3,118" prefix="IC">
<description>&lt;b&gt;High-speed CAN transceiver&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="http://www.nxp.com/docs/en/data-sheet/TJA1051.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="TJA1051TK_3,118" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SON65P300X300X100-9N">
<connects>
<connect gate="G$1" pin="CANH" pad="7"/>
<connect gate="G$1" pin="CANL" pad="6"/>
<connect gate="G$1" pin="EP" pad="9"/>
<connect gate="G$1" pin="GND" pad="2"/>
<connect gate="G$1" pin="RXD" pad="4"/>
<connect gate="G$1" pin="S" pad="8"/>
<connect gate="G$1" pin="TXD" pad="1"/>
<connect gate="G$1" pin="VCC" pad="3"/>
<connect gate="G$1" pin="VIO" pad="5"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="High-speed CAN transceiver" constant="no"/>
<attribute name="HEIGHT" value="1mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="NXP" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="TJA1051TK/3,118" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="771-TJA1051TK/3118" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/NXP-Semiconductors/TJA1051TK-3118?qs=fhAOlxDPaYVrDQ2e4g%252BBJA%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="SM04B-GHS-TB_LF__SN_" prefix="J">
<description>&lt;b&gt;JST GH Series, 1.25mm Pitch 4 Way Right Angle PCB Header, Solder Termination, 1A&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="http://uk.rs-online.com/web/p/products/7521797P"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="SM04B-GHS-TB_LF__SN_" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SM04B-GHS-TB">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="JST GH Series, 1.25mm Pitch 4 Way Right Angle PCB Header, Solder Termination, 1A" constant="no"/>
<attribute name="HEIGHT" value="mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="JST (JAPAN SOLDERLESS TERMINALS)" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="SM04B-GHS-TB(LF)(SN)" constant="no"/>
<attribute name="RS_PART_NUMBER" value="7521797P" constant="no"/>
<attribute name="RS_PRICE-STOCK" value="http://uk.rs-online.com/web/p/products/7521797P" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="SM05B-GHS-TB_LF__SN_" prefix="J">
<description>&lt;b&gt;JST GH Series, 1.25mm Pitch 5 Way Right Angle PCB Header, Solder Termination, 1A&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="http://uk.rs-online.com/web/p/products/7521807P"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="SM05B-GHS-TB_LF__SN_" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SM05B-GHS-TB">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="JST GH Series, 1.25mm Pitch 5 Way Right Angle PCB Header, Solder Termination, 1A" constant="no"/>
<attribute name="HEIGHT" value="mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="JST (JAPAN SOLDERLESS TERMINALS)" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="SM05B-GHS-TB(LF)(SN)" constant="no"/>
<attribute name="RS_PART_NUMBER" value="7521807P" constant="no"/>
<attribute name="RS_PRICE-STOCK" value="http://uk.rs-online.com/web/p/products/7521807P" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="74LVC1G86SE-7" prefix="IC">
<description>&lt;b&gt;DiodesZetex 74LVC1G86SE-7, XOR 2 Input XOR, 1.65  5.5 V, 5-Pin SOT-353&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://www.diodes.com/assets/Datasheets/74LVC1G86.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="74LVC1G86SE-7" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SOT65P210X110-5N">
<connects>
<connect gate="G$1" pin="A" pad="1"/>
<connect gate="G$1" pin="B" pad="2"/>
<connect gate="G$1" pin="GND" pad="3"/>
<connect gate="G$1" pin="VCC" pad="5"/>
<connect gate="G$1" pin="Y" pad="4"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="DiodesZetex 74LVC1G86SE-7, XOR 2 Input XOR, 1.65  5.5 V, 5-Pin SOT-353" constant="no"/>
<attribute name="HEIGHT" value="1.1mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Diodes Inc." constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="74LVC1G86SE-7" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="621-74LVC1G86SE-7" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/Diodes-Incorporated/74LVC1G86SE-7/?qs=8Dv1RiiPiVJ%252BnYSWg3kTgg%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="74LVC2G86DC,125" prefix="IC">
<description>&lt;b&gt;74LVC2G86 - Dual 2-input EXCLUSIVE-OR gate@en-us&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://assets.nexperia.com/documents/data-sheet/74LVC2G86.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="74LVC2G86DC,125" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SOP50P310X100-8N">
<connects>
<connect gate="G$1" pin="1A" pad="1"/>
<connect gate="G$1" pin="1B" pad="2"/>
<connect gate="G$1" pin="1Y" pad="7"/>
<connect gate="G$1" pin="2A" pad="5"/>
<connect gate="G$1" pin="2B" pad="6"/>
<connect gate="G$1" pin="2Y" pad="3"/>
<connect gate="G$1" pin="GND" pad="4"/>
<connect gate="G$1" pin="VCC" pad="8"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="74LVC2G86 - Dual 2-input EXCLUSIVE-OR gate@en-us" constant="no"/>
<attribute name="HEIGHT" value="1mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Nexperia" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="74LVC2G86DC,125" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="771-LVC2G86DC125" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/Nexperia/74LVC2G86DC125?qs=me8TqzrmIYXbZy3sMRjHUw%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="SM06B-SRSS-TB__LF__SN_" prefix="J">
<description>&lt;b&gt;connector,multipole PCB use,SM06B-SRSS-T JST SH Series, 1mm Pitch 6 Way 1 Row Right Angle PCB Header, Solder Termination, 1A&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="http://uk.rs-online.com/web/p/products/5468827"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="SM06B-SRSS-TB__LF__SN_" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SM06B-SRSS-TB">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="connector,multipole PCB use,SM06B-SRSS-T JST SH Series, 1mm Pitch 6 Way 1 Row Right Angle PCB Header, Solder Termination, 1A" constant="no"/>
<attribute name="HEIGHT" value="mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="JST (JAPAN SOLDERLESS TERMINALS)" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="SM06B-SRSS-TB (LF)(SN)" constant="no"/>
<attribute name="RS_PART_NUMBER" value="5468827" constant="no"/>
<attribute name="RS_PRICE-STOCK" value="http://uk.rs-online.com/web/p/products/5468827" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="PMEG2020CPASX" prefix="D">
<description>&lt;b&gt;Schottky Diodes &amp; Rectifiers 20V 2A dual MEGA Schottky&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://componentsearchengine.com/Datasheets/2/PMEG2020CPASX.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="PMEG2020CPASX" x="0" y="0"/>
</gates>
<devices>
<device name="" package="PMEG2020CPASX">
<connects>
<connect gate="G$1" pin="A1" pad="1"/>
<connect gate="G$1" pin="A2" pad="2"/>
<connect gate="G$1" pin="K_1" pad="3"/>
<connect gate="G$1" pin="K_2" pad="4"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="Schottky Diodes &amp; Rectifiers 20V 2A dual MEGA Schottky" constant="no"/>
<attribute name="HEIGHT" value="0.65mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Nexperia" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="PMEG2020CPASX" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="771-PMEG2020CPASX" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/Nexperia/PMEG2020CPASX?qs=K2OaAKmNuLimeK0EUCzHKQ%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="APG1608ZGCK" prefix="LED">
<description>&lt;b&gt;Standard LEDs - SMD 1.6X0.8MM&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="http://www.kingbrightusa.com/images/catalog/SPEC/APG1608ZGCK.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="APG1608ZGCK" x="0" y="0"/>
</gates>
<devices>
<device name="" package="LEDC1608X28N">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="K" pad="1"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="Standard LEDs - SMD 1.6X0.8MM" constant="no"/>
<attribute name="HEIGHT" value="0.28mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Kingbright" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="APG1608ZGCK" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="604-APG1608ZGCK" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/Kingbright/APG1608ZGCK?qs=Oo40KB9lBTmmOma0ledTcg%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="PMEG1030EJ,115" prefix="D">
<description>&lt;b&gt;Schottky Diodes &amp; Rectifiers SCHOTTKY 10V 3A&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://assets.nexperia.com/documents/data-sheet/PMEG1030EH_EJ.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="PMEG1030EJ,115" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SODFL2512X80N">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="K" pad="1"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="Schottky Diodes &amp; Rectifiers SCHOTTKY 10V 3A" constant="no"/>
<attribute name="HEIGHT" value="0.8mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Nexperia" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="PMEG1030EJ,115" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="771-PMEG1030EJ-T/R" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/Nexperia/PMEG1030EJ115?qs=LOCUfHb8d9vmk7P%2FuYbs5A%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="0603L100SLYR" prefix="F">
<description>&lt;b&gt;PTC 6V POLYFUSE SURF MOUNT 0603 SL 1.00A&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://m.littelfuse.com/~/media/electronics/datasheets/resettable_ptcs/littelfuse_ptc_lorho_datasheet.pdf.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="0603L100SLYR" x="0" y="0"/>
</gates>
<devices>
<device name="" package="0603L050SLYR">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="PTC 6V POLYFUSE SURF MOUNT 0603 SL 1.00A" constant="no"/>
<attribute name="HEIGHT" value="0.75mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="LITTELFUSE" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="0603L100SLYR" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="576-0603L100SLYR" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/Littelfuse/0603L100SLYR?qs=%252BPPFKVzHyAKqCAJtLoK6vw%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="1N4448X-TP" prefix="D">
<description>&lt;b&gt;Diodes - General Purpose, Power, Switching 250mA 75V 500mA 250mA 150mW 75Vbr&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://componentsearchengine.com/Datasheets/1/1N4448X-TP.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="1N4448X-TP" x="0" y="0"/>
</gates>
<devices>
<device name="" package="1N4448XTP">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="K" pad="1"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="Diodes - General Purpose, Power, Switching 250mA 75V 500mA 250mA 150mW 75Vbr" constant="no"/>
<attribute name="HEIGHT" value="0.65mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Micro Commercial Components (MCC)" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="1N4448X-TP" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="833-1N4448X-TP" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.com/Search/Refine.aspx?Keyword=833-1N4448X-TP" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="LTST-C19HE1WT" prefix="LED">
<description>&lt;b&gt;LED,SMD,1.6x1.5x0.4mm,Red/Green/Blue Lite-On LTST-C19HE1WT 3 RGB LED, 470 / 525 / 624 nm 3-Pin, Rectangle Lens SMD package&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://datasheet.datasheetarchive.com/originals/distributors/Datasheets-DGA13/1159767.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="LTST-C19HE1WT" x="0" y="0"/>
</gates>
<devices>
<device name="" package="LTST-C19HE1WT">
<connects>
<connect gate="G$1" pin="BLUE" pad="3"/>
<connect gate="G$1" pin="GREEN" pad="2"/>
<connect gate="G$1" pin="POLARITY" pad="4"/>
<connect gate="G$1" pin="RED" pad="1"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="LED,SMD,1.6x1.5x0.4mm,Red/Green/Blue Lite-On LTST-C19HE1WT 3 RGB LED, 470 / 525 / 624 nm 3-Pin, Rectangle Lens SMD package" constant="no"/>
<attribute name="HEIGHT" value="mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Lite-On" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="LTST-C19HE1WT" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="859-LTST-C19HE1WT" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/Lite-On/LTST-C19HE1WT?qs=WAWaI72GHKxJLPArJA9%252BUw%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="AP7365-33WG-7" prefix="IC">
<description>&lt;b&gt;DiodesZetex AP7365-33WG-7, LDO Voltage Regulator, 600mA, 3.3 V +/-2%, 2  6 Vin, 5-Pin SOT-25&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://componentsearchengine.com/Datasheets/1/AP7365-33WG-7.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="AP7365-33WG-7" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SOT95P285X130-5N">
<connects>
<connect gate="G$1" pin="ADJ" pad="4"/>
<connect gate="G$1" pin="EN" pad="3"/>
<connect gate="G$1" pin="GND" pad="2"/>
<connect gate="G$1" pin="IN" pad="1"/>
<connect gate="G$1" pin="OUT" pad="5"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="DiodesZetex AP7365-33WG-7, LDO Voltage Regulator, 600mA, 3.3 V +/-2%, 2  6 Vin, 5-Pin SOT-25" constant="no"/>
<attribute name="HEIGHT" value="1.3mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Diodes Inc." constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="AP7365-33WG-7" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="621-AP7365-33WG-7" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/Diodes-Incorporated/AP7365-33WG-7?qs=abZ1nkZpTuOZFvxvoFPL0w%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="CDBU70" prefix="D">
<description>&lt;b&gt;Schottky Diodes &amp; Rectifiers Schottky Barr Diode 70mA, 70V&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://www.arrow.com/en/products/cdbu70/comchip-technology"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="CDBU70" x="0" y="0"/>
</gates>
<devices>
<device name="" package="DIOM179X85N">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="K" pad="1"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="Schottky Diodes &amp; Rectifiers Schottky Barr Diode 70mA, 70V" constant="no"/>
<attribute name="HEIGHT" value="0.85mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Comchip Technology" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="CDBU70" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="750-CDBU70" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/Comchip-Technology/CDBU70?qs=J1R1puj4KiHu6WmHr9F3%252Bw%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="W2H13C1048AT1F" prefix="C">
<description>&lt;b&gt;Feed Through Capacitors 25volt 0.1uF X7R&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://componentsearchengine.com/Datasheets/1/W2H13C1048AT1F.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="W2H13C1048AT1F" x="0" y="0"/>
</gates>
<devices>
<device name="" package="W2H13C1048AT1A">
<connects>
<connect gate="G$1" pin="GROUND_1" pad="3"/>
<connect gate="G$1" pin="GROUND_2" pad="4"/>
<connect gate="G$1" pin="SIGNAL/VCC_1" pad="1"/>
<connect gate="G$1" pin="SIGNAL/VCC_2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="Feed Through Capacitors 25volt 0.1uF X7R" constant="no"/>
<attribute name="HEIGHT" value="1mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="AVX" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="W2H13C1048AT1F" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="581-W2H13C1048AT1F" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.com/Search/Refine.aspx?Keyword=581-W2H13C1048AT1F" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="XP151A12A2MR-G" prefix="Q">
<description>&lt;b&gt;Power MOSFET&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://www.torexsemi.com/file/xp151a12a2mr/XP151A12A2MR.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="XP151A12A2MR-G" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SOT95P280X130-3N">
<connects>
<connect gate="G$1" pin="D" pad="3"/>
<connect gate="G$1" pin="G" pad="1"/>
<connect gate="G$1" pin="S" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="Power MOSFET" constant="no"/>
<attribute name="HEIGHT" value="1.3mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Torex" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="XP151A12A2MR-G" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="865-XP151A12A2MR-G" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/Torex-Semiconductor/XP151A12A2MR-G?qs=AsjdqWjXhJ%252BYt8dSaKx3TA%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="BSS209PW_H6327" prefix="Q">
<description>&lt;b&gt;MOSFET P-Ch -20V -630mA SOT-323-3&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://componentsearchengine.com/Datasheets/1/BSS209PW H6327.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="BSS209PW_H6327" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SOT65P210X100-3N">
<connects>
<connect gate="G$1" pin="D" pad="3"/>
<connect gate="G$1" pin="G" pad="1"/>
<connect gate="G$1" pin="S" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="MOSFET P-Ch -20V -630mA SOT-323-3" constant="no"/>
<attribute name="HEIGHT" value="1mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Infineon" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="BSS209PW H6327" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="726-BSS209PWH6327" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.com/Search/Refine.aspx?Keyword=726-BSS209PWH6327" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="ICM-20602" prefix="IC">
<description>&lt;b&gt;IMUs - Inertial Measurement Units Low-Power, High-Performance Integrated 6-Axis MEMS MotionTracking  Device in 3mm x 3mm Package&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://3cfeqx1hf82y3xcoull08ihx-wpengine.netdna-ssl.com/wp-content/uploads/2021/03/DS-000135-ICG-20660-TYP-v1.2.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="ICM-20602" x="0" y="0"/>
</gates>
<devices>
<device name="" package="IAM20680HP">
<connects>
<connect gate="G$1" pin="CS" pad="5"/>
<connect gate="G$1" pin="FSYNC" pad="8"/>
<connect gate="G$1" pin="GND" pad="13"/>
<connect gate="G$1" pin="INT" pad="6"/>
<connect gate="G$1" pin="REGOUT" pad="14"/>
<connect gate="G$1" pin="RESV_1" pad="7"/>
<connect gate="G$1" pin="RESV_2" pad="9"/>
<connect gate="G$1" pin="RESV_3" pad="10"/>
<connect gate="G$1" pin="RESV_4" pad="11"/>
<connect gate="G$1" pin="RESV_5" pad="12"/>
<connect gate="G$1" pin="RESV_6" pad="15"/>
<connect gate="G$1" pin="SA0/SDO" pad="4"/>
<connect gate="G$1" pin="SCL/SPC" pad="2"/>
<connect gate="G$1" pin="SDA/SDI" pad="3"/>
<connect gate="G$1" pin="VDD" pad="16"/>
<connect gate="G$1" pin="VDDIO" pad="1"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="IMUs - Inertial Measurement Units Low-Power, High-Performance Integrated 6-Axis MEMS MotionTracking  Device in 3mm x 3mm Package" constant="no"/>
<attribute name="HEIGHT" value="mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="TDK" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="ICM-20602" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="410-ICM-20602" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/TDK-InvenSense/ICM-20602?qs=u4fy%2FsgLU9NtDChFbqTxBA%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="FM25V02A-GTR" prefix="IC">
<description>&lt;b&gt;CYPRESS SEMICONDUCTOR - FM25V02A-GTR - NON-VOL MEMORY, 256KBIT, 40MHZ, SOIC-8&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://www.cypress.com/file/139666/download"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="FM25V02A-GTR" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SOIC127P602X173-8N">
<connects>
<connect gate="G$1" pin="!CS" pad="1"/>
<connect gate="G$1" pin="!HOLD" pad="7"/>
<connect gate="G$1" pin="!WP" pad="3"/>
<connect gate="G$1" pin="SCK" pad="6"/>
<connect gate="G$1" pin="SI" pad="5"/>
<connect gate="G$1" pin="SO" pad="2"/>
<connect gate="G$1" pin="VDD" pad="8"/>
<connect gate="G$1" pin="VSS" pad="4"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value="CYPRESS SEMICONDUCTOR - FM25V02A-GTR - NON-VOL MEMORY, 256KBIT, 40MHZ, SOIC-8" constant="no"/>
<attribute name="HEIGHT" value="1.727mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Cypress Semiconductor" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="FM25V02A-GTR" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="727-FM25V02A-GTR" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/Cypress-Semiconductor/FM25V02A-GTR?qs=ILgNtqsyH21Sja70fv%2FiBQ%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="supply1" urn="urn:adsk.eagle:library:371">
<description>&lt;b&gt;Supply Symbols&lt;/b&gt;&lt;p&gt;
 GND, VCC, 0V, +5V, -5V, etc.&lt;p&gt;
 Please keep in mind, that these devices are necessary for the
 automatic wiring of the supply signals.&lt;p&gt;
 The pin name defined in the symbol is identical to the net which is to be wired automatically.&lt;p&gt;
 In this library the device names are the same as the pin names of the symbols, therefore the correct signal names appear next to the supply symbols in the schematic.&lt;p&gt;
 &lt;author&gt;Created by librarian@cadsoft.de&lt;/author&gt;</description>
<packages>
</packages>
<symbols>
<symbol name="GND" urn="urn:adsk.eagle:symbol:26925/1" library_version="1">
<wire x1="-1.905" y1="0" x2="1.905" y2="0" width="0.254" layer="94"/>
<text x="-2.54" y="-2.54" size="1.778" layer="96">&gt;VALUE</text>
<pin name="GND" x="0" y="2.54" visible="off" length="short" direction="sup" rot="R270"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="GND" urn="urn:adsk.eagle:component:26954/1" prefix="GND" library_version="1">
<description>&lt;b&gt;SUPPLY SYMBOL&lt;/b&gt;</description>
<gates>
<gate name="1" symbol="GND" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="SparkFun-Capacitors">
<description>&lt;h3&gt;SparkFun Capacitors&lt;/h3&gt;
This library contains capacitors. 
&lt;br&gt;
&lt;br&gt;
We've spent an enormous amount of time creating and checking these footprints and parts, but it is &lt;b&gt; the end user's responsibility&lt;/b&gt; to ensure correctness and suitablity for a given componet or application. 
&lt;br&gt;
&lt;br&gt;If you enjoy using this library, please buy one of our products at &lt;a href=" www.sparkfun.com"&gt;SparkFun.com&lt;/a&gt;.
&lt;br&gt;
&lt;br&gt;
&lt;b&gt;Licensing:&lt;/b&gt; Creative Commons ShareAlike 4.0 International - https://creativecommons.org/licenses/by-sa/4.0/ 
&lt;br&gt;
&lt;br&gt;
You are welcome to use this library for commercial purposes. For attribution, we ask that when you begin to sell your device using our footprint, you email us with a link to the product being sold. We want bragging rights that we helped (in a very small part) to create your 8th world wonder. We would like the opportunity to feature your device on our homepage.</description>
<packages>
<package name="0603">
<description>&lt;p&gt;&lt;b&gt;Generic 1608 (0603) package&lt;/b&gt;&lt;/p&gt;
&lt;p&gt;0.2mm courtyard excess rounded to nearest 0.05mm.&lt;/p&gt;</description>
<wire x1="-1.6" y1="0.7" x2="1.6" y2="0.7" width="0.0508" layer="39"/>
<wire x1="1.6" y1="0.7" x2="1.6" y2="-0.7" width="0.0508" layer="39"/>
<wire x1="1.6" y1="-0.7" x2="-1.6" y2="-0.7" width="0.0508" layer="39"/>
<wire x1="-1.6" y1="-0.7" x2="-1.6" y2="0.7" width="0.0508" layer="39"/>
<wire x1="-0.356" y1="0.432" x2="0.356" y2="0.432" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.419" x2="0.356" y2="-0.419" width="0.1016" layer="51"/>
<smd name="1" x="-0.85" y="0" dx="1.1" dy="1" layer="1"/>
<smd name="2" x="0.85" y="0" dx="1.1" dy="1" layer="1"/>
<text x="0" y="0.762" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-0.762" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
<rectangle x1="-0.8382" y1="-0.4699" x2="-0.3381" y2="0.4801" layer="51"/>
<rectangle x1="0.3302" y1="-0.4699" x2="0.8303" y2="0.4801" layer="51"/>
<rectangle x1="-0.1999" y1="-0.3" x2="0.1999" y2="0.3" layer="35"/>
</package>
<package name="0805">
<description>&lt;p&gt;&lt;b&gt;Generic 2012 (0805) package&lt;/b&gt;&lt;/p&gt;
&lt;p&gt;0.2mm courtyard excess rounded to nearest 0.05mm.&lt;/p&gt;</description>
<wire x1="-1.5" y1="0.8" x2="1.5" y2="0.8" width="0.0508" layer="39"/>
<wire x1="1.5" y1="0.8" x2="1.5" y2="-0.8" width="0.0508" layer="39"/>
<wire x1="1.5" y1="-0.8" x2="-1.5" y2="-0.8" width="0.0508" layer="39"/>
<wire x1="-1.5" y1="-0.8" x2="-1.5" y2="0.8" width="0.0508" layer="39"/>
<smd name="1" x="-0.9" y="0" dx="0.8" dy="1.2" layer="1"/>
<smd name="2" x="0.9" y="0" dx="0.8" dy="1.2" layer="1"/>
<text x="0" y="0.889" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-0.889" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
</package>
<package name="1206">
<description>&lt;p&gt;&lt;b&gt;Generic 3216 (1206) package&lt;/b&gt;&lt;/p&gt;
&lt;p&gt;0.2mm courtyard excess rounded to nearest 0.05mm.&lt;/p&gt;</description>
<wire x1="-2.4" y1="1.1" x2="2.4" y2="1.1" width="0.0508" layer="39"/>
<wire x1="2.4" y1="-1.1" x2="-2.4" y2="-1.1" width="0.0508" layer="39"/>
<wire x1="-2.4" y1="-1.1" x2="-2.4" y2="1.1" width="0.0508" layer="39"/>
<wire x1="2.4" y1="1.1" x2="2.4" y2="-1.1" width="0.0508" layer="39"/>
<wire x1="-0.965" y1="0.787" x2="0.965" y2="0.787" width="0.1016" layer="51"/>
<wire x1="-0.965" y1="-0.787" x2="0.965" y2="-0.787" width="0.1016" layer="51"/>
<rectangle x1="-1.7018" y1="-0.8509" x2="-0.9517" y2="0.8491" layer="51"/>
<rectangle x1="0.9517" y1="-0.8491" x2="1.7018" y2="0.8509" layer="51"/>
<rectangle x1="-0.1999" y1="-0.4001" x2="0.1999" y2="0.4001" layer="35"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<text x="0" y="1.143" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.143" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
</package>
<package name="0402-TIGHT">
<smd name="1" x="-0.5" y="0" dx="0.6" dy="0.6" layer="1"/>
<smd name="2" x="0.5" y="0" dx="0.6" dy="0.6" layer="1"/>
<text x="0" y="0.562" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-0.562" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
<wire x1="-0.5" y1="-0.25" x2="-0.5" y2="0.25" width="0.002540625" layer="51"/>
<wire x1="-0.5" y1="0.25" x2="0.5" y2="0.25" width="0.002540625" layer="51"/>
<wire x1="0.5" y1="0.25" x2="0.5" y2="-0.25" width="0.002540625" layer="51"/>
<wire x1="0.5" y1="-0.25" x2="-0.5" y2="-0.25" width="0.002540625" layer="51"/>
<rectangle x1="-0.5" y1="-0.25" x2="-0.3" y2="0.25" layer="51"/>
<rectangle x1="0.3" y1="-0.25" x2="0.5" y2="0.25" layer="51" rot="R180"/>
<wire x1="0.9262" y1="0.4262" x2="-0.9262" y2="0.4262" width="0.05" layer="39"/>
<wire x1="-0.9262" y1="0.4262" x2="-0.9262" y2="-0.4262" width="0.05" layer="39"/>
<wire x1="-0.9262" y1="-0.4262" x2="0.9262" y2="-0.4262" width="0.05" layer="39"/>
<wire x1="0.9262" y1="-0.4262" x2="0.9262" y2="0.4262" width="0.05" layer="39"/>
</package>
<package name="0402">
<description>&lt;p&gt;&lt;b&gt;Generic 1005 (0402) package&lt;/b&gt;&lt;/p&gt;
&lt;p&gt;0.2mm courtyard excess rounded to nearest 0.05mm.&lt;/p&gt;</description>
<wire x1="-0.2704" y1="0.2286" x2="0.2704" y2="0.2286" width="0.1524" layer="51"/>
<wire x1="0.2704" y1="-0.2286" x2="-0.2704" y2="-0.2286" width="0.1524" layer="51"/>
<wire x1="-1.2" y1="0.65" x2="1.2" y2="0.65" width="0.0508" layer="39"/>
<wire x1="1.2" y1="0.65" x2="1.2" y2="-0.65" width="0.0508" layer="39"/>
<wire x1="1.2" y1="-0.65" x2="-1.2" y2="-0.65" width="0.0508" layer="39"/>
<wire x1="-1.2" y1="-0.65" x2="-1.2" y2="0.65" width="0.0508" layer="39"/>
<smd name="1" x="-0.58" y="0" dx="0.85" dy="0.9" layer="1"/>
<smd name="2" x="0.58" y="0" dx="0.85" dy="0.9" layer="1"/>
<text x="0" y="0.762" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-0.762" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
<rectangle x1="-0.554" y1="-0.3048" x2="-0.254" y2="0.3048" layer="51"/>
<rectangle x1="0.2588" y1="-0.3048" x2="0.5588" y2="0.3048" layer="51"/>
<rectangle x1="-0.1999" y1="-0.3" x2="0.1999" y2="0.3" layer="35"/>
</package>
<package name="CAP-PTH-SMALL-KIT">
<description>&lt;h3&gt;CAP-PTH-SMALL-KIT&lt;/h3&gt;
Commonly used for small ceramic capacitors. Like our 0.1uF (http://www.sparkfun.com/products/8375) or 22pF caps (http://www.sparkfun.com/products/8571).&lt;br&gt;
&lt;br&gt;
&lt;b&gt;Warning:&lt;/b&gt; This is the KIT version of this package. This package has a smaller diameter top stop mask, which doesn't cover the diameter of the pad. This means only the bottom side of the pads' copper will be exposed. You'll only be able to solder to the bottom side.</description>
<wire x1="0" y1="0.635" x2="0" y2="-0.635" width="0.254" layer="21"/>
<wire x1="-2.667" y1="1.27" x2="2.667" y2="1.27" width="0.254" layer="21"/>
<wire x1="2.667" y1="1.27" x2="2.667" y2="-1.27" width="0.254" layer="21"/>
<wire x1="2.667" y1="-1.27" x2="-2.667" y2="-1.27" width="0.254" layer="21"/>
<wire x1="-2.667" y1="-1.27" x2="-2.667" y2="1.27" width="0.254" layer="21"/>
<pad name="1" x="-1.397" y="0" drill="1.016" diameter="2.032" stop="no"/>
<pad name="2" x="1.397" y="0" drill="1.016" diameter="2.032" stop="no"/>
<polygon width="0.127" layer="30">
<vertex x="-1.4021" y="-0.9475" curve="-90"/>
<vertex x="-2.357" y="-0.0178" curve="-90.011749"/>
<vertex x="-1.4046" y="0.9576" curve="-90"/>
<vertex x="-0.4546" y="-0.0204" curve="-90.024193"/>
</polygon>
<polygon width="0.127" layer="29">
<vertex x="-1.4046" y="-0.4395" curve="-90.012891"/>
<vertex x="-1.8491" y="-0.0153" curve="-90"/>
<vertex x="-1.4046" y="0.452" curve="-90"/>
<vertex x="-0.9627" y="-0.0051" curve="-90.012967"/>
</polygon>
<polygon width="0.127" layer="30">
<vertex x="1.397" y="-0.9475" curve="-90"/>
<vertex x="0.4421" y="-0.0178" curve="-90.011749"/>
<vertex x="1.3945" y="0.9576" curve="-90"/>
<vertex x="2.3445" y="-0.0204" curve="-90.024193"/>
</polygon>
<polygon width="0.127" layer="29">
<vertex x="1.3945" y="-0.4395" curve="-90.012891"/>
<vertex x="0.95" y="-0.0153" curve="-90"/>
<vertex x="1.3945" y="0.452" curve="-90"/>
<vertex x="1.8364" y="-0.0051" curve="-90.012967"/>
</polygon>
</package>
<package name="1210">
<description>&lt;p&gt;&lt;b&gt;Generic 3225 (1210) package&lt;/b&gt;&lt;/p&gt;
&lt;p&gt;0.2mm courtyard excess rounded to nearest 0.05mm.&lt;/p&gt;</description>
<wire x1="-1.5365" y1="1.1865" x2="1.5365" y2="1.1865" width="0.127" layer="51"/>
<wire x1="1.5365" y1="1.1865" x2="1.5365" y2="-1.1865" width="0.127" layer="51"/>
<wire x1="1.5365" y1="-1.1865" x2="-1.5365" y2="-1.1865" width="0.127" layer="51"/>
<wire x1="-1.5365" y1="-1.1865" x2="-1.5365" y2="1.1865" width="0.127" layer="51"/>
<wire x1="-2.59" y1="1.45" x2="2.59" y2="1.45" width="0.0508" layer="39"/>
<wire x1="2.59" y1="1.45" x2="2.59" y2="-1.45" width="0.0508" layer="39"/>
<wire x1="2.59" y1="-1.45" x2="-2.59" y2="-1.45" width="0.0508" layer="39"/>
<wire x1="-2.59" y1="-1.45" x2="-2.59" y2="1.45" width="0.0508" layer="39"/>
<smd name="1" x="-1.755" y="0" dx="1.27" dy="2.06" layer="1"/>
<smd name="2" x="1.755" y="0" dx="1.27" dy="2.06" layer="1"/>
<text x="0" y="1.397" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.397" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
</package>
<package name="CAP-PTH-10MM">
<description>2 PTH spaced 10mm apart</description>
<wire x1="-0.5" y1="0.635" x2="-0.5" y2="0" width="0.2032" layer="21"/>
<pad name="1" x="-5" y="0" drill="0.9" diameter="1.651"/>
<pad name="2" x="5" y="0" drill="0.9" diameter="1.651"/>
<text x="0" y="1" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;Name</text>
<text x="0" y="-1" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;Value</text>
<wire x1="-0.5" y1="0" x2="-0.5" y2="-0.635" width="0.2032" layer="21"/>
<wire x1="0.5" y1="0.635" x2="0.5" y2="0" width="0.2032" layer="21"/>
<wire x1="0.5" y1="0" x2="0.5" y2="-0.635" width="0.2032" layer="21"/>
<wire x1="-0.5" y1="0" x2="-3.5" y2="0" width="0.2032" layer="21"/>
<wire x1="0.5" y1="0" x2="3.5" y2="0" width="0.2032" layer="21"/>
</package>
<package name="EIA7343">
<description>EIA 7343 tantalum capacitor</description>
<wire x1="-5" y1="2.5" x2="-2" y2="2.5" width="0.2032" layer="21"/>
<wire x1="-5" y1="2.5" x2="-5" y2="-2.5" width="0.2032" layer="21"/>
<wire x1="-5" y1="-2.5" x2="-2" y2="-2.5" width="0.2032" layer="21"/>
<wire x1="2" y1="2.5" x2="4" y2="2.5" width="0.2032" layer="21"/>
<wire x1="4" y1="2.5" x2="5" y2="1.5" width="0.2032" layer="21"/>
<wire x1="5" y1="1.5" x2="5" y2="-1.5" width="0.2032" layer="21"/>
<wire x1="5" y1="-1.5" x2="4" y2="-2.5" width="0.2032" layer="21"/>
<wire x1="4" y1="-2.5" x2="2" y2="-2.5" width="0.2032" layer="21"/>
<smd name="C" x="-3.17" y="0" dx="2.55" dy="2.7" layer="1" rot="R180"/>
<smd name="A" x="3.17" y="0" dx="2.55" dy="2.7" layer="1" rot="R180"/>
<text x="0" y="2.667" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;Name</text>
<text x="0" y="-2.667" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;Value</text>
</package>
<package name="CPOL-RADIAL-2.5MM-6.5MM">
<description>2.5 mm spaced PTHs with 6.5 mm diameter outline</description>
<wire x1="-0.635" y1="1.778" x2="-1.905" y2="1.778" width="0.2032" layer="21"/>
<circle x="0" y="0" radius="3.25" width="0.2032" layer="21"/>
<pad name="2" x="-1.25" y="0" drill="0.7" diameter="1.651"/>
<pad name="1" x="1.25" y="0" drill="0.7" diameter="1.651" shape="square"/>
<text x="0" y="-3.429" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;Value</text>
<text x="0" y="3.429" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;Name</text>
<wire x1="1.905" y1="1.778" x2="0.635" y2="1.778" width="0.2032" layer="21"/>
<wire x1="1.27" y1="2.413" x2="1.27" y2="1.143" width="0.2032" layer="21"/>
</package>
<package name="NIC_10X10.5_CAP">
<description>Some old package in our library</description>
<smd name="+" x="4.5" y="0" dx="4.5" dy="2.5" layer="1"/>
<smd name="-" x="-4.5" y="0" dx="4.5" dy="2.5" layer="1"/>
<wire x1="-5.5" y1="-5.5" x2="3.5" y2="-5.5" width="0.2032" layer="21"/>
<wire x1="-5.5" y1="5.5" x2="3.5" y2="5.5" width="0.2032" layer="21"/>
<wire x1="3.5" y1="5.5" x2="5.5" y2="3.5" width="0.2032" layer="21"/>
<wire x1="5.5" y1="-3.5" x2="3.5" y2="-5.5" width="0.2032" layer="21"/>
<wire x1="-4.826" y1="1.524" x2="4.826" y2="1.397" width="0.2032" layer="21" curve="-147.716211"/>
<wire x1="-4.826" y1="-1.524" x2="4.826" y2="-1.397" width="0.2032" layer="21" curve="147.716211"/>
<wire x1="5.5" y1="3.5" x2="5.5" y2="1.5" width="0.2032" layer="21"/>
<wire x1="5.5" y1="-3.5" x2="5.5" y2="-1.5" width="0.2032" layer="21"/>
<wire x1="-5.5" y1="-5.5" x2="-5.5" y2="-1.5" width="0.2032" layer="21"/>
<wire x1="-5.5" y1="1.5" x2="-5.5" y2="5.5" width="0.2032" layer="21"/>
<text x="0" y="5.715" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-5.715" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
</package>
<package name="PANASONIC_D">
<description>&lt;b&gt;Panasonic Aluminium Electrolytic Capacitor VS-Serie Package E&lt;/b&gt;</description>
<wire x1="-3.25" y1="3.25" x2="1.55" y2="3.25" width="0.1016" layer="51"/>
<wire x1="1.55" y1="3.25" x2="3.25" y2="1.55" width="0.1016" layer="51"/>
<wire x1="3.25" y1="1.55" x2="3.25" y2="-1.55" width="0.1016" layer="51"/>
<wire x1="3.25" y1="-1.55" x2="1.55" y2="-3.25" width="0.1016" layer="51"/>
<wire x1="1.55" y1="-3.25" x2="-3.25" y2="-3.25" width="0.1016" layer="51"/>
<wire x1="-3.25" y1="-3.25" x2="-3.25" y2="3.25" width="0.1016" layer="51"/>
<wire x1="-3.25" y1="0.95" x2="-3.25" y2="3.25" width="0.2032" layer="21"/>
<wire x1="-3.25" y1="3.25" x2="1.55" y2="3.25" width="0.2032" layer="21"/>
<wire x1="1.55" y1="3.25" x2="3.25" y2="1.55" width="0.2032" layer="21"/>
<wire x1="3.25" y1="1.55" x2="3.25" y2="0.95" width="0.2032" layer="21"/>
<wire x1="3.25" y1="-0.95" x2="3.25" y2="-1.55" width="0.2032" layer="21"/>
<wire x1="3.25" y1="-1.55" x2="1.55" y2="-3.25" width="0.2032" layer="21"/>
<wire x1="1.55" y1="-3.25" x2="-3.25" y2="-3.25" width="0.2032" layer="21"/>
<wire x1="-3.25" y1="-3.25" x2="-3.25" y2="-0.95" width="0.2032" layer="21"/>
<wire x1="2.95" y1="0.95" x2="-2.95" y2="0.95" width="0.2032" layer="21" curve="144.299363"/>
<wire x1="-2.95" y1="-0.95" x2="2.95" y2="-0.95" width="0.2032" layer="21" curve="144.299363"/>
<wire x1="-2.1" y1="2.25" x2="-2.1" y2="-2.2" width="0.1016" layer="51"/>
<circle x="0" y="0" radius="3.1" width="0.1016" layer="51"/>
<smd name="+" x="2.4" y="0" dx="3" dy="1.4" layer="1"/>
<smd name="-" x="-2.4" y="0" dx="3" dy="1.4" layer="1"/>
<text x="0" y="3.429" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-3.429" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
<rectangle x1="-3.65" y1="-0.35" x2="-3.05" y2="0.35" layer="51"/>
<rectangle x1="3.05" y1="-0.35" x2="3.65" y2="0.35" layer="51"/>
<polygon width="0.1016" layer="51">
<vertex x="-2.15" y="2.15"/>
<vertex x="-2.6" y="1.6"/>
<vertex x="-2.9" y="0.9"/>
<vertex x="-3.05" y="0"/>
<vertex x="-2.9" y="-0.95"/>
<vertex x="-2.55" y="-1.65"/>
<vertex x="-2.15" y="-2.15"/>
<vertex x="-2.15" y="2.1"/>
</polygon>
</package>
<package name="1206-POLAR">
<wire x1="-2.4" y1="1.1" x2="2.4" y2="1.1" width="0.0508" layer="39"/>
<wire x1="2.4" y1="-1.1" x2="-2.4" y2="-1.1" width="0.0508" layer="39"/>
<wire x1="-2.4" y1="-1.1" x2="-2.4" y2="1.1" width="0.0508" layer="39"/>
<wire x1="2.4" y1="1.1" x2="2.4" y2="-1.1" width="0.0508" layer="39"/>
<wire x1="-0.965" y1="0.787" x2="0.965" y2="0.787" width="0.1016" layer="51"/>
<wire x1="-0.965" y1="-0.787" x2="0.965" y2="-0.787" width="0.1016" layer="51"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<text x="0" y="1.143" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.143" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
<rectangle x1="-1.7018" y1="-0.8509" x2="-0.9517" y2="0.8491" layer="51"/>
<rectangle x1="0.9517" y1="-0.8491" x2="1.7018" y2="0.8509" layer="51"/>
<rectangle x1="-0.1999" y1="-0.4001" x2="0.1999" y2="0.4001" layer="35"/>
<wire x1="-2.54" y1="0.889" x2="-2.54" y2="-0.889" width="0.254" layer="21"/>
</package>
<package name="8X10.5">
<smd name="+" x="-3.05" y="0" dx="2.9" dy="0.9" layer="1"/>
<wire x1="-2.15" y1="4.15" x2="4.15" y2="4.15" width="0.127" layer="21"/>
<wire x1="4.15" y1="-4.15" x2="-2.15" y2="-4.15" width="0.127" layer="21"/>
<smd name="-" x="3.05" y="0" dx="2.9" dy="0.9" layer="1"/>
<wire x1="-4" y1="2.3" x2="-4" y2="0.5" width="0.127" layer="21"/>
<wire x1="-4" y1="-0.5" x2="-4" y2="-2.3" width="0.127" layer="21"/>
<wire x1="-4" y1="-2.3" x2="-2.15" y2="-4.15" width="0.127" layer="21"/>
<wire x1="-2.15" y1="4.15" x2="-4" y2="2.3" width="0.127" layer="21"/>
<wire x1="4.15" y1="4.15" x2="4.15" y2="0.55" width="0.127" layer="21"/>
<wire x1="4.15" y1="-0.55" x2="4.15" y2="-4.15" width="0.127" layer="21"/>
<text x="-0.5" y="4.5" size="0.6096" layer="25" font="vector" ratio="20">&gt;Name</text>
<text x="-0.5" y="-5" size="0.6096" layer="27" font="vector" ratio="20">&gt;Value</text>
</package>
<package name="EIA3216">
<description>Generic EIA 3216 (1206) polarized tantalum capacitor</description>
<wire x1="-1" y1="-1.2" x2="-2.5" y2="-1.2" width="0.2032" layer="51"/>
<wire x1="-2.5" y1="-1.2" x2="-2.5" y2="1.2" width="0.2032" layer="51"/>
<wire x1="-2.5" y1="1.2" x2="-1" y2="1.2" width="0.2032" layer="51"/>
<wire x1="1" y1="-1.2" x2="2.1" y2="-1.2" width="0.2032" layer="51"/>
<wire x1="2.1" y1="-1.2" x2="2.5" y2="-0.8" width="0.2032" layer="51"/>
<wire x1="2.5" y1="-0.8" x2="2.5" y2="0.8" width="0.2032" layer="51"/>
<wire x1="2.5" y1="0.8" x2="2.1" y2="1.2" width="0.2032" layer="51"/>
<wire x1="2.1" y1="1.2" x2="1" y2="1.2" width="0.2032" layer="51"/>
<wire x1="2.413" y1="0.762" x2="2.413" y2="-0.762" width="0.2032" layer="21"/>
<smd name="-" x="-1.4" y="0" dx="1.6" dy="1.4" layer="1" rot="R90"/>
<smd name="+" x="1.4" y="0" dx="1.6" dy="1.4" layer="1" rot="R90"/>
<text x="0" y="1.143" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.143" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
<wire x1="-2.286" y1="0.9906" x2="2.286" y2="0.9906" width="0.0508" layer="39"/>
<wire x1="2.286" y1="0.9906" x2="2.286" y2="-0.9906" width="0.0508" layer="39"/>
<wire x1="2.286" y1="-0.9906" x2="-2.286" y2="-0.9906" width="0.0508" layer="39"/>
<wire x1="-2.286" y1="-0.9906" x2="-2.286" y2="0.9906" width="0.0508" layer="39"/>
</package>
<package name="0603-POLAR">
<description>&lt;p&gt;&lt;b&gt;Polarized 1608 (0603) package&lt;/b&gt;&lt;/p&gt;
&lt;p&gt;0.2mm courtyard excess rounded to nearest 0.05mm.&lt;/p&gt;</description>
<wire x1="-1.1" y1="-0.8" x2="-1.7" y2="-0.8" width="0.2032" layer="51"/>
<wire x1="-1.7" y1="-0.8" x2="-1.7" y2="0.8" width="0.2032" layer="51"/>
<wire x1="-1.7" y1="0.8" x2="-1.1" y2="0.8" width="0.2032" layer="51"/>
<wire x1="1.1" y1="-0.8" x2="1.5" y2="-0.8" width="0.2032" layer="51"/>
<wire x1="1.5" y1="-0.8" x2="1.9" y2="-0.4" width="0.2032" layer="51"/>
<wire x1="1.9" y1="-0.4" x2="1.9" y2="0.4" width="0.2032" layer="51"/>
<wire x1="1.9" y1="0.4" x2="1.5" y2="0.8" width="0.2032" layer="51"/>
<wire x1="1.5" y1="0.8" x2="1.1" y2="0.8" width="0.2032" layer="51"/>
<wire x1="-1.6" y1="0.7" x2="1.6" y2="0.7" width="0.0508" layer="39"/>
<wire x1="1.6" y1="0.7" x2="1.6" y2="-0.7" width="0.0508" layer="39"/>
<wire x1="1.6" y1="-0.7" x2="-1.6" y2="-0.7" width="0.0508" layer="39"/>
<wire x1="-1.6" y1="-0.7" x2="-1.6" y2="0.7" width="0.0508" layer="39"/>
<wire x1="-0.356" y1="0.432" x2="0.356" y2="0.432" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.419" x2="0.356" y2="-0.419" width="0.1016" layer="51"/>
<smd name="-" x="-0.85" y="0" dx="1.1" dy="1" layer="1"/>
<smd name="+" x="0.85" y="0" dx="1.1" dy="1" layer="1"/>
<text x="0" y="0.762" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-0.762" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
<rectangle x1="-0.8382" y1="-0.4699" x2="-0.3381" y2="0.4801" layer="51"/>
<rectangle x1="0.3302" y1="-0.4699" x2="0.8303" y2="0.4801" layer="51"/>
<wire x1="1.651" y1="0.508" x2="1.651" y2="-0.508" width="0.2032" layer="21"/>
</package>
<package name="EIA3528">
<description>Generic EIA 3528 polarized tantalum capacitor</description>
<wire x1="-0.9" y1="-1.6" x2="-2.6" y2="-1.6" width="0.2032" layer="51"/>
<wire x1="-2.6" y1="-1.6" x2="-2.6" y2="1.55" width="0.2032" layer="51"/>
<wire x1="-2.6" y1="1.55" x2="-0.9" y2="1.55" width="0.2032" layer="51"/>
<wire x1="1" y1="-1.55" x2="2.2" y2="-1.55" width="0.2032" layer="51"/>
<wire x1="2.2" y1="-1.55" x2="2.6" y2="-1.2" width="0.2032" layer="51"/>
<wire x1="2.6" y1="-1.2" x2="2.6" y2="1.25" width="0.2032" layer="51"/>
<wire x1="2.6" y1="1.25" x2="2.2" y2="1.55" width="0.2032" layer="51"/>
<wire x1="2.2" y1="1.55" x2="1" y2="1.55" width="0.2032" layer="51"/>
<wire x1="2.641" y1="1.311" x2="2.641" y2="-1.286" width="0.2032" layer="21" style="longdash"/>
<smd name="C" x="-1.65" y="0" dx="2.5" dy="1.2" layer="1" rot="R90"/>
<smd name="A" x="1.65" y="0" dx="2.5" dy="1.2" layer="1" rot="R90"/>
<text x="0" y="1.778" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.778" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
</package>
<package name="CPOL-RADIAL-2.5MM-5MM">
<description>2.5 mm spaced PTHs with 5 mm diameter outline and standard solder mask</description>
<pad name="1" x="1.25" y="0" drill="0.7" diameter="1.651" shape="square"/>
<pad name="2" x="-1.25" y="0" drill="0.7" diameter="1.651"/>
<circle x="0" y="0" radius="2.5" width="0.2032" layer="21"/>
<text x="0" y="2.667" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;Name</text>
<text x="0" y="-2.667" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;Value</text>
<wire x1="-0.742" y1="1.397" x2="-1.758" y2="1.397" width="0.2032" layer="21"/>
<wire x1="1.758" y1="1.397" x2="0.742" y2="1.397" width="0.2032" layer="21"/>
<wire x1="1.25" y1="1.905" x2="1.25" y2="0.889" width="0.2032" layer="21"/>
</package>
<package name="CPOL-RADIAL-2.5MM-5MM-KIT">
<description>2.5 mm spaced PTHs with top copper masked</description>
<circle x="0" y="0" radius="2.5" width="0.2032" layer="21"/>
<pad name="1" x="1.25" y="0" drill="0.7" diameter="1.651" shape="square" stop="no"/>
<pad name="2" x="-1.25" y="0" drill="0.7" diameter="1.651" stop="no"/>
<text x="0" y="2.667" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;Name</text>
<text x="0" y="-2.667" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;Value</text>
<circle x="-1.25" y="0" radius="0.3556" width="0" layer="29"/>
<circle x="-1.25" y="0" radius="0.9652" width="0" layer="30"/>
<circle x="1.25" y="0" radius="0.3556" width="0" layer="29"/>
<rectangle x1="0.2848" y1="-0.9652" x2="2.2152" y2="0.9652" layer="30"/>
<wire x1="-0.742" y1="1.397" x2="-1.758" y2="1.397" width="0.2032" layer="21"/>
<wire x1="1.758" y1="1.397" x2="0.742" y2="1.397" width="0.2032" layer="21"/>
<wire x1="1.25" y1="1.905" x2="1.25" y2="0.889" width="0.2032" layer="21"/>
</package>
<package name="EIA6032-NOM">
<description>Metric Size Code EIA 6032-25 Median (Nominal) Land Protrusion&lt;br /&gt;
http://www.kemet.com/Lists/ProductCatalog/Attachments/254/KEM_T2005_T491.pdf</description>
<wire x1="-3.91" y1="1.5" x2="-2" y2="1.5" width="0.127" layer="51"/>
<wire x1="-3.91" y1="1.5" x2="-3.91" y2="-1.5" width="0.127" layer="51"/>
<wire x1="-3.91" y1="-1.5" x2="-2" y2="-1.5" width="0.127" layer="51"/>
<wire x1="2" y1="1.5" x2="3.5" y2="1.5" width="0.127" layer="51"/>
<wire x1="3.5" y1="1.5" x2="3.91" y2="1" width="0.127" layer="51"/>
<wire x1="3.91" y1="1" x2="3.91" y2="-1" width="0.127" layer="51"/>
<wire x1="3.91" y1="-1" x2="3.5" y2="-1.5" width="0.127" layer="51"/>
<wire x1="3.5" y1="-1.5" x2="2" y2="-1.5" width="0.127" layer="51"/>
<smd name="C" x="-2.47" y="0" dx="2.37" dy="2.23" layer="1" rot="R180"/>
<smd name="A" x="2.47" y="0" dx="2.37" dy="2.23" layer="1" rot="R180"/>
<text x="0" y="1.27" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;Name</text>
<text x="0" y="-1.27" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;Value</text>
<wire x1="3.91" y1="1" x2="3.91" y2="-1" width="0.127" layer="21"/>
</package>
</packages>
<symbols>
<symbol name="CAP">
<wire x1="0" y1="2.54" x2="0" y2="2.032" width="0.1524" layer="94"/>
<wire x1="0" y1="0" x2="0" y2="0.508" width="0.1524" layer="94"/>
<text x="1.524" y="2.921" size="1.778" layer="95" font="vector">&gt;NAME</text>
<text x="1.524" y="-2.159" size="1.778" layer="96" font="vector">&gt;VALUE</text>
<rectangle x1="-2.032" y1="0.508" x2="2.032" y2="1.016" layer="94"/>
<rectangle x1="-2.032" y1="1.524" x2="2.032" y2="2.032" layer="94"/>
<pin name="1" x="0" y="5.08" visible="off" length="short" direction="pas" swaplevel="1" rot="R270"/>
<pin name="2" x="0" y="-2.54" visible="off" length="short" direction="pas" swaplevel="1" rot="R90"/>
</symbol>
<symbol name="CAP_POL">
<wire x1="-2.54" y1="0" x2="2.54" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="-1.016" x2="0" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="0" y1="-1" x2="2.4892" y2="-1.8542" width="0.254" layer="94" curve="-37.878202" cap="flat"/>
<wire x1="-2.4669" y1="-1.8504" x2="0" y2="-1.0161" width="0.254" layer="94" curve="-37.376341" cap="flat"/>
<text x="1.016" y="0.635" size="1.778" layer="95" font="vector">&gt;NAME</text>
<text x="1.016" y="-4.191" size="1.778" layer="96" font="vector">&gt;VALUE</text>
<rectangle x1="-2.253" y1="0.668" x2="-1.364" y2="0.795" layer="94"/>
<rectangle x1="-1.872" y1="0.287" x2="-1.745" y2="1.176" layer="94"/>
<pin name="+" x="0" y="2.54" visible="off" length="short" direction="pas" swaplevel="1" rot="R270"/>
<pin name="-" x="0" y="-5.08" visible="off" length="short" direction="pas" swaplevel="1" rot="R90"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="2.2UF" prefix="C">
<description>&lt;h3&gt;2.2µF ceramic capacitors&lt;/h3&gt;
&lt;p&gt;A capacitor is a passive two-terminal electrical component used to store electrical energy temporarily in an electric field.&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="CAP" x="0" y="0"/>
</gates>
<devices>
<device name="-0603-10V-20%" package="0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-07888" constant="no"/>
<attribute name="VALUE" value="2.2uF" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0805-25V-(+80/-20%)" package="0805">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-11624"/>
<attribute name="VALUE" value="2.2uF"/>
</technology>
</technologies>
</device>
<device name="-1206-50V-10%" package="1206">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-10009"/>
<attribute name="VALUE" value="2.2uF"/>
</technology>
</technologies>
</device>
<device name="-0402_TIGHT-10V-10%-X5R" package="0402-TIGHT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-14232"/>
<attribute name="VALUE" value="2.2uF"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="9.0PF" prefix="C">
<description>&lt;h3&gt;9.0pF ceramic capacitors&lt;/h3&gt;
&lt;p&gt;A capacitor is a passive two-terminal electrical component used to store electrical energy temporarily in an electric field.&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="CAP" x="0" y="0"/>
</gates>
<devices>
<device name="-0603-50V-10%" package="0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-09341"/>
<attribute name="VALUE" value="9.0pF"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="0.1UF" prefix="C">
<description>&lt;h3&gt;0.1µF ceramic capacitors&lt;/h3&gt;
&lt;p&gt;A capacitor is a passive two-terminal electrical component used to store electrical energy temporarily in an electric field.&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="CAP" x="0" y="0"/>
</gates>
<devices>
<device name="-0402-16V-10%" package="0402">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-12416"/>
<attribute name="VALUE" value="0.1uF"/>
</technology>
</technologies>
</device>
<device name="-0603-25V-(+80/-20%)" package="0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-00810"/>
<attribute name="VALUE" value="0.1uF"/>
</technology>
</technologies>
</device>
<device name="-0603-25V-5%" package="0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-08604"/>
<attribute name="VALUE" value="0.1uF"/>
</technology>
</technologies>
</device>
<device name="-KIT-EZ-50V-20%" package="CAP-PTH-SMALL-KIT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-08370"/>
<attribute name="VALUE" value="0.1uF"/>
</technology>
</technologies>
</device>
<device name="-0603-100V-10%" package="0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-08390"/>
<attribute name="VALUE" value="0.1uF"/>
</technology>
</technologies>
</device>
<device name="-0402T-16V-10%" package="0402-TIGHT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-12416" constant="no"/>
<attribute name="VALUE" value="0.1uF" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0402-6.3V-10%-X7R" package="0402">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-14993" constant="no"/>
<attribute name="VALUE" value="0.1uF" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0402-10V-10%-X7R" package="0402">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-15083" constant="no"/>
<attribute name="VALUE" value="0.1uF" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0402T-6.3V-10%-X7R" package="0402-TIGHT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-14993" constant="no"/>
<attribute name="VALUE" value="0.1uF" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0402T-10V-10%-X7R" package="0402-TIGHT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-15083" constant="no"/>
<attribute name="VALUE" value="0.1uF" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0603-100V-10%-X7R-WE" package="0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-16436" constant="no"/>
<attribute name="VALUE" value="0.1uF" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0603-25V-10%-X7R-WE" package="0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-16503" constant="no"/>
<attribute name="VALUE" value="0.1uF" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0402T-16V-10%-X7R-WE" package="0402-TIGHT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-16507" constant="no"/>
<attribute name="VALUE" value="0.1uF" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0603-50V-10%-X7R-WE" package="0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-16523" constant="no"/>
<attribute name="VALUE" value="0.1uF" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="10UF" prefix="C">
<description>&lt;h3&gt;10.0µF ceramic capacitors&lt;/h3&gt;
&lt;p&gt;A capacitor is a passive two-terminal electrical component used to store electrical energy temporarily in an electric field.&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="CAP" x="0" y="0"/>
</gates>
<devices>
<device name="-0603-6.3V-20%" package="0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-11015"/>
<attribute name="VALUE" value="10uF"/>
</technology>
</technologies>
</device>
<device name="-1206-6.3V-20%" package="1206">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-10057"/>
<attribute name="VALUE" value="10uF"/>
</technology>
</technologies>
</device>
<device name="-0805-10V-10%" package="0805">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-11330"/>
<attribute name="VALUE" value="10uF"/>
</technology>
</technologies>
</device>
<device name="-1210-50V-20%" package="1210">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-09824"/>
<attribute name="VALUE" value="10uF"/>
</technology>
</technologies>
</device>
<device name="-0805-25V-10%" package="0805">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-14259"/>
<attribute name="VALUE" value="10uF"/>
</technology>
</technologies>
</device>
<device name="-0402T-6.3V-20%" package="0402-TIGHT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-14848" constant="no"/>
<attribute name="VALUE" value="10uF" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="470NF" prefix="C">
<description>&lt;h3&gt;0.47uF/470nF ceramic capacitors&lt;/h3&gt;
&lt;p&gt;A capacitor is a passive two-terminal electrical component used to store electrical energy temporarily in an electric field.&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="CAP" x="0" y="0"/>
</gates>
<devices>
<device name="-0402-16V-10%" package="0402">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-09041"/>
<attribute name="VALUE" value="470nF"/>
</technology>
</technologies>
</device>
<device name="-0603-10V-10%-X5R" package="0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-13216"/>
<attribute name="VALUE" value="470nF"/>
</technology>
</technologies>
</device>
<device name="-0402_TIGHT-6.3V-10%-X5R" package="0402-TIGHT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-14242"/>
<attribute name="VALUE" value="0.47uF"/>
</technology>
</technologies>
</device>
<device name="-0805-100V-10%-X7S" package="0805">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-16570" constant="no"/>
<attribute name="VALUE" value="470nF" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="10NF" prefix="C">
<description>&lt;h3&gt;0.01uF/10nF/10,000pF ceramic capacitors&lt;/h3&gt;
&lt;p&gt;A capacitor is a passive two-terminal electrical component used to store electrical energy temporarily in an electric field.&lt;/p&gt;

CAP-09321</description>
<gates>
<gate name="G$1" symbol="CAP" x="0" y="0"/>
</gates>
<devices>
<device name="-PTH-10MM-10000V-1-%" package="CAP-PTH-10MM">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-09321"/>
<attribute name="VALUE" value="10nF"/>
</technology>
</technologies>
</device>
<device name="-0603-50V-10%" package="0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-00867"/>
<attribute name="VALUE" value="10nF"/>
</technology>
</technologies>
</device>
<device name="-0402T-25V-10%" package="0402-TIGHT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-14847" constant="no"/>
<attribute name="VALUE" value="10nF" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0402T-25V-10%-X7R-WE" package="0402-TIGHT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-16508" constant="no"/>
<attribute name="VALUE" value="10nF" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="100UF-POLAR" prefix="C">
<description>&lt;h3&gt;100µF polarized capacitors&lt;/h3&gt;
&lt;p&gt;A capacitor is a passive two-terminal electrical component used to store electrical energy temporarily in an electric field.&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="CAP_POL" x="0" y="0"/>
</gates>
<devices>
<device name="-EIA7343-10V-10%(TANT)" package="EIA7343">
<connects>
<connect gate="G$1" pin="+" pad="A"/>
<connect gate="G$1" pin="-" pad="C"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-07890"/>
<attribute name="VALUE" value="100uF"/>
</technology>
</technologies>
</device>
<device name="-EIA7343-16V-10%(TANT)" package="EIA7343">
<connects>
<connect gate="G$1" pin="+" pad="A"/>
<connect gate="G$1" pin="-" pad="C"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-08702"/>
<attribute name="VALUE" value="100uF"/>
</technology>
</technologies>
</device>
<device name="-RADIAL-2.5MM-25V-20%" package="CPOL-RADIAL-2.5MM-6.5MM">
<connects>
<connect gate="G$1" pin="+" pad="1"/>
<connect gate="G$1" pin="-" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-08439"/>
<attribute name="VALUE" value="100uF"/>
</technology>
</technologies>
</device>
<device name="-10X10.5-63V-20%" package="NIC_10X10.5_CAP">
<connects>
<connect gate="G$1" pin="+" pad="+"/>
<connect gate="G$1" pin="-" pad="-"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-08362"/>
<attribute name="VALUE" value="100uF"/>
</technology>
</technologies>
</device>
<device name="-25V-20%(ELEC)" package="PANASONIC_D">
<connects>
<connect gate="G$1" pin="+" pad="+"/>
<connect gate="G$1" pin="-" pad="-"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-12547" constant="no"/>
<attribute name="VALUE" value="100uF" constant="no"/>
</technology>
</technologies>
</device>
<device name="-1206-6.3V-20%(TANT)" package="1206-POLAR">
<connects>
<connect gate="G$1" pin="+" pad="1"/>
<connect gate="G$1" pin="-" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-14093" constant="no"/>
<attribute name="VALUE" value="100uF" constant="no"/>
</technology>
</technologies>
</device>
<device name="-8X10.5-50V" package="8X10.5">
<connects>
<connect gate="G$1" pin="+" pad="+"/>
<connect gate="G$1" pin="-" pad="-"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-15455" constant="no"/>
<attribute name="VALUE" value="100uF" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="10UF-POLAR" prefix="C">
<description>&lt;h3&gt;10.0µF polarized capacitors&lt;/h3&gt;
&lt;p&gt;A capacitor is a passive two-terminal electrical component used to store electrical energy temporarily in an electric field.&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="CAP_POL" x="0" y="0"/>
</gates>
<devices>
<device name="-EIA3216-16V-10%(TANT)" package="EIA3216">
<connects>
<connect gate="G$1" pin="+" pad="+"/>
<connect gate="G$1" pin="-" pad="-"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-00811"/>
<attribute name="VALUE" value="10uF"/>
</technology>
</technologies>
</device>
<device name="-0603-6.3V-20%(TANT)" package="0603-POLAR">
<connects>
<connect gate="G$1" pin="+" pad="+"/>
<connect gate="G$1" pin="-" pad="-"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-13210"/>
<attribute name="VALUE" value="10uF"/>
</technology>
</technologies>
</device>
<device name="-EIA3528-20V-10%(TANT)" package="EIA3528">
<connects>
<connect gate="G$1" pin="+" pad="A"/>
<connect gate="G$1" pin="-" pad="C"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-08063"/>
<attribute name="VALUE" value="10uF"/>
</technology>
</technologies>
</device>
<device name="-RADIAL-2.5MM-25V-20%" package="CPOL-RADIAL-2.5MM-5MM">
<connects>
<connect gate="G$1" pin="+" pad="1"/>
<connect gate="G$1" pin="-" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-08440"/>
<attribute name="VALUE" value="10uF"/>
</technology>
</technologies>
</device>
<device name="-RADIAL-2.5MM-KIT-25V-20%" package="CPOL-RADIAL-2.5MM-5MM-KIT">
<connects>
<connect gate="G$1" pin="+" pad="1"/>
<connect gate="G$1" pin="-" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-08440"/>
<attribute name="VALUE" value="10uF"/>
</technology>
</technologies>
</device>
<device name="-EIA6032-25V-10%" package="EIA6032-NOM">
<connects>
<connect gate="G$1" pin="+" pad="A"/>
<connect gate="G$1" pin="-" pad="C"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CAP-12984"/>
<attribute name="VALUE" value="10µF"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="SparkFun-IC-Power">
<description>&lt;h3&gt;SparkFun Power Driver and Management ICs&lt;/h3&gt;
In this library you'll find anything that has to do with power delivery, or making power supplies.
&lt;p&gt;Contents:
&lt;ul&gt;&lt;li&gt;LDOs&lt;/li&gt;
&lt;li&gt;Boost/Buck controllers&lt;/li&gt;
&lt;li&gt;Charge pump controllers&lt;/li&gt;
&lt;li&gt;Power sequencers&lt;/li&gt;
&lt;li&gt;Power switches&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;
&lt;br&gt;
We've spent an enormous amount of time creating and checking these footprints and parts, but it is &lt;b&gt; the end user's responsibility&lt;/b&gt; to ensure correctness and suitablity for a given componet or application. 
&lt;br&gt;
&lt;br&gt;If you enjoy using this library, please buy one of our products at &lt;a href=" www.sparkfun.com"&gt;SparkFun.com&lt;/a&gt;.
&lt;br&gt;
&lt;br&gt;
&lt;b&gt;Licensing:&lt;/b&gt; Creative Commons ShareAlike 4.0 International - https://creativecommons.org/licenses/by-sa/4.0/ 
&lt;br&gt;
&lt;br&gt;
You are welcome to use this library for commercial purposes. For attribution, we ask that when you begin to sell your device using our footprint, you email us with a link to the product being sold. We want bragging rights that we helped (in a very small part) to create your 8th world wonder. We would like the opportunity to feature your device on our homepage.</description>
<packages>
<package name="SOT23-5">
<description>&lt;b&gt;Small Outline Transistor&lt;/b&gt;</description>
<circle x="-1.6002" y="-1.016" radius="0.127" width="0" layer="21"/>
<wire x1="1.27" y1="0.4294" x2="1.27" y2="-0.4294" width="0.2032" layer="21"/>
<wire x1="1.4" y1="-0.8" x2="-1.4" y2="-0.8" width="0.1524" layer="51"/>
<wire x1="-1.27" y1="-0.4294" x2="-1.27" y2="0.4294" width="0.2032" layer="21"/>
<wire x1="-1.4" y1="0.8" x2="1.4" y2="0.8" width="0.1524" layer="51"/>
<wire x1="-0.2684" y1="0.7088" x2="0.2684" y2="0.7088" width="0.2032" layer="21"/>
<wire x1="1.4" y1="0.8" x2="1.4" y2="-0.8" width="0.1524" layer="51"/>
<wire x1="-1.4" y1="0.8" x2="-1.4" y2="-0.8" width="0.1524" layer="51"/>
<rectangle x1="-1.2" y1="-1.5" x2="-0.7" y2="-0.85" layer="51"/>
<rectangle x1="-0.25" y1="-1.5" x2="0.25" y2="-0.85" layer="51"/>
<rectangle x1="0.7" y1="-1.5" x2="1.2" y2="-0.85" layer="51"/>
<rectangle x1="0.7" y1="0.85" x2="1.2" y2="1.5" layer="51"/>
<rectangle x1="-1.2" y1="0.85" x2="-0.7" y2="1.5" layer="51"/>
<smd name="1" x="-0.95" y="-1.3001" dx="0.55" dy="1.2" layer="1"/>
<smd name="2" x="0" y="-1.3001" dx="0.55" dy="1.2" layer="1"/>
<smd name="3" x="0.95" y="-1.3001" dx="0.55" dy="1.2" layer="1"/>
<smd name="4" x="0.95" y="1.3001" dx="0.55" dy="1.2" layer="1"/>
<smd name="5" x="-0.95" y="1.3001" dx="0.55" dy="1.2" layer="1"/>
<text x="-1.778" y="2.159" size="0.6096" layer="25" ratio="20">&gt;NAME</text>
<text x="-1.778" y="-2.794" size="0.6096" layer="27" ratio="20">&gt;VALUE</text>
</package>
</packages>
<symbols>
<symbol name="V-REG-LDO_NO-BP">
<description>&lt;h3&gt; Voltage Regulator - No bypass&lt;/h3&gt;
5  pin, with Enable function.</description>
<wire x1="-7.62" y1="-7.62" x2="5.08" y2="-7.62" width="0.4064" layer="94"/>
<wire x1="5.08" y1="-7.62" x2="5.08" y2="7.62" width="0.4064" layer="94"/>
<wire x1="5.08" y1="7.62" x2="-7.62" y2="7.62" width="0.4064" layer="94"/>
<wire x1="-7.62" y1="7.62" x2="-7.62" y2="-7.62" width="0.4064" layer="94"/>
<text x="-7.62" y="7.874" size="1.778" layer="95" font="vector">&gt;NAME</text>
<text x="-7.62" y="-7.874" size="1.778" layer="96" font="vector" align="top-left">&gt;VALUE</text>
<pin name="IN" x="-10.16" y="5.08" visible="pin" length="short" direction="in"/>
<pin name="GND" x="-10.16" y="-5.08" visible="pin" length="short" direction="in"/>
<pin name="OUT" x="7.62" y="5.08" visible="pin" length="short" direction="pas" rot="R180"/>
<pin name="EN" x="-10.16" y="0" visible="pin" length="short" direction="in"/>
<pin name="NC" x="7.62" y="-5.08" visible="pin" length="short" direction="nc" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="V_REG_LP5907" prefix="U">
<description>&lt;h3&gt;LP5907 - 250mA Ultra-Low-Noise LDO Regulator w/ Enable&lt;/h3&gt;
&lt;p&gt;The LP5907 is a low-noise LDO that can supply up to
250 mA output current. Designed to meet the
requirements of RF and analog circuits, the LP5907
device provides low noise, high PSRR, low quiescent
current, and low line or load transient response
figures. Using new innovative design techniques, the
LP5907 offers class-leading noise performance
without a noise bypass capacitor and the ability for
remote output capacitor placement.
The device is designed to work with a 1-µF input and
a 1-µF output ceramic capacitor (no separate noise
bypass capacitor is required).
This device is available with fixed output voltages
from 1.2 V to 4.5 V in 25-mV steps.&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="V-REG-LDO_NO-BP" x="0" y="0"/>
</gates>
<devices>
<device name="SOT23-3.0V" package="SOT23-5">
<connects>
<connect gate="G$1" pin="EN" pad="3"/>
<connect gate="G$1" pin="GND" pad="2"/>
<connect gate="G$1" pin="IN" pad="1"/>
<connect gate="G$1" pin="NC" pad="4"/>
<connect gate="G$1" pin="OUT" pad="5"/>
</connects>
<technologies>
<technology name="">
<attribute name="DIGIKEY_PART" value="296-40357-1-ND" constant="no"/>
<attribute name="MANU_PART" value="LP5907MFX-3.0/NOPB" constant="no"/>
<attribute name="MOUSER_PART" value="595-LP5907MFX-3.0NPB" constant="no"/>
<attribute name="PACKAGE" value="SOT-23(5)" constant="no"/>
<attribute name="PROD_ID" value="VREG-15586"/>
<attribute name="VALUE" value="3.0V"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="SparkFun-Resistors">
<description>&lt;h3&gt;SparkFun Resistors&lt;/h3&gt;
This library contains resistors. Reference designator:R. 
&lt;br&gt;
&lt;br&gt;
We've spent an enormous amount of time creating and checking these footprints and parts, but it is &lt;b&gt; the end user's responsibility&lt;/b&gt; to ensure correctness and suitablity for a given componet or application. 
&lt;br&gt;
&lt;br&gt;If you enjoy using this library, please buy one of our products at &lt;a href=" www.sparkfun.com"&gt;SparkFun.com&lt;/a&gt;.
&lt;br&gt;
&lt;br&gt;
&lt;b&gt;Licensing:&lt;/b&gt; Creative Commons ShareAlike 4.0 International - https://creativecommons.org/licenses/by-sa/4.0/ 
&lt;br&gt;
&lt;br&gt;
You are welcome to use this library for commercial purposes. For attribution, we ask that when you begin to sell your device using our footprint, you email us with a link to the product being sold. We want bragging rights that we helped (in a very small part) to create your 8th world wonder. We would like the opportunity to feature your device on our homepage.</description>
<packages>
<package name="0603" urn="urn:adsk.eagle:footprint:39615/1" library_version="1">
<description>&lt;p&gt;&lt;b&gt;Generic 1608 (0603) package&lt;/b&gt;&lt;/p&gt;
&lt;p&gt;0.2mm courtyard excess rounded to nearest 0.05mm.&lt;/p&gt;</description>
<wire x1="-1.6" y1="0.7" x2="1.6" y2="0.7" width="0.0508" layer="39"/>
<wire x1="1.6" y1="0.7" x2="1.6" y2="-0.7" width="0.0508" layer="39"/>
<wire x1="1.6" y1="-0.7" x2="-1.6" y2="-0.7" width="0.0508" layer="39"/>
<wire x1="-1.6" y1="-0.7" x2="-1.6" y2="0.7" width="0.0508" layer="39"/>
<wire x1="-0.356" y1="0.432" x2="0.356" y2="0.432" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.419" x2="0.356" y2="-0.419" width="0.1016" layer="51"/>
<smd name="1" x="-0.85" y="0" dx="1.1" dy="1" layer="1"/>
<smd name="2" x="0.85" y="0" dx="1.1" dy="1" layer="1"/>
<text x="0" y="0.762" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-0.762" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
<rectangle x1="-0.8382" y1="-0.4699" x2="-0.3381" y2="0.4801" layer="51"/>
<rectangle x1="0.3302" y1="-0.4699" x2="0.8303" y2="0.4801" layer="51"/>
<rectangle x1="-0.1999" y1="-0.3" x2="0.1999" y2="0.3" layer="35"/>
</package>
<package name="0402-TIGHT">
<smd name="1" x="-0.5" y="0" dx="0.6" dy="0.6" layer="1"/>
<smd name="2" x="0.5" y="0" dx="0.6" dy="0.6" layer="1"/>
<text x="0" y="0.562" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-0.562" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
<wire x1="-0.5" y1="-0.25" x2="-0.5" y2="0.25" width="0.002540625" layer="51"/>
<wire x1="-0.5" y1="0.25" x2="0.5" y2="0.25" width="0.002540625" layer="51"/>
<wire x1="0.5" y1="0.25" x2="0.5" y2="-0.25" width="0.002540625" layer="51"/>
<wire x1="0.5" y1="-0.25" x2="-0.5" y2="-0.25" width="0.002540625" layer="51"/>
<rectangle x1="-0.5" y1="-0.25" x2="-0.3" y2="0.25" layer="51"/>
<rectangle x1="0.3" y1="-0.25" x2="0.5" y2="0.25" layer="51" rot="R180"/>
<wire x1="0.9262" y1="0.4262" x2="-0.9262" y2="0.4262" width="0.05" layer="39"/>
<wire x1="-0.9262" y1="0.4262" x2="-0.9262" y2="-0.4262" width="0.05" layer="39"/>
<wire x1="-0.9262" y1="-0.4262" x2="0.9262" y2="-0.4262" width="0.05" layer="39"/>
<wire x1="0.9262" y1="-0.4262" x2="0.9262" y2="0.4262" width="0.05" layer="39"/>
</package>
<package name="AXIAL-0.3">
<description>&lt;h3&gt;AXIAL-0.3&lt;/h3&gt;
&lt;p&gt;Commonly used for 1/4W through-hole resistors. 0.3" pitch between holes.&lt;/p&gt;</description>
<wire x1="-2.54" y1="0.762" x2="2.54" y2="0.762" width="0.2032" layer="21"/>
<wire x1="2.54" y1="0.762" x2="2.54" y2="0" width="0.2032" layer="21"/>
<wire x1="2.54" y1="0" x2="2.54" y2="-0.762" width="0.2032" layer="21"/>
<wire x1="2.54" y1="-0.762" x2="-2.54" y2="-0.762" width="0.2032" layer="21"/>
<wire x1="-2.54" y1="-0.762" x2="-2.54" y2="0" width="0.2032" layer="21"/>
<wire x1="-2.54" y1="0" x2="-2.54" y2="0.762" width="0.2032" layer="21"/>
<wire x1="2.54" y1="0" x2="2.794" y2="0" width="0.2032" layer="21"/>
<wire x1="-2.54" y1="0" x2="-2.794" y2="0" width="0.2032" layer="21"/>
<pad name="P$1" x="-3.81" y="0" drill="0.9" diameter="1.8796"/>
<pad name="P$2" x="3.81" y="0" drill="0.9" diameter="1.8796"/>
<text x="0" y="1.016" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;Name</text>
<text x="0" y="-1.016" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;Value</text>
</package>
<package name="AXIAL-0.1">
<description>&lt;h3&gt;AXIAL-0.1&lt;/h3&gt;
&lt;p&gt;Commonly used for 1/4W through-hole resistors. 0.1" pitch between holes.&lt;/p&gt;</description>
<wire x1="0" y1="-0.762" x2="0" y2="0" width="0.2032" layer="21"/>
<wire x1="0" y1="0" x2="0" y2="0.762" width="0.2032" layer="21"/>
<wire x1="0.254" y1="0" x2="0" y2="0" width="0.2032" layer="21"/>
<wire x1="0" y1="0" x2="-0.254" y2="0" width="0.2032" layer="21"/>
<pad name="P$1" x="-1.27" y="0" drill="0.9" diameter="1.8796"/>
<pad name="P$2" x="1.27" y="0" drill="0.9" diameter="1.8796"/>
<text x="0" y="1.143" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;Name</text>
<text x="0" y="-1.143" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;Value</text>
</package>
<package name="AXIAL-0.1-KIT">
<description>&lt;h3&gt;AXIAL-0.1-KIT&lt;/h3&gt;
&lt;p&gt;Commonly used for 1/4W through-hole resistors. 0.1" pitch between holes.&lt;/p&gt;
&lt;p&gt;&lt;b&gt;Warning:&lt;/b&gt; This is the KIT version of the AXIAL-0.1 package. This package has a smaller diameter top stop mask, which doesn't cover the diameter of the pad. This means only the bottom side of the pads' copper will be exposed. You'll only be able to solder to the bottom side.&lt;/p&gt;</description>
<wire x1="0" y1="-0.762" x2="0" y2="0" width="0.2032" layer="21"/>
<wire x1="0" y1="0" x2="0" y2="0.762" width="0.2032" layer="21"/>
<wire x1="0.254" y1="0" x2="0" y2="0" width="0.2032" layer="21"/>
<wire x1="0" y1="0" x2="-0.254" y2="0" width="0.2032" layer="21"/>
<pad name="P$1" x="-1.27" y="0" drill="0.9" diameter="1.8796" stop="no"/>
<pad name="P$2" x="1.27" y="0" drill="0.9" diameter="1.8796" stop="no"/>
<text x="0" y="1.143" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;Name</text>
<text x="0" y="-1.143" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;Value</text>
<circle x="-1.27" y="0" radius="0.4572" width="0" layer="29"/>
<circle x="-1.27" y="0" radius="1.016" width="0" layer="30"/>
<circle x="1.27" y="0" radius="1.016" width="0" layer="30"/>
<circle x="-1.27" y="0" radius="0.4572" width="0" layer="29"/>
<circle x="1.27" y="0" radius="0.4572" width="0" layer="29"/>
</package>
<package name="AXIAL-0.3-KIT">
<description>&lt;h3&gt;AXIAL-0.3-KIT&lt;/h3&gt;
&lt;p&gt;Commonly used for 1/4W through-hole resistors. 0.3" pitch between holes.&lt;/p&gt;
&lt;p&gt;&lt;b&gt;Warning:&lt;/b&gt; This is the KIT version of the AXIAL-0.3 package. This package has a smaller diameter top stop mask, which doesn't cover the diameter of the pad. This means only the bottom side of the pads' copper will be exposed. You'll only be able to solder to the bottom side.&lt;/p&gt;</description>
<wire x1="-2.54" y1="1.27" x2="2.54" y2="1.27" width="0.254" layer="21"/>
<wire x1="2.54" y1="1.27" x2="2.54" y2="0" width="0.254" layer="21"/>
<wire x1="2.54" y1="0" x2="2.54" y2="-1.27" width="0.254" layer="21"/>
<wire x1="2.54" y1="-1.27" x2="-2.54" y2="-1.27" width="0.254" layer="21"/>
<wire x1="-2.54" y1="-1.27" x2="-2.54" y2="0" width="0.254" layer="21"/>
<wire x1="-2.54" y1="0" x2="-2.54" y2="1.27" width="0.254" layer="21"/>
<wire x1="2.54" y1="0" x2="2.794" y2="0" width="0.254" layer="21"/>
<wire x1="-2.54" y1="0" x2="-2.794" y2="0" width="0.254" layer="21"/>
<pad name="P$1" x="-3.81" y="0" drill="1.016" diameter="2.032" stop="no"/>
<pad name="P$2" x="3.81" y="0" drill="1.016" diameter="2.032" stop="no"/>
<text x="0" y="1.524" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.524" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
<polygon width="0.127" layer="30">
<vertex x="3.8201" y="-0.9449" curve="-90"/>
<vertex x="2.8652" y="-0.0152" curve="-90.011749"/>
<vertex x="3.8176" y="0.9602" curve="-90"/>
<vertex x="4.7676" y="-0.0178" curve="-90.024193"/>
</polygon>
<polygon width="0.127" layer="29">
<vertex x="3.8176" y="-0.4369" curve="-90.012891"/>
<vertex x="3.3731" y="-0.0127" curve="-90"/>
<vertex x="3.8176" y="0.4546" curve="-90"/>
<vertex x="4.2595" y="-0.0025" curve="-90.012967"/>
</polygon>
<polygon width="0.127" layer="30">
<vertex x="-3.8075" y="-0.9525" curve="-90"/>
<vertex x="-4.7624" y="-0.0228" curve="-90.011749"/>
<vertex x="-3.81" y="0.9526" curve="-90"/>
<vertex x="-2.86" y="-0.0254" curve="-90.024193"/>
</polygon>
<polygon width="0.127" layer="29">
<vertex x="-3.81" y="-0.4445" curve="-90.012891"/>
<vertex x="-4.2545" y="-0.0203" curve="-90"/>
<vertex x="-3.81" y="0.447" curve="-90"/>
<vertex x="-3.3681" y="-0.0101" curve="-90.012967"/>
</polygon>
</package>
<package name="0402">
<description>&lt;p&gt;&lt;b&gt;Generic 1005 (0402) package&lt;/b&gt;&lt;/p&gt;
&lt;p&gt;0.2mm courtyard excess rounded to nearest 0.05mm.&lt;/p&gt;</description>
<wire x1="-0.2704" y1="0.2286" x2="0.2704" y2="0.2286" width="0.1524" layer="51"/>
<wire x1="0.2704" y1="-0.2286" x2="-0.2704" y2="-0.2286" width="0.1524" layer="51"/>
<wire x1="-1.2" y1="0.65" x2="1.2" y2="0.65" width="0.0508" layer="39"/>
<wire x1="1.2" y1="0.65" x2="1.2" y2="-0.65" width="0.0508" layer="39"/>
<wire x1="1.2" y1="-0.65" x2="-1.2" y2="-0.65" width="0.0508" layer="39"/>
<wire x1="-1.2" y1="-0.65" x2="-1.2" y2="0.65" width="0.0508" layer="39"/>
<smd name="1" x="-0.58" y="0" dx="0.85" dy="0.9" layer="1"/>
<smd name="2" x="0.58" y="0" dx="0.85" dy="0.9" layer="1"/>
<text x="0" y="0.762" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-0.762" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
<rectangle x1="-0.554" y1="-0.3048" x2="-0.254" y2="0.3048" layer="51"/>
<rectangle x1="0.2588" y1="-0.3048" x2="0.5588" y2="0.3048" layer="51"/>
<rectangle x1="-0.1999" y1="-0.3" x2="0.1999" y2="0.3" layer="35"/>
</package>
<package name="1206">
<description>&lt;p&gt;&lt;b&gt;Generic 3216 (1206) package&lt;/b&gt;&lt;/p&gt;
&lt;p&gt;0.2mm courtyard excess rounded to nearest 0.05mm.&lt;/p&gt;</description>
<wire x1="-2.4" y1="1.1" x2="2.4" y2="1.1" width="0.0508" layer="39"/>
<wire x1="2.4" y1="-1.1" x2="-2.4" y2="-1.1" width="0.0508" layer="39"/>
<wire x1="-2.4" y1="-1.1" x2="-2.4" y2="1.1" width="0.0508" layer="39"/>
<wire x1="2.4" y1="1.1" x2="2.4" y2="-1.1" width="0.0508" layer="39"/>
<wire x1="-0.965" y1="0.787" x2="0.965" y2="0.787" width="0.1016" layer="51"/>
<wire x1="-0.965" y1="-0.787" x2="0.965" y2="-0.787" width="0.1016" layer="51"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<text x="0" y="1.143" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.143" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
<rectangle x1="-1.7018" y1="-0.8509" x2="-0.9517" y2="0.8491" layer="51"/>
<rectangle x1="0.9517" y1="-0.8491" x2="1.7018" y2="0.8509" layer="51"/>
<rectangle x1="-0.1999" y1="-0.4001" x2="0.1999" y2="0.4001" layer="35"/>
</package>
<package name="AXIAL-0.3EZ">
<description>This is the "EZ" version of the standard .3" spaced resistor package.&lt;br&gt;
It has a reduced top mask to make it harder to install upside-down.</description>
<wire x1="-2.54" y1="0.762" x2="2.54" y2="0.762" width="0.2032" layer="21"/>
<wire x1="2.54" y1="0.762" x2="2.54" y2="0" width="0.2032" layer="21"/>
<wire x1="2.54" y1="0" x2="2.54" y2="-0.762" width="0.2032" layer="21"/>
<wire x1="2.54" y1="-0.762" x2="-2.54" y2="-0.762" width="0.2032" layer="21"/>
<wire x1="-2.54" y1="-0.762" x2="-2.54" y2="0" width="0.2032" layer="21"/>
<wire x1="-2.54" y1="0" x2="-2.54" y2="0.762" width="0.2032" layer="21"/>
<wire x1="2.54" y1="0" x2="2.794" y2="0" width="0.2032" layer="21"/>
<wire x1="-2.54" y1="0" x2="-2.794" y2="0" width="0.2032" layer="21"/>
<pad name="P$1" x="-3.81" y="0" drill="0.9" diameter="1.8796" stop="no"/>
<pad name="P$2" x="3.81" y="0" drill="0.9" diameter="1.8796" stop="no"/>
<text x="0" y="1.016" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;Name</text>
<text x="0" y="-1.016" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;Value</text>
<circle x="-3.81" y="0" radius="0.508" width="0" layer="29"/>
<circle x="3.81" y="0" radius="0.523634375" width="0" layer="29"/>
<circle x="-3.81" y="0" radius="1.02390625" width="0" layer="30"/>
<circle x="3.81" y="0" radius="1.04726875" width="0" layer="30"/>
</package>
</packages>
<symbols>
<symbol name="RESISTOR">
<wire x1="-2.54" y1="0" x2="-2.159" y2="1.016" width="0.1524" layer="94"/>
<wire x1="-2.159" y1="1.016" x2="-1.524" y2="-1.016" width="0.1524" layer="94"/>
<wire x1="-1.524" y1="-1.016" x2="-0.889" y2="1.016" width="0.1524" layer="94"/>
<wire x1="-0.889" y1="1.016" x2="-0.254" y2="-1.016" width="0.1524" layer="94"/>
<wire x1="-0.254" y1="-1.016" x2="0.381" y2="1.016" width="0.1524" layer="94"/>
<wire x1="0.381" y1="1.016" x2="1.016" y2="-1.016" width="0.1524" layer="94"/>
<wire x1="1.016" y1="-1.016" x2="1.651" y2="1.016" width="0.1524" layer="94"/>
<wire x1="1.651" y1="1.016" x2="2.286" y2="-1.016" width="0.1524" layer="94"/>
<wire x1="2.286" y1="-1.016" x2="2.54" y2="0" width="0.1524" layer="94"/>
<text x="0" y="1.524" size="1.778" layer="95" font="vector" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.524" size="1.778" layer="96" font="vector" align="top-center">&gt;VALUE</text>
<pin name="2" x="5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1" rot="R180"/>
<pin name="1" x="-5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="220OHM" prefix="R">
<description>&lt;h3&gt;220Ω resistor&lt;/h3&gt;
&lt;p&gt;A resistor is a passive two-terminal electrical component that implements electrical resistance as a circuit element. Resistors act to reduce current flow, and, at the same time, act to lower voltage levels within circuits. - Wikipedia&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="RESISTOR" x="0" y="0"/>
</gates>
<devices>
<device name="-0603-1/10W-1%" package="0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-07861"/>
<attribute name="VALUE" value="220"/>
</technology>
</technologies>
</device>
<device name="-0402-TIGHT-1/16W-1%" package="0402-TIGHT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-15269" constant="no"/>
<attribute name="VALUE" value="220" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="1KOHM" prefix="R">
<description>&lt;h3&gt;1kΩ resistor&lt;/h3&gt;
&lt;p&gt;A resistor is a passive two-terminal electrical component that implements electrical resistance as a circuit element. Resistors act to reduce current flow, and, at the same time, act to lower voltage levels within circuits. - Wikipedia&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="RESISTOR" x="0" y="0"/>
</gates>
<devices>
<device name="-HORIZ-1/4W-1%" package="AXIAL-0.3">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-12182"/>
<attribute name="VALUE" value="1k"/>
</technology>
</technologies>
</device>
<device name="-VERT-1/4W-1%" package="AXIAL-0.1">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-12182"/>
<attribute name="VALUE" value="1k"/>
</technology>
</technologies>
</device>
<device name="-VERT_KIT-1/4W-1%" package="AXIAL-0.1-KIT">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-12182"/>
<attribute name="VALUE" value="1k"/>
</technology>
</technologies>
</device>
<device name="-HORIZ_KIT-1/4W-1%" package="AXIAL-0.3-KIT">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-12182"/>
<attribute name="VALUE" value="1k"/>
</technology>
</technologies>
</device>
<device name="-VERT-1/4W-5%" package="AXIAL-0.1">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-08380"/>
<attribute name="VALUE" value="1k"/>
</technology>
</technologies>
</device>
<device name="-VERT_KIT-1/4W-5%" package="AXIAL-0.1-KIT">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-08380"/>
<attribute name="VALUE" value="1k"/>
</technology>
</technologies>
</device>
<device name="-HORIZ-1/4W-5%" package="AXIAL-0.3">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-08380"/>
<attribute name="VALUE" value="1k"/>
</technology>
</technologies>
</device>
<device name="-HORIZ_KIT-1/4W-5%" package="AXIAL-0.3-KIT">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-08380"/>
<attribute name="VALUE" value="1k"/>
</technology>
</technologies>
</device>
<device name="-VERT-1/6W-5%" package="AXIAL-0.1">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-09769"/>
<attribute name="VALUE" value="1k"/>
</technology>
</technologies>
</device>
<device name="-0603-1/10W-1%" package="0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-07856"/>
<attribute name="VALUE" value="1k"/>
</technology>
</technologies>
</device>
<device name="-0402-1/16W-1%" package="0402">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-14342" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0402T-1/16W-1%" package="0402-TIGHT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-14342" constant="no"/>
<attribute name="VALUE" value="1k" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="22OHM" prefix="R">
<description>&lt;h3&gt;22Ω resistor&lt;/h3&gt;
&lt;p&gt;A resistor is a passive two-terminal electrical component that implements electrical resistance as a circuit element. Resistors act to reduce current flow, and, at the same time, act to lower voltage levels within circuits. - Wikipedia&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="RESISTOR" x="0" y="0"/>
</gates>
<devices>
<device name="-0402-1/10W-1%" package="0402">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-12427"/>
<attribute name="VALUE" value="22Ω"/>
</technology>
</technologies>
</device>
<device name="-0603-1/10W-1%" package="0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-08698"/>
<attribute name="VALUE" value="22Ω"/>
</technology>
</technologies>
</device>
<device name="-0402T-1/16W-1%" package="0402-TIGHT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-12427" constant="no"/>
<attribute name="VALUE" value="22Ω" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="1MOHM" prefix="R">
<description>&lt;h3&gt;1MΩ resistor&lt;/h3&gt;
&lt;p&gt;A resistor is a passive two-terminal electrical component that implements electrical resistance as a circuit element. Resistors act to reduce current flow, and, at the same time, act to lower voltage levels within circuits. - Wikipedia&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="RESISTOR" x="0" y="0"/>
</gates>
<devices>
<device name="-VERT-1/4W-5%" package="AXIAL-0.1">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-09329"/>
<attribute name="VALUE" value="1M"/>
</technology>
</technologies>
</device>
<device name="-VERT_KIT-1/4W-5%" package="AXIAL-0.1-KIT">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-09329"/>
<attribute name="VALUE" value="1M"/>
</technology>
</technologies>
</device>
<device name="-HORIZ-1/4W-5%" package="AXIAL-0.3">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-09329"/>
<attribute name="VALUE" value="1M"/>
</technology>
</technologies>
</device>
<device name="-HORIZ_KIT-1/4W-5%" package="AXIAL-0.3-KIT">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-09329"/>
<attribute name="VALUE" value="1M"/>
</technology>
</technologies>
</device>
<device name="-0603-1/4W-5%" package="0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-07868"/>
<attribute name="VALUE" value="1M"/>
</technology>
</technologies>
</device>
<device name="-VERT-1/6W-5%" package="AXIAL-0.1">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-09559"/>
<attribute name="VALUE" value="1M"/>
</technology>
</technologies>
</device>
<device name="-VERT_KIT-1/6W-5%" package="AXIAL-0.1-KIT">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-09559"/>
<attribute name="VALUE" value="1M"/>
</technology>
</technologies>
</device>
<device name="-HORIZ-1/6W-5%" package="AXIAL-0.3">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-09559"/>
<attribute name="VALUE" value="1M"/>
</technology>
</technologies>
</device>
<device name="-HORIZ_KIT-1/6W-5%" package="AXIAL-0.3-KIT">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-09559"/>
<attribute name="VALUE" value="1M"/>
</technology>
</technologies>
</device>
<device name="-0402-1/16W-5%" package="0402">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-15185"/>
<attribute name="VALUE" value="1M"/>
</technology>
</technologies>
</device>
<device name="-0402T-1/16W-5%" package="0402-TIGHT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-15185"/>
<attribute name="VALUE" value="1M"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="100KOHM" prefix="R">
<description>&lt;h3&gt;100kΩ resistor&lt;/h3&gt;
&lt;p&gt;A resistor is a passive two-terminal electrical component that implements electrical resistance as a circuit element. Resistors act to reduce current flow, and, at the same time, act to lower voltage levels within circuits. - Wikipedia&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="RESISTOR" x="0" y="0"/>
</gates>
<devices>
<device name="-HORIZ-1/4W-1%" package="AXIAL-0.3">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-12184"/>
<attribute name="VALUE" value="100k" constant="no"/>
</technology>
</technologies>
</device>
<device name="-VERT-1/4W-1%" package="AXIAL-0.1">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-12184"/>
<attribute name="VALUE" value="100k"/>
</technology>
</technologies>
</device>
<device name="-VERT_KIT-1/4W-1%" package="AXIAL-0.1-KIT">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-12184"/>
<attribute name="VALUE" value="100k" constant="no"/>
</technology>
</technologies>
</device>
<device name="-HORIZ_KIT-1/4W-1%" package="AXIAL-0.3-KIT">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-12184"/>
<attribute name="VALUE" value="100k"/>
</technology>
</technologies>
</device>
<device name="-VERT-1/4W-5%" package="AXIAL-0.1">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-10686"/>
<attribute name="VALUE" value="100k"/>
</technology>
</technologies>
</device>
<device name="-VERT_KIT-1/4W-5%" package="AXIAL-0.1-KIT">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-10686"/>
<attribute name="VALUE" value="100k"/>
</technology>
</technologies>
</device>
<device name="-HORIZ-1/4W-5%" package="AXIAL-0.3">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-10686"/>
<attribute name="VALUE" value="100k"/>
</technology>
</technologies>
</device>
<device name="-HORIZ_KIT-1/4W-5%" package="AXIAL-0.3-KIT">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-10686"/>
<attribute name="VALUE" value="100k"/>
</technology>
</technologies>
</device>
<device name="-0603-1/10W-1%" package="0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-07828"/>
<attribute name="VALUE" value="100k"/>
</technology>
</technologies>
</device>
<device name="-0402-1/16W-1%" package="0402">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-13495"/>
<attribute name="VALUE" value="100K"/>
</technology>
</technologies>
</device>
<device name="-0402T-1/16W-1%" package="0402-TIGHT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-13495" constant="no"/>
<attribute name="VALUE" value="100k" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="120OHM" prefix="R">
<description>&lt;h3&gt;120Ω resistor&lt;/h3&gt;
&lt;p&gt;A resistor is a passive two-terminal electrical component that implements electrical resistance as a circuit element. Resistors act to reduce current flow, and, at the same time, act to lower voltage levels within circuits. - Wikipedia&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="RESISTOR" x="0" y="0"/>
</gates>
<devices>
<device name="" package="0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="1.5KOHM" prefix="R">
<description>&lt;h3&gt;1.5kΩ resistor&lt;/h3&gt;
&lt;p&gt;A resistor is a passive two-terminal electrical component that implements electrical resistance as a circuit element. Resistors act to reduce current flow, and, at the same time, act to lower voltage levels within circuits. - Wikipedia&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="RESISTOR" x="0" y="0"/>
</gates>
<devices>
<device name="-0603-1/10W-1%" package="0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-08306"/>
<attribute name="VALUE" value="1.5k"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="68OHM" prefix="R">
<description>&lt;h3&gt;68Ω resistor&lt;/h3&gt;
&lt;p&gt;A resistor is a passive two-terminal electrical component that implements electrical resistance as a circuit element. Resistors act to reduce current flow, and, at the same time, act to lower voltage levels within circuits. - Wikipedia&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="RESISTOR" x="0" y="0"/>
</gates>
<devices>
<device name="-0603-1/10W-1%" package="0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="470OHM" prefix="R" uservalue="yes">
<description>&lt;h3&gt;470Ω resistor&lt;/h3&gt;
&lt;p&gt;A resistor is a passive two-terminal electrical component that implements electrical resistance as a circuit element. Resistors act to reduce current flow, and, at the same time, act to lower voltage levels within circuits. - Wikipedia&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="RESISTOR" x="0" y="0"/>
</gates>
<devices>
<device name="-0603-1/10W-1%" package="0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-07869"/>
<attribute name="VALUE" value="470"/>
</technology>
</technologies>
</device>
<device name="-0402-1/16W-5%" package="0402">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-13829" constant="no"/>
<attribute name="VALUE" value="470" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0402-TIGHT-1/16W-5%" package="0402-TIGHT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-13829" constant="no"/>
<attribute name="VALUE" value="470Ω" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0402-TIGHT-1/16W-1%" package="0402-TIGHT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-15584" constant="no"/>
<attribute name="VALUE" value="470" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="10OHM" prefix="R">
<description>&lt;h3&gt;10Ω resistor&lt;/h3&gt;
&lt;p&gt;A resistor is a passive two-terminal electrical component that implements electrical resistance as a circuit element. Resistors act to reduce current flow, and, at the same time, act to lower voltage levels within circuits. - Wikipedia&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="RESISTOR" x="0" y="0"/>
</gates>
<devices>
<device name="-1206-1/4W-1%" package="1206">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-08705"/>
<attribute name="VALUE" value="10"/>
</technology>
</technologies>
</device>
<device name="-VERT-1/4W-1%" package="AXIAL-0.1">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-12180"/>
<attribute name="VALUE" value="10"/>
</technology>
</technologies>
</device>
<device name="-VERT_KIT-1/4W-1%" package="AXIAL-0.1-KIT">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-12180"/>
<attribute name="VALUE" value="10"/>
</technology>
</technologies>
</device>
<device name="-HORIZ-1/4W-1%" package="AXIAL-0.3">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-12180"/>
<attribute name="VALUE" value="10"/>
</technology>
</technologies>
</device>
<device name="-HORIZ_KIT-1/4W-1%" package="AXIAL-0.3-KIT">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-12180"/>
<attribute name="VALUE" value="10"/>
</technology>
</technologies>
</device>
<device name="-0603-1/10W-1%" package="0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-12581"/>
<attribute name="VALUE" value="10"/>
</technology>
</technologies>
</device>
<device name="-0603-1/10W-5%" package="0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-09834"/>
<attribute name="VALUE" value="10"/>
</technology>
</technologies>
</device>
<device name="-0402-1/16W-5%" package="0402-TIGHT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-16072" constant="no"/>
<attribute name="VALUE" value="10Ω" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="100OHM" prefix="R">
<description>&lt;h3&gt;100Ω resistor&lt;/h3&gt;
&lt;p&gt;A resistor is a passive two-terminal electrical component that implements electrical resistance as a circuit element. Resistors act to reduce current flow, and, at the same time, act to lower voltage levels within circuits. - Wikipedia&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="RESISTOR" x="0" y="0"/>
</gates>
<devices>
<device name="-HORIZ-1/4W-1%" package="AXIAL-0.3">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-12181" constant="no"/>
<attribute name="VALUE" value="100" constant="no"/>
</technology>
</technologies>
</device>
<device name="-HORIZ_KIT-1/4W-1%" package="AXIAL-0.3EZ">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-12181" constant="no"/>
<attribute name="VALUE" value="100" constant="no"/>
</technology>
</technologies>
</device>
<device name="-VERT-1/4W-1%" package="AXIAL-0.1">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-12181"/>
<attribute name="VALUE" value="100"/>
</technology>
</technologies>
</device>
<device name="-VERT_KIT-1/4W-1%" package="AXIAL-0.1-KIT">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-12181" constant="no"/>
<attribute name="VALUE" value="100" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0603-1/10W-1%" package="0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-07863"/>
<attribute name="VALUE" value="100"/>
</technology>
</technologies>
</device>
<device name="-0402-TIGHT-1/16W-1%" package="0402-TIGHT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-14962" constant="no"/>
<attribute name="VALUE" value="100" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="SparkFun-Connectors">
<description>&lt;h3&gt;SparkFun Connectors&lt;/h3&gt;
This library contains electrically-functional connectors. 
&lt;br&gt;
&lt;br&gt;
We've spent an enormous amount of time creating and checking these footprints and parts, but it is &lt;b&gt; the end user's responsibility&lt;/b&gt; to ensure correctness and suitablity for a given componet or application. 
&lt;br&gt;
&lt;br&gt;If you enjoy using this library, please buy one of our products at &lt;a href=" www.sparkfun.com"&gt;SparkFun.com&lt;/a&gt;.
&lt;br&gt;
&lt;br&gt;
&lt;b&gt;Licensing:&lt;/b&gt; Creative Commons ShareAlike 4.0 International - https://creativecommons.org/licenses/by-sa/4.0/ 
&lt;br&gt;
&lt;br&gt;
You are welcome to use this library for commercial purposes. For attribution, we ask that when you begin to sell your device using our footprint, you email us with a link to the product being sold. We want bragging rights that we helped (in a very small part) to create your 8th world wonder. We would like the opportunity to feature your device on our homepage.</description>
<packages>
<package name="1X06">
<description>&lt;h3&gt;Plated Through Hole - 6 Pin&lt;/h3&gt;
&lt;p&gt;Specifications:
&lt;ul&gt;&lt;li&gt;Pin count:6&lt;/li&gt;
&lt;li&gt;Pin pitch:0.1"&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;
&lt;p&gt;Example device(s):
&lt;ul&gt;&lt;li&gt;CONN_06&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;</description>
<wire x1="11.43" y1="0.635" x2="12.065" y2="1.27" width="0.2032" layer="21"/>
<wire x1="12.065" y1="1.27" x2="13.335" y2="1.27" width="0.2032" layer="21"/>
<wire x1="13.335" y1="1.27" x2="13.97" y2="0.635" width="0.2032" layer="21"/>
<wire x1="13.97" y1="-0.635" x2="13.335" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="13.335" y1="-1.27" x2="12.065" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="12.065" y1="-1.27" x2="11.43" y2="-0.635" width="0.2032" layer="21"/>
<wire x1="6.985" y1="1.27" x2="8.255" y2="1.27" width="0.2032" layer="21"/>
<wire x1="8.255" y1="1.27" x2="8.89" y2="0.635" width="0.2032" layer="21"/>
<wire x1="8.89" y1="-0.635" x2="8.255" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="8.89" y1="0.635" x2="9.525" y2="1.27" width="0.2032" layer="21"/>
<wire x1="9.525" y1="1.27" x2="10.795" y2="1.27" width="0.2032" layer="21"/>
<wire x1="10.795" y1="1.27" x2="11.43" y2="0.635" width="0.2032" layer="21"/>
<wire x1="11.43" y1="-0.635" x2="10.795" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="10.795" y1="-1.27" x2="9.525" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="9.525" y1="-1.27" x2="8.89" y2="-0.635" width="0.2032" layer="21"/>
<wire x1="3.81" y1="0.635" x2="4.445" y2="1.27" width="0.2032" layer="21"/>
<wire x1="4.445" y1="1.27" x2="5.715" y2="1.27" width="0.2032" layer="21"/>
<wire x1="5.715" y1="1.27" x2="6.35" y2="0.635" width="0.2032" layer="21"/>
<wire x1="6.35" y1="-0.635" x2="5.715" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="5.715" y1="-1.27" x2="4.445" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="4.445" y1="-1.27" x2="3.81" y2="-0.635" width="0.2032" layer="21"/>
<wire x1="6.985" y1="1.27" x2="6.35" y2="0.635" width="0.2032" layer="21"/>
<wire x1="6.35" y1="-0.635" x2="6.985" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="8.255" y1="-1.27" x2="6.985" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="-0.635" y1="1.27" x2="0.635" y2="1.27" width="0.2032" layer="21"/>
<wire x1="0.635" y1="1.27" x2="1.27" y2="0.635" width="0.2032" layer="21"/>
<wire x1="1.27" y1="-0.635" x2="0.635" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="1.27" y1="0.635" x2="1.905" y2="1.27" width="0.2032" layer="21"/>
<wire x1="1.905" y1="1.27" x2="3.175" y2="1.27" width="0.2032" layer="21"/>
<wire x1="3.175" y1="1.27" x2="3.81" y2="0.635" width="0.2032" layer="21"/>
<wire x1="3.81" y1="-0.635" x2="3.175" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="3.175" y1="-1.27" x2="1.905" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="1.905" y1="-1.27" x2="1.27" y2="-0.635" width="0.2032" layer="21"/>
<wire x1="-1.27" y1="0.635" x2="-1.27" y2="-0.635" width="0.2032" layer="21"/>
<wire x1="-0.635" y1="1.27" x2="-1.27" y2="0.635" width="0.2032" layer="21"/>
<wire x1="-1.27" y1="-0.635" x2="-0.635" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="0.635" y1="-1.27" x2="-0.635" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="13.97" y1="0.635" x2="13.97" y2="-0.635" width="0.2032" layer="21"/>
<pad name="1" x="0" y="0" drill="1.016" diameter="1.8796" rot="R90"/>
<pad name="2" x="2.54" y="0" drill="1.016" diameter="1.8796" rot="R90"/>
<pad name="3" x="5.08" y="0" drill="1.016" diameter="1.8796" rot="R90"/>
<pad name="4" x="7.62" y="0" drill="1.016" diameter="1.8796" rot="R90"/>
<pad name="5" x="10.16" y="0" drill="1.016" diameter="1.8796" rot="R90"/>
<pad name="6" x="12.7" y="0" drill="1.016" diameter="1.8796" rot="R90"/>
<rectangle x1="12.446" y1="-0.254" x2="12.954" y2="0.254" layer="51"/>
<rectangle x1="9.906" y1="-0.254" x2="10.414" y2="0.254" layer="51"/>
<rectangle x1="7.366" y1="-0.254" x2="7.874" y2="0.254" layer="51"/>
<rectangle x1="4.826" y1="-0.254" x2="5.334" y2="0.254" layer="51"/>
<rectangle x1="2.286" y1="-0.254" x2="2.794" y2="0.254" layer="51"/>
<rectangle x1="-0.254" y1="-0.254" x2="0.254" y2="0.254" layer="51"/>
<text x="-1.27" y="1.397" size="0.6096" layer="25" font="vector" ratio="20">&gt;NAME</text>
<text x="-1.27" y="-2.032" size="0.6096" layer="27" font="vector" ratio="20">&gt;VALUE</text>
</package>
<package name="MOLEX-1X6">
<description>&lt;h3&gt;Molex 6-Pin Plated Through-Hole&lt;/h3&gt;
&lt;p&gt;Specifications:
&lt;ul&gt;&lt;li&gt;Pin count:6&lt;/li&gt;
&lt;li&gt;Pin pitch:0.1"&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;
&lt;p&gt;&lt;a href=”https://www.sparkfun.com/datasheets/Prototyping/2pin_molex_set_19iv10.pdf”&gt;Datasheet referenced for footprint&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;Example device(s):
&lt;ul&gt;&lt;li&gt;CONN_06&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;</description>
<wire x1="-1.27" y1="3.048" x2="-1.27" y2="-2.54" width="0.127" layer="21"/>
<wire x1="13.97" y1="3.048" x2="13.97" y2="-2.54" width="0.127" layer="21"/>
<wire x1="13.97" y1="3.048" x2="-1.27" y2="3.048" width="0.127" layer="21"/>
<wire x1="13.97" y1="-2.54" x2="12.7" y2="-2.54" width="0.127" layer="21"/>
<wire x1="12.7" y1="-2.54" x2="0" y2="-2.54" width="0.127" layer="21"/>
<wire x1="0" y1="-2.54" x2="-1.27" y2="-2.54" width="0.127" layer="21"/>
<wire x1="0" y1="-2.54" x2="0" y2="-1.27" width="0.127" layer="21"/>
<wire x1="0" y1="-1.27" x2="12.7" y2="-1.27" width="0.127" layer="21"/>
<wire x1="12.7" y1="-1.27" x2="12.7" y2="-2.54" width="0.127" layer="21"/>
<pad name="1" x="0" y="0" drill="1.016" diameter="1.8796"/>
<pad name="2" x="2.54" y="0" drill="1.016" diameter="1.8796"/>
<pad name="3" x="5.08" y="0" drill="1.016" diameter="1.8796"/>
<pad name="4" x="7.62" y="0" drill="1.016" diameter="1.8796"/>
<pad name="5" x="10.16" y="0" drill="1.016" diameter="1.8796"/>
<pad name="6" x="12.7" y="0" drill="1.016" diameter="1.8796"/>
<text x="4.699" y="3.302" size="0.6096" layer="25" font="vector" ratio="20">&gt;NAME</text>
<text x="4.699" y="-3.556" size="0.6096" layer="27" font="vector" ratio="20">&gt;VALUE</text>
<wire x1="-0.635" y1="1.27" x2="0.635" y2="1.27" width="0.2032" layer="21"/>
<wire x1="0.635" y1="1.27" x2="-0.635" y2="1.27" width="0.2032" layer="22"/>
</package>
<package name="MOLEX-1X6-RA">
<description>&lt;h3&gt;Molex 6-Pin Plated Through-Hole Right Angle&lt;/h3&gt;
tPlace shows angle of connector. 
&lt;p&gt;Specifications:
&lt;ul&gt;&lt;li&gt;Pin count:6&lt;/li&gt;
&lt;li&gt;Pin pitch:0.1"&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;
&lt;p&gt;&lt;a href=”https://www.sparkfun.com/datasheets/Prototyping/2pin_molex_set_19iv10.pdf”&gt;Datasheet referenced for footprint&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;Example device(s):
&lt;ul&gt;&lt;li&gt;CONN_06&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;</description>
<wire x1="-1.27" y1="0.635" x2="-1.27" y2="3.175" width="0.127" layer="21"/>
<wire x1="13.97" y1="0.635" x2="13.97" y2="3.175" width="0.127" layer="21"/>
<wire x1="13.97" y1="0.635" x2="-1.27" y2="0.635" width="0.127" layer="21"/>
<wire x1="13.97" y1="3.175" x2="12.7" y2="3.175" width="0.127" layer="21"/>
<wire x1="12.7" y1="3.175" x2="0" y2="3.175" width="0.127" layer="21"/>
<wire x1="0" y1="3.175" x2="-1.27" y2="3.175" width="0.127" layer="21"/>
<wire x1="0" y1="3.175" x2="0" y2="7.62" width="0.127" layer="21"/>
<wire x1="0" y1="7.62" x2="12.7" y2="7.62" width="0.127" layer="21"/>
<wire x1="12.7" y1="7.62" x2="12.7" y2="3.175" width="0.127" layer="21"/>
<pad name="1" x="0" y="0" drill="1.016" diameter="1.8796"/>
<pad name="2" x="2.54" y="0" drill="1.016" diameter="1.8796"/>
<pad name="3" x="5.08" y="0" drill="1.016" diameter="1.8796"/>
<pad name="4" x="7.62" y="0" drill="1.016" diameter="1.8796"/>
<pad name="5" x="10.16" y="0" drill="1.016" diameter="1.8796"/>
<pad name="6" x="12.7" y="0" drill="1.016" diameter="1.8796"/>
<text x="4.953" y="5.334" size="0.6096" layer="25" font="vector" ratio="20">&gt;NAME</text>
<text x="4.699" y="4.445" size="0.6096" layer="27" font="vector" ratio="20">&gt;VALUE</text>
<wire x1="-0.635" y1="-1.27" x2="0.635" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="0.635" y1="-1.27" x2="-0.635" y2="-1.27" width="0.2032" layer="22"/>
</package>
<package name="1X06-SMD_RA_MALE">
<description>&lt;h3&gt;SMD - 6 Pin Right Angle Male Header&lt;/h3&gt;
tDocu layer shows pin locations.
&lt;p&gt;Specifications:
&lt;ul&gt;&lt;li&gt;Pin count:6&lt;/li&gt;
&lt;li&gt;Pin pitch:0.1"&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;
&lt;p&gt;Example device(s):
&lt;ul&gt;&lt;li&gt;CONN_06&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;</description>
<wire x1="7.62" y1="1.25" x2="-7.62" y2="1.25" width="0.127" layer="51"/>
<wire x1="-7.62" y1="1.25" x2="-7.62" y2="-1.25" width="0.127" layer="51"/>
<wire x1="-7.62" y1="-1.25" x2="-6.35" y2="-1.25" width="0.127" layer="51"/>
<wire x1="-6.35" y1="-1.25" x2="-3.81" y2="-1.25" width="0.127" layer="51"/>
<wire x1="-3.81" y1="-1.25" x2="-1.27" y2="-1.25" width="0.127" layer="51"/>
<wire x1="-1.27" y1="-1.25" x2="1.27" y2="-1.25" width="0.127" layer="51"/>
<wire x1="1.27" y1="-1.25" x2="3.81" y2="-1.25" width="0.127" layer="51"/>
<wire x1="3.81" y1="-1.25" x2="6.35" y2="-1.25" width="0.127" layer="51"/>
<wire x1="6.35" y1="-1.25" x2="7.62" y2="-1.25" width="0.127" layer="51"/>
<wire x1="7.62" y1="-1.25" x2="7.62" y2="1.25" width="0.127" layer="51"/>
<wire x1="6.35" y1="-1.25" x2="6.35" y2="-7.25" width="0.127" layer="51"/>
<wire x1="3.81" y1="-1.25" x2="3.81" y2="-7.25" width="0.127" layer="51"/>
<wire x1="1.27" y1="-1.25" x2="1.27" y2="-7.25" width="0.127" layer="51"/>
<wire x1="-1.27" y1="-1.25" x2="-1.27" y2="-7.25" width="0.127" layer="51"/>
<wire x1="-3.81" y1="-1.25" x2="-3.81" y2="-7.25" width="0.127" layer="51"/>
<wire x1="-6.35" y1="-1.25" x2="-6.35" y2="-7.25" width="0.127" layer="51"/>
<smd name="4" x="1.27" y="5" dx="3" dy="1" layer="1" rot="R90"/>
<smd name="5" x="3.81" y="5" dx="3" dy="1" layer="1" rot="R90"/>
<smd name="6" x="6.35" y="5" dx="3" dy="1" layer="1" rot="R90"/>
<smd name="3" x="-1.27" y="5" dx="3" dy="1" layer="1" rot="R90"/>
<smd name="2" x="-3.81" y="5" dx="3" dy="1" layer="1" rot="R90"/>
<smd name="1" x="-6.35" y="5" dx="3" dy="1" layer="1" rot="R90"/>
<hole x="-5.08" y="0" drill="1.4"/>
<hole x="5.08" y="0" drill="1.4"/>
<text x="-1.524" y="0.381" size="0.6096" layer="25" font="vector" ratio="20">&gt;NAME</text>
<text x="-1.651" y="-1.016" size="0.6096" layer="27" font="vector" ratio="20">&gt;VALUE</text>
</package>
<package name="1X06_LOCK">
<description>&lt;h3&gt;Plated Through Hole - 6 Pin with Locking Footprint&lt;/h3&gt;
Holes are offset 0.005" from center, locking pins in place during soldering.
&lt;p&gt;Specifications:
&lt;ul&gt;&lt;li&gt;Pin count:6&lt;/li&gt;
&lt;li&gt;Pin pitch:0.1"&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;
&lt;p&gt;Example device(s):
&lt;ul&gt;&lt;li&gt;CONN_06&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;</description>
<wire x1="-1.27" y1="0.508" x2="-0.635" y2="1.143" width="0.2032" layer="21"/>
<wire x1="-0.635" y1="1.143" x2="0.635" y2="1.143" width="0.2032" layer="21"/>
<wire x1="0.635" y1="1.143" x2="1.27" y2="0.508" width="0.2032" layer="21"/>
<wire x1="1.27" y1="0.508" x2="1.905" y2="1.143" width="0.2032" layer="21"/>
<wire x1="1.905" y1="1.143" x2="3.175" y2="1.143" width="0.2032" layer="21"/>
<wire x1="3.175" y1="1.143" x2="3.81" y2="0.508" width="0.2032" layer="21"/>
<wire x1="3.81" y1="0.508" x2="4.445" y2="1.143" width="0.2032" layer="21"/>
<wire x1="4.445" y1="1.143" x2="5.715" y2="1.143" width="0.2032" layer="21"/>
<wire x1="5.715" y1="1.143" x2="6.35" y2="0.508" width="0.2032" layer="21"/>
<wire x1="6.35" y1="0.508" x2="6.985" y2="1.143" width="0.2032" layer="21"/>
<wire x1="6.985" y1="1.143" x2="8.255" y2="1.143" width="0.2032" layer="21"/>
<wire x1="8.255" y1="1.143" x2="8.89" y2="0.508" width="0.2032" layer="21"/>
<wire x1="8.89" y1="0.508" x2="9.525" y2="1.143" width="0.2032" layer="21"/>
<wire x1="9.525" y1="1.143" x2="10.795" y2="1.143" width="0.2032" layer="21"/>
<wire x1="10.795" y1="1.143" x2="11.43" y2="0.508" width="0.2032" layer="21"/>
<wire x1="11.43" y1="0.508" x2="12.065" y2="1.143" width="0.2032" layer="21"/>
<wire x1="12.065" y1="1.143" x2="13.335" y2="1.143" width="0.2032" layer="21"/>
<wire x1="13.335" y1="1.143" x2="13.97" y2="0.508" width="0.2032" layer="21"/>
<wire x1="13.97" y1="0.508" x2="13.97" y2="-0.762" width="0.2032" layer="21"/>
<wire x1="13.97" y1="-0.762" x2="13.335" y2="-1.397" width="0.2032" layer="21"/>
<wire x1="13.335" y1="-1.397" x2="12.065" y2="-1.397" width="0.2032" layer="21"/>
<wire x1="12.065" y1="-1.397" x2="11.43" y2="-0.762" width="0.2032" layer="21"/>
<wire x1="11.43" y1="-0.762" x2="10.795" y2="-1.397" width="0.2032" layer="21"/>
<wire x1="10.795" y1="-1.397" x2="9.525" y2="-1.397" width="0.2032" layer="21"/>
<wire x1="9.525" y1="-1.397" x2="8.89" y2="-0.762" width="0.2032" layer="21"/>
<wire x1="8.89" y1="-0.762" x2="8.255" y2="-1.397" width="0.2032" layer="21"/>
<wire x1="8.255" y1="-1.397" x2="6.985" y2="-1.397" width="0.2032" layer="21"/>
<wire x1="6.985" y1="-1.397" x2="6.35" y2="-0.762" width="0.2032" layer="21"/>
<wire x1="6.35" y1="-0.762" x2="5.715" y2="-1.397" width="0.2032" layer="21"/>
<wire x1="5.715" y1="-1.397" x2="4.445" y2="-1.397" width="0.2032" layer="21"/>
<wire x1="4.445" y1="-1.397" x2="3.81" y2="-0.762" width="0.2032" layer="21"/>
<wire x1="3.81" y1="-0.762" x2="3.175" y2="-1.397" width="0.2032" layer="21"/>
<wire x1="3.175" y1="-1.397" x2="1.905" y2="-1.397" width="0.2032" layer="21"/>
<wire x1="1.905" y1="-1.397" x2="1.27" y2="-0.762" width="0.2032" layer="21"/>
<wire x1="1.27" y1="-0.762" x2="0.635" y2="-1.397" width="0.2032" layer="21"/>
<wire x1="0.635" y1="-1.397" x2="-0.635" y2="-1.397" width="0.2032" layer="21"/>
<wire x1="-0.635" y1="-1.397" x2="-1.27" y2="-0.762" width="0.2032" layer="21"/>
<wire x1="-1.27" y1="-0.762" x2="-1.27" y2="0.508" width="0.2032" layer="21"/>
<pad name="1" x="0" y="0" drill="1.016" diameter="1.8796"/>
<pad name="2" x="2.54" y="-0.254" drill="1.016" diameter="1.8796"/>
<pad name="3" x="5.08" y="0" drill="1.016" diameter="1.8796"/>
<pad name="4" x="7.62" y="-0.254" drill="1.016" diameter="1.8796"/>
<pad name="5" x="10.16" y="0" drill="1.016" diameter="1.8796"/>
<pad name="6" x="12.7" y="-0.254" drill="1.016" diameter="1.8796"/>
<rectangle x1="-0.2921" y1="-0.4191" x2="0.2921" y2="0.1651" layer="51"/>
<rectangle x1="2.2479" y1="-0.4191" x2="2.8321" y2="0.1651" layer="51"/>
<rectangle x1="4.7879" y1="-0.4191" x2="5.3721" y2="0.1651" layer="51"/>
<rectangle x1="7.3279" y1="-0.4191" x2="7.9121" y2="0.1651" layer="51"/>
<rectangle x1="9.8679" y1="-0.4191" x2="10.4521" y2="0.1651" layer="51"/>
<rectangle x1="12.4079" y1="-0.4191" x2="12.9921" y2="0.1651" layer="51"/>
<text x="-1.27" y="1.397" size="0.6096" layer="25" font="vector" ratio="20">&gt;NAME</text>
<text x="-1.27" y="-2.286" size="0.6096" layer="27" font="vector" ratio="20">&gt;VALUE</text>
</package>
<package name="1X06_LOCK_LONGPADS">
<description>&lt;h3&gt;Plated Through Hole - 6 Pin with Locking Footprint with Long Pads&lt;/h3&gt;
Holes are offset 0.005" from center, locking pins in place during soldering.
&lt;p&gt;Specifications:
&lt;ul&gt;&lt;li&gt;Pin count:6&lt;/li&gt;
&lt;li&gt;Pin pitch:0.1"&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;
&lt;p&gt;Example device(s):
&lt;ul&gt;&lt;li&gt;CONN_06&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;</description>
<wire x1="1.524" y1="-0.127" x2="1.016" y2="-0.127" width="0.2032" layer="21"/>
<wire x1="4.064" y1="-0.127" x2="3.556" y2="-0.127" width="0.2032" layer="21"/>
<wire x1="6.604" y1="-0.127" x2="6.096" y2="-0.127" width="0.2032" layer="21"/>
<wire x1="9.144" y1="-0.127" x2="8.636" y2="-0.127" width="0.2032" layer="21"/>
<wire x1="11.684" y1="-0.127" x2="11.176" y2="-0.127" width="0.2032" layer="21"/>
<wire x1="-1.27" y1="-0.127" x2="-1.016" y2="-0.127" width="0.2032" layer="21"/>
<wire x1="-1.27" y1="-0.127" x2="-1.27" y2="0.8636" width="0.2032" layer="21"/>
<wire x1="-1.27" y1="0.8636" x2="-0.9906" y2="1.143" width="0.2032" layer="21"/>
<wire x1="-1.27" y1="-0.127" x2="-1.27" y2="-1.1176" width="0.2032" layer="21"/>
<wire x1="-1.27" y1="-1.1176" x2="-0.9906" y2="-1.397" width="0.2032" layer="21"/>
<wire x1="13.97" y1="-0.127" x2="13.716" y2="-0.127" width="0.2032" layer="21"/>
<wire x1="13.97" y1="-0.127" x2="13.97" y2="-1.1176" width="0.2032" layer="21"/>
<wire x1="13.97" y1="-1.1176" x2="13.6906" y2="-1.397" width="0.2032" layer="21"/>
<wire x1="13.97" y1="-0.127" x2="13.97" y2="0.8636" width="0.2032" layer="21"/>
<wire x1="13.97" y1="0.8636" x2="13.6906" y2="1.143" width="0.2032" layer="21"/>
<pad name="1" x="0" y="0" drill="1.016" shape="long" rot="R90"/>
<pad name="2" x="2.54" y="-0.254" drill="1.016" shape="long" rot="R90"/>
<pad name="3" x="5.08" y="0" drill="1.016" shape="long" rot="R90"/>
<pad name="4" x="7.62" y="-0.254" drill="1.016" shape="long" rot="R90"/>
<pad name="5" x="10.16" y="0" drill="1.016" shape="long" rot="R90"/>
<pad name="6" x="12.7" y="-0.254" drill="1.016" shape="long" rot="R90"/>
<rectangle x1="-0.2921" y1="-0.4191" x2="0.2921" y2="0.1651" layer="51"/>
<rectangle x1="2.2479" y1="-0.4191" x2="2.8321" y2="0.1651" layer="51"/>
<rectangle x1="4.7879" y1="-0.4191" x2="5.3721" y2="0.1651" layer="51"/>
<rectangle x1="7.3279" y1="-0.4191" x2="7.9121" y2="0.1651" layer="51" rot="R90"/>
<rectangle x1="9.8679" y1="-0.4191" x2="10.4521" y2="0.1651" layer="51"/>
<rectangle x1="12.4079" y1="-0.4191" x2="12.9921" y2="0.1651" layer="51"/>
<text x="-1.143" y="2.032" size="0.6096" layer="25" font="vector" ratio="20">&gt;NAME</text>
<text x="-1.143" y="-2.667" size="0.6096" layer="27" font="vector" ratio="20">&gt;VALUE</text>
</package>
<package name="MOLEX-1X6_LOCK">
<description>&lt;h3&gt;Molex 6-Pin Plated Through-Hole Locking Footprint&lt;/h3&gt;
Holes are offset 0.005" from center to hold pins in place during soldering.  
&lt;p&gt;Specifications:
&lt;ul&gt;&lt;li&gt;Pin count:6&lt;/li&gt;
&lt;li&gt;Pin pitch:0.1"&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;
&lt;p&gt;&lt;a href=”https://www.sparkfun.com/datasheets/Prototyping/2pin_molex_set_19iv10.pdf”&gt;Datasheet referenced for footprint&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;Example device(s):
&lt;ul&gt;&lt;li&gt;CONN_06&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;</description>
<wire x1="-1.27" y1="3.048" x2="-1.27" y2="-2.54" width="0.127" layer="21"/>
<wire x1="13.97" y1="3.048" x2="13.97" y2="-2.54" width="0.127" layer="21"/>
<wire x1="13.97" y1="3.048" x2="-1.27" y2="3.048" width="0.127" layer="21"/>
<wire x1="13.97" y1="-2.54" x2="12.7" y2="-2.54" width="0.127" layer="21"/>
<wire x1="12.7" y1="-2.54" x2="0" y2="-2.54" width="0.127" layer="21"/>
<wire x1="0" y1="-2.54" x2="-1.27" y2="-2.54" width="0.127" layer="21"/>
<wire x1="0" y1="-2.54" x2="0" y2="-1.27" width="0.127" layer="21"/>
<wire x1="0" y1="-1.27" x2="12.7" y2="-1.27" width="0.127" layer="21"/>
<wire x1="12.7" y1="-1.27" x2="12.7" y2="-2.54" width="0.127" layer="21"/>
<pad name="1" x="0" y="0" drill="1.016" diameter="1.8796"/>
<pad name="2" x="2.54" y="-0.254" drill="1.016" diameter="1.8796"/>
<pad name="3" x="5.08" y="0" drill="1.016" diameter="1.8796"/>
<pad name="4" x="7.62" y="-0.254" drill="1.016" diameter="1.8796"/>
<pad name="5" x="10.16" y="0" drill="1.016" diameter="1.8796"/>
<pad name="6" x="12.7" y="-0.254" drill="1.016" diameter="1.8796"/>
<rectangle x1="-0.2921" y1="-0.4191" x2="0.2921" y2="0.1651" layer="51"/>
<rectangle x1="2.2479" y1="-0.4191" x2="2.8321" y2="0.1651" layer="51"/>
<rectangle x1="4.7879" y1="-0.4191" x2="5.3721" y2="0.1651" layer="51"/>
<rectangle x1="7.3279" y1="-0.4191" x2="7.9121" y2="0.1651" layer="51"/>
<rectangle x1="9.8679" y1="-0.4191" x2="10.4521" y2="0.1651" layer="51"/>
<rectangle x1="12.4079" y1="-0.4191" x2="12.9921" y2="0.1651" layer="51"/>
<text x="4.445" y="3.302" size="0.6096" layer="25" font="vector" ratio="20">&gt;NAME</text>
<text x="4.191" y="-3.429" size="0.6096" layer="27" font="vector" ratio="20">&gt;VALUE</text>
<wire x1="-0.635" y1="1.27" x2="0.635" y2="1.27" width="0.2032" layer="21"/>
<wire x1="0.635" y1="1.27" x2="-0.635" y2="1.27" width="0.2032" layer="22"/>
</package>
<package name="MOLEX_1X6_RA_LOCK">
<description>&lt;h3&gt;Molex 6-Pin Plated Through-Hole Right Angle Locking Footprint&lt;/h3&gt;
Holes are offset 0.005" from center to hold pins in place during soldering.  
tPlace shows location of connector.
&lt;p&gt;Specifications:
&lt;ul&gt;&lt;li&gt;Pin count:6&lt;/li&gt;
&lt;li&gt;Pin pitch:0.1"&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;
&lt;p&gt;&lt;a href=”https://www.sparkfun.com/datasheets/Prototyping/2pin_molex_set_19iv10.pdf”&gt;Datasheet referenced for footprint&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;Example device(s):
&lt;ul&gt;&lt;li&gt;CONN_06&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;</description>
<wire x1="-1.27" y1="0.635" x2="-1.27" y2="3.175" width="0.127" layer="21"/>
<wire x1="13.97" y1="0.635" x2="13.97" y2="3.175" width="0.127" layer="21"/>
<wire x1="13.97" y1="0.635" x2="-1.27" y2="0.635" width="0.127" layer="21"/>
<wire x1="13.97" y1="3.175" x2="12.7" y2="3.175" width="0.127" layer="21"/>
<wire x1="12.7" y1="3.175" x2="0" y2="3.175" width="0.127" layer="21"/>
<wire x1="0" y1="3.175" x2="-1.27" y2="3.175" width="0.127" layer="21"/>
<wire x1="0" y1="3.175" x2="0" y2="7.62" width="0.127" layer="21"/>
<wire x1="0" y1="7.62" x2="12.7" y2="7.62" width="0.127" layer="21"/>
<wire x1="12.7" y1="7.62" x2="12.7" y2="3.175" width="0.127" layer="21"/>
<pad name="1" x="0" y="0.127" drill="1.016" diameter="1.8796"/>
<pad name="2" x="2.54" y="-0.127" drill="1.016" diameter="1.8796"/>
<pad name="3" x="5.08" y="0.127" drill="1.016" diameter="1.8796"/>
<pad name="4" x="7.62" y="-0.127" drill="1.016" diameter="1.8796"/>
<pad name="5" x="10.16" y="0.127" drill="1.016" diameter="1.8796"/>
<pad name="6" x="12.7" y="-0.127" drill="1.016" diameter="1.8796"/>
<text x="4.826" y="5.588" size="0.6096" layer="25" font="vector" ratio="20">&gt;NAME</text>
<text x="4.699" y="4.318" size="0.6096" layer="27" font="vector" ratio="20">&gt;VALUE</text>
<wire x1="0.635" y1="-1.27" x2="-0.635" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="-0.635" y1="-1.27" x2="0.635" y2="-1.27" width="0.2032" layer="22"/>
</package>
<package name="1X06_FEMALE_LOCK.010">
<description>&lt;h3&gt;Plated Through Hole - 6 Pin Locking Header&lt;/h3&gt;
Includes silk outline for 6 pin female header
&lt;p&gt;Specifications:
&lt;ul&gt;&lt;li&gt;Pin count:6&lt;/li&gt;
&lt;li&gt;Pin pitch:0.1"&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;
&lt;p&gt;&lt;a href=”https://cdn.sparkfun.com/datasheets/Prototyping/SP-140520-XX-001.pdf”&gt;Datasheet referenced for footprint:&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;Example device(s):
&lt;ul&gt;&lt;li&gt;CONN_06&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;</description>
<wire x1="-1.27" y1="1.27" x2="-1.27" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="-1.27" y1="1.27" x2="13.97" y2="1.27" width="0.2032" layer="21"/>
<wire x1="13.97" y1="-1.27" x2="-1.27" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="13.97" y1="1.27" x2="13.97" y2="-1.27" width="0.2032" layer="21"/>
<pad name="1" x="0" y="0.254" drill="1.016" diameter="1.8796" rot="R90"/>
<pad name="2" x="2.54" y="-0.254" drill="1.016" diameter="1.8796" rot="R90"/>
<pad name="3" x="5.08" y="0.254" drill="1.016" diameter="1.8796" rot="R90"/>
<pad name="4" x="7.62" y="-0.254" drill="1.016" diameter="1.8796" rot="R90"/>
<pad name="5" x="10.16" y="0.254" drill="1.016" diameter="1.8796" rot="R90"/>
<pad name="6" x="12.7" y="-0.254" drill="1.016" diameter="1.8796" rot="R90"/>
<rectangle x1="-0.3175" y1="-0.1905" x2="0.3175" y2="0.1905" layer="51"/>
<rectangle x1="2.2225" y1="-0.1905" x2="2.8575" y2="0.1905" layer="51"/>
<rectangle x1="4.7625" y1="-0.1905" x2="5.3975" y2="0.1905" layer="51"/>
<rectangle x1="7.3025" y1="-0.1905" x2="7.9375" y2="0.1905" layer="51"/>
<rectangle x1="9.8425" y1="-0.1905" x2="10.4775" y2="0.1905" layer="51"/>
<rectangle x1="12.3825" y1="-0.1905" x2="13.0175" y2="0.1905" layer="51"/>
<text x="-1.143" y="1.524" size="0.6096" layer="25" font="vector" ratio="20">&gt;NAME</text>
<text x="-1.143" y="-2.159" size="0.6096" layer="27" font="vector" ratio="20">&gt;VALUE</text>
</package>
<package name="1X06_LONGPADS">
<description>&lt;h3&gt;Plated Through Hole - 6 Pin with Long Pads&lt;/h3&gt;
&lt;p&gt;Specifications:
&lt;ul&gt;&lt;li&gt;Pin count:6&lt;/li&gt;
&lt;li&gt;Pin pitch:0.1"&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;
&lt;p&gt;Example device(s):
&lt;ul&gt;&lt;li&gt;CONN_06&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;</description>
<wire x1="-1.27" y1="0.635" x2="-1.27" y2="-0.635" width="0.2032" layer="21"/>
<wire x1="13.97" y1="0.635" x2="13.97" y2="-0.635" width="0.2032" layer="21"/>
<pad name="1" x="0" y="0" drill="1.1176" diameter="1.8796" shape="long" rot="R90"/>
<pad name="2" x="2.54" y="0" drill="1.1176" diameter="1.8796" shape="long" rot="R90"/>
<pad name="3" x="5.08" y="0" drill="1.1176" diameter="1.8796" shape="long" rot="R90"/>
<pad name="4" x="7.62" y="0" drill="1.1176" diameter="1.8796" shape="long" rot="R90"/>
<pad name="5" x="10.16" y="0" drill="1.1176" diameter="1.8796" shape="long" rot="R90"/>
<pad name="6" x="12.7" y="0" drill="1.1176" diameter="1.8796" shape="long" rot="R90"/>
<text x="-1.27" y="2.032" size="0.6096" layer="25" font="vector" ratio="20">&gt;NAME</text>
<text x="-1.27" y="-2.667" size="0.6096" layer="27" font="vector" ratio="20">&gt;VALUE</text>
<rectangle x1="12.446" y1="-0.254" x2="12.954" y2="0.254" layer="51"/>
<rectangle x1="9.906" y1="-0.254" x2="10.414" y2="0.254" layer="51"/>
<rectangle x1="7.366" y1="-0.254" x2="7.874" y2="0.254" layer="51"/>
<rectangle x1="4.826" y1="-0.254" x2="5.334" y2="0.254" layer="51"/>
<rectangle x1="2.286" y1="-0.254" x2="2.794" y2="0.254" layer="51"/>
<rectangle x1="-0.254" y1="-0.254" x2="0.254" y2="0.254" layer="51"/>
</package>
<package name="SCREWTERMINAL-3.5MM-6">
<description>&lt;h3&gt;Screw Terminal  3.5mm Pitch -6 Pin PTH&lt;/h3&gt;
&lt;p&gt;Specifications:
&lt;ul&gt;&lt;li&gt;Pin count: 6&lt;/li&gt;
&lt;li&gt;Pin pitch: 3.5mm/138mil&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;
&lt;p&gt;&lt;a href=”https://www.sparkfun.com/datasheets/Prototyping/Screw-Terminal-3.5mm.pdf”&gt;Datasheet referenced for footprint&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;Example device(s):
&lt;ul&gt;&lt;li&gt;CONN_06&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;</description>
<wire x1="-1.75" y1="3.4" x2="19.25" y2="3.4" width="0.2032" layer="21"/>
<wire x1="19.25" y1="3.4" x2="19.25" y2="-2.8" width="0.2032" layer="21"/>
<wire x1="19.25" y1="-2.8" x2="19.25" y2="-3.6" width="0.2032" layer="21"/>
<wire x1="19.25" y1="-3.6" x2="-1.75" y2="-3.6" width="0.2032" layer="21"/>
<wire x1="-1.75" y1="-3.6" x2="-1.75" y2="-2.8" width="0.2032" layer="21"/>
<wire x1="-1.75" y1="-2.8" x2="-1.75" y2="3.4" width="0.2032" layer="21"/>
<wire x1="19.25" y1="-2.8" x2="-1.75" y2="-2.8" width="0.2032" layer="21"/>
<wire x1="-1.75" y1="-1.35" x2="-2.25" y2="-1.35" width="0.2032" layer="51"/>
<wire x1="-2.25" y1="-1.35" x2="-2.25" y2="-2.35" width="0.2032" layer="51"/>
<wire x1="-2.25" y1="-2.35" x2="-1.75" y2="-2.35" width="0.2032" layer="51"/>
<wire x1="19.25" y1="3.15" x2="19.75" y2="3.15" width="0.2032" layer="51"/>
<wire x1="19.75" y1="3.15" x2="19.75" y2="2.15" width="0.2032" layer="51"/>
<wire x1="19.75" y1="2.15" x2="19.25" y2="2.15" width="0.2032" layer="51"/>
<pad name="1" x="0" y="0" drill="1.2" diameter="2.032" shape="square"/>
<pad name="2" x="3.5" y="0" drill="1.2" diameter="2.032"/>
<pad name="3" x="7" y="0" drill="1.2" diameter="2.032"/>
<pad name="4" x="10.5" y="0" drill="1.2" diameter="2.032"/>
<pad name="5" x="14" y="0" drill="1.2" diameter="2.032"/>
<pad name="6" x="17.5" y="0" drill="1.2" diameter="2.032"/>
<text x="7.112" y="2.413" size="0.6096" layer="25" font="vector" ratio="20">&gt;NAME</text>
<text x="6.858" y="1.524" size="0.6096" layer="27" font="vector" ratio="20">&gt;VALUE</text>
</package>
<package name="1X06-SMD-FEMALE">
<description>&lt;h3&gt;Header - 6 pin Female SMD&lt;/h3&gt;
Right angle 0.1"
&lt;p&gt;Specifications:
&lt;ul&gt;&lt;li&gt;Pin count:6&lt;/li&gt;
&lt;li&gt;Pin pitch:0.1"&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;
&lt;p&gt;&lt;a href=”http://cdn.sparkfun.com/datasheets/Prototyping/19686.pdf”&gt;Datasheet referenced for footprint:&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;Example device(s):
&lt;ul&gt;&lt;li&gt;CONN_06&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;</description>
<wire x1="-7.5" y1="0.45" x2="-7.5" y2="-8.05" width="0.127" layer="21"/>
<wire x1="7.5" y1="0.45" x2="-7.5" y2="0.45" width="0.127" layer="21"/>
<wire x1="7.5" y1="-8.05" x2="7.5" y2="0.45" width="0.127" layer="21"/>
<wire x1="-7.5" y1="-8.05" x2="7.5" y2="-8.05" width="0.127" layer="21"/>
<smd name="4" x="-1.27" y="3.425" dx="1.25" dy="3" layer="1" rot="R180"/>
<smd name="5" x="-3.81" y="3.425" dx="1.25" dy="3" layer="1" rot="R180"/>
<smd name="6" x="-6.35" y="3.425" dx="1.25" dy="3" layer="1" rot="R180"/>
<smd name="3" x="1.27" y="3.425" dx="1.25" dy="3" layer="1" rot="R180"/>
<smd name="2" x="3.81" y="3.425" dx="1.25" dy="3" layer="1" rot="R180"/>
<smd name="1" x="6.35" y="3.425" dx="1.25" dy="3" layer="1" rot="R180"/>
<text x="-1.524" y="-3.302" size="0.6096" layer="25" font="vector" ratio="20">&gt;NAME</text>
<text x="-1.778" y="-4.826" size="0.6096" layer="27" font="vector" ratio="20">&gt;VALUE</text>
</package>
<package name="1X06_HOLES_ONLY">
<description>&lt;h3&gt; 6 Pin Holes&lt;/h3&gt;
No silk, no plating
&lt;p&gt;Specifications:
&lt;ul&gt;&lt;li&gt;Pin count:6&lt;/li&gt;
&lt;li&gt;Pin pitch:0.1"&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;
&lt;p&gt;Example device(s):
&lt;ul&gt;&lt;li&gt;CONN_06&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;</description>
<circle x="0" y="0" radius="0.635" width="0.127" layer="51"/>
<circle x="2.54" y="0" radius="0.635" width="0.127" layer="51"/>
<circle x="5.08" y="0" radius="0.635" width="0.127" layer="51"/>
<circle x="7.62" y="0" radius="0.635" width="0.127" layer="51"/>
<circle x="10.16" y="0" radius="0.635" width="0.127" layer="51"/>
<circle x="12.7" y="0" radius="0.635" width="0.127" layer="51"/>
<pad name="1" x="0" y="0" drill="0.889" diameter="0.8128" rot="R90"/>
<pad name="2" x="2.54" y="0" drill="0.889" diameter="0.8128" rot="R90"/>
<pad name="3" x="5.08" y="0" drill="0.889" diameter="0.8128" rot="R90"/>
<pad name="4" x="7.62" y="0" drill="0.889" diameter="0.8128" rot="R90"/>
<pad name="5" x="10.16" y="0" drill="0.889" diameter="0.8128" rot="R90"/>
<pad name="6" x="12.7" y="0" drill="0.889" diameter="0.8128" rot="R90"/>
<hole x="0" y="0" drill="1.4732"/>
<hole x="2.54" y="0" drill="1.4732"/>
<hole x="5.08" y="0" drill="1.4732"/>
<hole x="7.62" y="0" drill="1.4732"/>
<hole x="10.16" y="0" drill="1.4732"/>
<hole x="12.7" y="0" drill="1.4732"/>
</package>
<package name="1X06_SMD_STRAIGHT">
<description>&lt;h3&gt; 6 Pin SMD Female Header&lt;/h3&gt;
&lt;p&gt;Specifications:
&lt;ul&gt;&lt;li&gt;Pin count:6&lt;/li&gt;
&lt;li&gt;Pin pitch:0.1"&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;
&lt;p&gt;&lt;a href=”http://cdn.sparkfun.com/datasheets/Prototyping/femaleSMDheader.pdf”&gt;Datasheet referenced for footprint:&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;Example device(s):
&lt;ul&gt;&lt;li&gt;CONN_06&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;</description>
<wire x1="1.37" y1="1.25" x2="-14.07" y2="1.25" width="0.127" layer="51"/>
<wire x1="-14.07" y1="1.25" x2="-14.07" y2="-1.25" width="0.127" layer="51"/>
<wire x1="-14.07" y1="-1.25" x2="1.37" y2="-1.25" width="0.127" layer="51"/>
<wire x1="1.37" y1="-1.25" x2="1.37" y2="1.25" width="0.127" layer="51"/>
<wire x1="1.37" y1="1.25" x2="1.37" y2="-1.25" width="0.127" layer="21"/>
<wire x1="-14.07" y1="-1.25" x2="-14.07" y2="1.25" width="0.127" layer="21"/>
<wire x1="0.85" y1="1.25" x2="1.37" y2="1.25" width="0.127" layer="21"/>
<wire x1="-14.07" y1="1.25" x2="-10.883" y2="1.25" width="0.127" layer="21"/>
<wire x1="-13.55" y1="-1.25" x2="-14.07" y2="-1.25" width="0.127" layer="21"/>
<wire x1="1.37" y1="-1.25" x2="-1.817" y2="-1.25" width="0.127" layer="21"/>
<wire x1="-4.377" y1="1.25" x2="-0.703" y2="1.25" width="0.127" layer="21"/>
<wire x1="-9.457" y1="1.25" x2="-5.783" y2="1.25" width="0.127" layer="21"/>
<wire x1="-3.329" y1="-1.25" x2="-6.831" y2="-1.25" width="0.127" layer="21"/>
<wire x1="-8.409" y1="-1.25" x2="-11.911" y2="-1.25" width="0.127" layer="21"/>
<smd name="5" x="-10.16" y="1.65" dx="2" dy="1" layer="1" rot="R90"/>
<smd name="3" x="-5.08" y="1.65" dx="2" dy="1" layer="1" rot="R90"/>
<smd name="1" x="0" y="1.65" dx="2" dy="1" layer="1" rot="R90"/>
<smd name="6" x="-12.7" y="-1.65" dx="2" dy="1" layer="1" rot="R90"/>
<smd name="4" x="-7.62" y="-1.65" dx="2" dy="1" layer="1" rot="R90"/>
<smd name="2" x="-2.54" y="-1.65" dx="2" dy="1" layer="1" rot="R90"/>
<text x="-13.716" y="2.921" size="0.6096" layer="25" font="vector" ratio="20">&gt;NAME</text>
<text x="-13.843" y="-3.429" size="0.6096" layer="27" font="vector" ratio="20">&gt;VALUE</text>
</package>
<package name="1X06_SMD_STRAIGHT_ALT">
<description>&lt;h3&gt; 6 Pin SMD Female Header&lt;/h3&gt;
Alternate pin configuration
&lt;p&gt;Specifications:
&lt;ul&gt;&lt;li&gt;Pin count:6&lt;/li&gt;
&lt;li&gt;Pin pitch:0.1"&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;
&lt;p&gt;&lt;a href=”http://cdn.sparkfun.com/datasheets/Prototyping/femaleSMDheader.pdf”&gt;Datasheet referenced for footprint:&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;Example device(s):
&lt;ul&gt;&lt;li&gt;CONN_06&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;</description>
<wire x1="1.37" y1="1.25" x2="-14.07" y2="1.25" width="0.127" layer="51"/>
<wire x1="-14.07" y1="1.25" x2="-14.07" y2="-1.25" width="0.127" layer="51"/>
<wire x1="-14.07" y1="-1.25" x2="1.37" y2="-1.25" width="0.127" layer="51"/>
<wire x1="1.37" y1="-1.25" x2="1.37" y2="1.25" width="0.127" layer="51"/>
<wire x1="-14.07" y1="1.25" x2="-14.07" y2="-1.25" width="0.127" layer="21"/>
<wire x1="1.37" y1="-1.25" x2="1.37" y2="1.25" width="0.127" layer="21"/>
<wire x1="-13.55" y1="1.25" x2="-14.07" y2="1.25" width="0.127" layer="21"/>
<wire x1="1.37" y1="1.25" x2="-1.817" y2="1.25" width="0.127" layer="21"/>
<wire x1="0.85" y1="-1.25" x2="1.37" y2="-1.25" width="0.127" layer="21"/>
<wire x1="-14.07" y1="-1.25" x2="-10.883" y2="-1.25" width="0.127" layer="21"/>
<wire x1="-8.323" y1="1.25" x2="-11.997" y2="1.25" width="0.127" layer="21"/>
<wire x1="-3.243" y1="1.25" x2="-6.917" y2="1.25" width="0.127" layer="21"/>
<wire x1="-9.371" y1="-1.25" x2="-5.869" y2="-1.25" width="0.127" layer="21"/>
<wire x1="-4.291" y1="-1.25" x2="-0.789" y2="-1.25" width="0.127" layer="21"/>
<smd name="5" x="-10.16" y="-1.65" dx="2" dy="1" layer="1" rot="R270"/>
<smd name="3" x="-5.08" y="-1.65" dx="2" dy="1" layer="1" rot="R270"/>
<smd name="1" x="0" y="-1.65" dx="2" dy="1" layer="1" rot="R270"/>
<smd name="6" x="-12.7" y="1.65" dx="2" dy="1" layer="1" rot="R270"/>
<smd name="4" x="-7.62" y="1.65" dx="2" dy="1" layer="1" rot="R270"/>
<smd name="2" x="-2.54" y="1.65" dx="2" dy="1" layer="1" rot="R270"/>
<text x="-13.716" y="2.921" size="0.6096" layer="25" font="vector" ratio="20">&gt;NAME</text>
<text x="-13.843" y="-3.556" size="0.6096" layer="27" font="vector" ratio="20">&gt;VALUE</text>
</package>
<package name="1X06_SMD_STRAIGHT_COMBO">
<description>&lt;h3&gt; 6 Pin SMD Female Header - Combined Footprint&lt;/h3&gt;

&lt;p&gt;Specifications:
&lt;ul&gt;&lt;li&gt;Pin count:6&lt;/li&gt;
&lt;li&gt;Pin pitch:0.1"&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;
&lt;p&gt;&lt;a href=”http://cdn.sparkfun.com/datasheets/Prototyping/femaleSMDheader.pdf”&gt;Datasheet referenced for footprint:&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;Example device(s):
&lt;ul&gt;&lt;li&gt;CONN_06&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;</description>
<wire x1="12.7" y1="1.27" x2="12.7" y2="-1.27" width="0.4064" layer="1"/>
<wire x1="10.16" y1="1.27" x2="10.16" y2="-1.27" width="0.4064" layer="1"/>
<wire x1="7.62" y1="1.27" x2="7.62" y2="-1.27" width="0.4064" layer="1"/>
<wire x1="5.08" y1="1.27" x2="5.08" y2="-1.27" width="0.4064" layer="1"/>
<wire x1="2.54" y1="1.27" x2="2.54" y2="-1.27" width="0.4064" layer="1"/>
<wire x1="0" y1="1.27" x2="0" y2="-1.27" width="0.4064" layer="1"/>
<wire x1="-1.37" y1="-1.25" x2="-1.37" y2="1.25" width="0.2032" layer="21"/>
<wire x1="14.07" y1="1.25" x2="14.07" y2="-1.25" width="0.2032" layer="21"/>
<wire x1="-0.73" y1="-1.25" x2="-1.37" y2="-1.25" width="0.2032" layer="21"/>
<wire x1="14.07" y1="-1.25" x2="13.4" y2="-1.25" width="0.2032" layer="21"/>
<wire x1="13.4" y1="1.25" x2="14.07" y2="1.25" width="0.2032" layer="21"/>
<wire x1="-1.37" y1="1.25" x2="-0.73" y2="1.25" width="0.2032" layer="21"/>
<wire x1="10.949" y1="1.25" x2="11.911" y2="1.25" width="0.2032" layer="21"/>
<wire x1="10.949" y1="-1.29" x2="11.911" y2="-1.29" width="0.2032" layer="21"/>
<wire x1="8.409" y1="1.25" x2="9.371" y2="1.25" width="0.2032" layer="21"/>
<wire x1="8.409" y1="-1.29" x2="9.371" y2="-1.29" width="0.2032" layer="21"/>
<wire x1="5.869" y1="-1.29" x2="6.831" y2="-1.29" width="0.2032" layer="21"/>
<wire x1="5.869" y1="1.25" x2="6.831" y2="1.25" width="0.2032" layer="21"/>
<wire x1="3.329" y1="-1.29" x2="4.291" y2="-1.29" width="0.2032" layer="21"/>
<wire x1="3.329" y1="1.25" x2="4.291" y2="1.25" width="0.2032" layer="21"/>
<wire x1="0.789" y1="-1.29" x2="1.751" y2="-1.29" width="0.2032" layer="21"/>
<wire x1="0.789" y1="1.25" x2="1.751" y2="1.25" width="0.2032" layer="21"/>
<smd name="5" x="10.16" y="-1.65" dx="2" dy="1" layer="1" rot="R270"/>
<smd name="3" x="5.08" y="-1.65" dx="2" dy="1" layer="1" rot="R270"/>
<smd name="1" x="0" y="-1.65" dx="2" dy="1" layer="1" rot="R270"/>
<smd name="6" x="12.7" y="1.65" dx="2" dy="1" layer="1" rot="R270"/>
<smd name="4" x="7.62" y="1.65" dx="2" dy="1" layer="1" rot="R270"/>
<smd name="2" x="2.54" y="1.65" dx="2" dy="1" layer="1" rot="R270"/>
<smd name="1-2" x="0" y="1.65" dx="2" dy="1" layer="1" rot="R90"/>
<smd name="2-2" x="2.54" y="-1.65" dx="2" dy="1" layer="1" rot="R90"/>
<smd name="3-2" x="5.08" y="1.65" dx="2" dy="1" layer="1" rot="R90"/>
<smd name="4-2" x="7.62" y="-1.65" dx="2" dy="1" layer="1" rot="R90"/>
<smd name="5-2" x="10.16" y="1.65" dx="2" dy="1" layer="1" rot="R90"/>
<smd name="6-2" x="12.7" y="-1.65" dx="2" dy="1" layer="1" rot="R90"/>
<text x="-0.508" y="2.921" size="0.6096" layer="25" font="vector" ratio="20">&gt;NAME</text>
<text x="-0.508" y="-3.556" size="0.6096" layer="27" font="vector" ratio="20">&gt;VALUE</text>
</package>
<package name="1X06_SMD_MALE">
<description>&lt;h3&gt; 6 Pin SMD Male Header&lt;/h3&gt;
&lt;p&gt;Specifications:
&lt;ul&gt;&lt;li&gt;Pin count:6&lt;/li&gt;
&lt;li&gt;Pin pitch:0.1"&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;
&lt;p&gt;&lt;a href=”http://cdn.sparkfun.com/datasheets/Prototyping/maleSMDheader.pdf”&gt;Datasheet referenced for footprint:&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;Example device(s):
&lt;ul&gt;&lt;li&gt;CONN_06&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;</description>
<wire x1="-1.27" y1="1.25" x2="-1.27" y2="-1.25" width="0.127" layer="51"/>
<wire x1="-1.27" y1="-1.25" x2="13.97" y2="-1.25" width="0.127" layer="51"/>
<wire x1="13.97" y1="-1.25" x2="13.97" y2="1.25" width="0.127" layer="51"/>
<wire x1="13.97" y1="1.25" x2="-1.27" y2="1.25" width="0.127" layer="51"/>
<circle x="0" y="0" radius="0.64" width="0.127" layer="51"/>
<circle x="2.54" y="0" radius="0.64" width="0.127" layer="51"/>
<circle x="5.08" y="0" radius="0.64" width="0.127" layer="51"/>
<circle x="7.62" y="0" radius="0.64" width="0.127" layer="51"/>
<circle x="10.16" y="0" radius="0.64" width="0.127" layer="51"/>
<circle x="12.7" y="0" radius="0.64" width="0.127" layer="51"/>
<rectangle x1="-0.32" y1="0" x2="0.32" y2="2.75" layer="51"/>
<rectangle x1="4.76" y1="0" x2="5.4" y2="2.75" layer="51"/>
<rectangle x1="9.84" y1="0" x2="10.48" y2="2.75" layer="51"/>
<rectangle x1="2.22" y1="-2.75" x2="2.86" y2="0" layer="51" rot="R180"/>
<rectangle x1="7.3" y1="-2.75" x2="7.94" y2="0" layer="51" rot="R180"/>
<rectangle x1="12.38" y1="-2.75" x2="13.02" y2="0" layer="51" rot="R180"/>
<smd name="1" x="0" y="0" dx="1.02" dy="6" layer="1"/>
<smd name="2" x="2.54" y="0" dx="1.02" dy="6" layer="1"/>
<smd name="3" x="5.08" y="0" dx="1.02" dy="6" layer="1"/>
<smd name="4" x="7.62" y="0" dx="1.02" dy="6" layer="1"/>
<smd name="5" x="10.16" y="0" dx="1.02" dy="6" layer="1"/>
<smd name="6" x="12.7" y="0" dx="1.02" dy="6" layer="1"/>
<wire x1="-1.27" y1="1.25" x2="-1.27" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="-1.27" y1="-1.25" x2="-0.635" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="-1.27" y1="1.25" x2="-0.635" y2="1.25" width="0.1778" layer="21"/>
<wire x1="0.762" y1="1.25" x2="1.778" y2="1.25" width="0.1778" layer="21"/>
<wire x1="3.302" y1="1.25" x2="4.318" y2="1.25" width="0.1778" layer="21"/>
<wire x1="5.842" y1="1.25" x2="6.858" y2="1.25" width="0.1778" layer="21"/>
<wire x1="8.382" y1="1.25" x2="9.398" y2="1.25" width="0.1778" layer="21"/>
<wire x1="10.922" y1="1.25" x2="11.938" y2="1.25" width="0.1778" layer="21"/>
<wire x1="1.778" y1="-1.25" x2="0.762" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="4.318" y1="-1.25" x2="3.302" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="6.858" y1="-1.25" x2="5.842" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="9.398" y1="-1.25" x2="8.382" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="11.938" y1="-1.25" x2="10.922" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="13.97" y1="-1.25" x2="13.97" y2="1.25" width="0.1778" layer="21"/>
<wire x1="13.97" y1="-1.25" x2="13.335" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="13.97" y1="1.25" x2="13.335" y2="1.25" width="0.1778" layer="21"/>
<text x="-0.508" y="3.302" size="0.6096" layer="25" font="vector" ratio="20">&gt;NAME</text>
<text x="-0.635" y="-3.937" size="0.6096" layer="27" font="vector" ratio="20">&gt;VALUE</text>
</package>
<package name="1X06-1MM">
<description>&lt;h3&gt;JST SH Vertical  6-Pin Connector -SMD&lt;/h3&gt;
&lt;p&gt;Specifications:
&lt;ul&gt;&lt;li&gt;Pin count:6&lt;/li&gt;
&lt;li&gt;Pin pitch:1mm&lt;/li&gt;
&lt;p&gt;&lt;b&gt;&lt;a href="https://www.sparkfun.com/datasheets/GPS/EM406-SMDConnector-eSH.pdf"&gt;Datasheet referenced for footprint&lt;/a&gt;&lt;/b&gt;&lt;/p&gt;
&lt;/ul&gt;&lt;/p&gt;
&lt;p&gt;Example device(s):
&lt;ul&gt;&lt;li&gt;CONN_06&lt;/li&gt;
&lt;li&gt;EM-406&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;</description>
<wire x1="-2.54" y1="-1.651" x2="2.54" y2="-1.651" width="0.254" layer="21"/>
<wire x1="-4.318" y1="0.508" x2="-4.318" y2="1.905" width="0.254" layer="21"/>
<wire x1="3.302" y1="1.905" x2="4.318" y2="1.905" width="0.254" layer="21"/>
<wire x1="4.318" y1="1.905" x2="4.318" y2="0.508" width="0.254" layer="21"/>
<wire x1="-4.318" y1="1.905" x2="-3.302" y2="1.905" width="0.254" layer="21"/>
<smd name="1" x="-2.54" y="1.27" dx="0.6" dy="1.55" layer="1"/>
<smd name="2" x="-1.54" y="1.27" dx="0.6" dy="1.55" layer="1"/>
<smd name="3" x="-0.54" y="1.27" dx="0.6" dy="1.55" layer="1"/>
<smd name="4" x="0.46" y="1.27" dx="0.6" dy="1.55" layer="1"/>
<smd name="5" x="1.46" y="1.27" dx="0.6" dy="1.55" layer="1"/>
<smd name="6" x="2.46" y="1.27" dx="0.6" dy="1.55" layer="1"/>
<smd name="P$1" x="-3.84" y="-0.955" dx="1.2" dy="1.8" layer="1"/>
<smd name="P$2" x="3.76" y="-0.955" dx="1.2" dy="1.8" layer="1"/>
<text x="-1.397" y="-0.381" size="0.6096" layer="25" font="vector" ratio="20">&gt;NAME</text>
<text x="-1.651" y="-1.27" size="0.6096" layer="27" font="vector" ratio="20">&gt;VALUE</text>
<circle x="-3.6" y="2.47" radius="0.1047" width="0.4064" layer="21"/>
</package>
<package name="1X06_NO_SILK">
<description>&lt;h3&gt;Plated Through Hole - 6 Pin No Silk Outline&lt;/h3&gt;
&lt;p&gt;Specifications:
&lt;ul&gt;&lt;li&gt;Pin count:6&lt;/li&gt;
&lt;li&gt;Pin pitch:0.1"&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;
&lt;p&gt;Example device(s):
&lt;ul&gt;&lt;li&gt;CONN_06&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;</description>
<pad name="1" x="0" y="0" drill="1.016" diameter="1.8796" rot="R90"/>
<pad name="2" x="2.54" y="0" drill="1.016" diameter="1.8796" rot="R90"/>
<pad name="3" x="5.08" y="0" drill="1.016" diameter="1.8796" rot="R90"/>
<pad name="4" x="7.62" y="0" drill="1.016" diameter="1.8796" rot="R90"/>
<pad name="5" x="10.16" y="0" drill="1.016" diameter="1.8796" rot="R90"/>
<pad name="6" x="12.7" y="0" drill="1.016" diameter="1.8796" rot="R90"/>
<rectangle x1="12.446" y1="-0.254" x2="12.954" y2="0.254" layer="51"/>
<rectangle x1="9.906" y1="-0.254" x2="10.414" y2="0.254" layer="51"/>
<rectangle x1="7.366" y1="-0.254" x2="7.874" y2="0.254" layer="51"/>
<rectangle x1="4.826" y1="-0.254" x2="5.334" y2="0.254" layer="51"/>
<rectangle x1="2.286" y1="-0.254" x2="2.794" y2="0.254" layer="51"/>
<rectangle x1="-0.254" y1="-0.254" x2="0.254" y2="0.254" layer="51"/>
<text x="-1.27" y="1.397" size="0.6096" layer="25" font="vector" ratio="20">&gt;NAME</text>
<text x="-1.27" y="-2.032" size="0.6096" layer="27" font="vector" ratio="20">&gt;VALUE</text>
</package>
<package name="1X06_1.27MM">
<description>&lt;h3&gt;Plated Through Hole - 6 Pin&lt;/h3&gt;
&lt;p&gt;Specifications:
&lt;ul&gt;&lt;li&gt;Pin count:6&lt;/li&gt;
&lt;li&gt;Pin pitch:1.27mm&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;
&lt;p&gt;Example device(s):
&lt;ul&gt;&lt;li&gt;CONN_06&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;</description>
<wire x1="-0.381" y1="-0.889" x2="0.381" y2="-0.889" width="0.127" layer="21"/>
<wire x1="0.381" y1="-0.889" x2="0.635" y2="-0.635" width="0.127" layer="21"/>
<wire x1="0.635" y1="-0.635" x2="0.889" y2="-0.889" width="0.127" layer="21"/>
<wire x1="0.889" y1="-0.889" x2="1.651" y2="-0.889" width="0.127" layer="21"/>
<wire x1="1.651" y1="-0.889" x2="1.905" y2="-0.635" width="0.127" layer="21"/>
<wire x1="1.905" y1="-0.635" x2="2.159" y2="-0.889" width="0.127" layer="21"/>
<wire x1="2.159" y1="-0.889" x2="2.921" y2="-0.889" width="0.127" layer="21"/>
<wire x1="2.921" y1="-0.889" x2="3.175" y2="-0.635" width="0.127" layer="21"/>
<wire x1="3.175" y1="-0.635" x2="3.429" y2="-0.889" width="0.127" layer="21"/>
<wire x1="3.429" y1="-0.889" x2="4.191" y2="-0.889" width="0.127" layer="21"/>
<wire x1="4.191" y1="-0.889" x2="4.445" y2="-0.635" width="0.127" layer="21"/>
<wire x1="4.445" y1="-0.635" x2="4.699" y2="-0.889" width="0.127" layer="21"/>
<wire x1="4.699" y1="-0.889" x2="5.461" y2="-0.889" width="0.127" layer="21"/>
<wire x1="5.461" y1="0.889" x2="4.699" y2="0.889" width="0.127" layer="21"/>
<wire x1="4.699" y1="0.889" x2="4.445" y2="0.635" width="0.127" layer="21"/>
<wire x1="4.445" y1="0.635" x2="4.191" y2="0.889" width="0.127" layer="21"/>
<wire x1="4.191" y1="0.889" x2="3.429" y2="0.889" width="0.127" layer="21"/>
<wire x1="3.429" y1="0.889" x2="3.175" y2="0.635" width="0.127" layer="21"/>
<wire x1="3.175" y1="0.635" x2="2.921" y2="0.889" width="0.127" layer="21"/>
<wire x1="2.921" y1="0.889" x2="2.159" y2="0.889" width="0.127" layer="21"/>
<wire x1="2.159" y1="0.889" x2="1.905" y2="0.635" width="0.127" layer="21"/>
<wire x1="1.905" y1="0.635" x2="1.651" y2="0.889" width="0.127" layer="21"/>
<wire x1="1.651" y1="0.889" x2="0.889" y2="0.889" width="0.127" layer="21"/>
<wire x1="0.889" y1="0.889" x2="0.635" y2="0.635" width="0.127" layer="21"/>
<wire x1="0.635" y1="0.635" x2="0.381" y2="0.889" width="0.127" layer="21"/>
<wire x1="0.381" y1="0.889" x2="-0.381" y2="0.889" width="0.127" layer="21"/>
<wire x1="-0.381" y1="0.889" x2="-0.889" y2="0.381" width="0.127" layer="21"/>
<wire x1="-0.889" y1="-0.381" x2="-0.381" y2="-0.889" width="0.127" layer="21"/>
<wire x1="-0.889" y1="0.381" x2="-0.889" y2="-0.381" width="0.127" layer="21"/>
<pad name="5" x="5.08" y="0" drill="0.508" diameter="1"/>
<pad name="4" x="3.81" y="0" drill="0.508" diameter="1"/>
<pad name="3" x="2.54" y="0" drill="0.508" diameter="1"/>
<pad name="2" x="1.27" y="0" drill="0.508" diameter="1"/>
<pad name="1" x="0" y="0" drill="0.508" diameter="1"/>
<pad name="6" x="6.35" y="0" drill="0.508" diameter="1"/>
<wire x1="5.461" y1="-0.889" x2="5.715" y2="-0.635" width="0.127" layer="21"/>
<wire x1="5.715" y1="-0.635" x2="5.969" y2="-0.889" width="0.127" layer="21"/>
<wire x1="5.969" y1="-0.889" x2="6.731" y2="-0.889" width="0.127" layer="21"/>
<wire x1="6.731" y1="0.889" x2="5.969" y2="0.889" width="0.127" layer="21"/>
<wire x1="5.969" y1="0.889" x2="5.715" y2="0.635" width="0.127" layer="21"/>
<wire x1="5.715" y1="0.635" x2="5.461" y2="0.889" width="0.127" layer="21"/>
<wire x1="6.731" y1="0.889" x2="7.239" y2="0.381" width="0.127" layer="21"/>
<wire x1="7.239" y1="0.381" x2="7.239" y2="-0.381" width="0.127" layer="21"/>
<wire x1="7.239" y1="-0.381" x2="6.731" y2="-0.889" width="0.127" layer="21"/>
<text x="-0.381" y="1.016" size="0.6096" layer="25" font="vector" ratio="20">&gt;NAME</text>
<text x="-0.381" y="-1.651" size="0.6096" layer="27" font="vector" ratio="20">&gt;VALUE</text>
</package>
<package name="1X06_SCREW_TERMINAL_BLOCK">
<wire x1="-10.4" y1="-4.85" x2="10.4" y2="-4.85" width="0.2032" layer="51"/>
<wire x1="10.4" y1="-4.85" x2="10.4" y2="6.05" width="0.2032" layer="51"/>
<wire x1="10.4" y1="6.05" x2="-10.4" y2="6.05" width="0.2032" layer="51"/>
<wire x1="-10.4" y1="6.05" x2="-10.4" y2="-4.85" width="0.2032" layer="51"/>
<rectangle x1="-9.275" y1="-4.9" x2="-8.225" y2="-1.225" layer="51"/>
<rectangle x1="-5.775" y1="-4.9" x2="-4.725" y2="-1.225" layer="51"/>
<rectangle x1="-2.275" y1="-4.9" x2="-1.225" y2="-1.225" layer="51"/>
<rectangle x1="1.225" y1="-4.9" x2="2.275" y2="-1.225" layer="51"/>
<rectangle x1="4.725" y1="-4.9" x2="5.775" y2="-1.225" layer="51"/>
<rectangle x1="8.225" y1="-4.9" x2="9.275" y2="-1.225" layer="51"/>
<pad name="1" x="-8.75" y="5.25" drill="1.4224" shape="long" rot="R90"/>
<pad name="2" x="-5.25" y="5.25" drill="1.4224" shape="long" rot="R90"/>
<pad name="3" x="-1.75" y="5.25" drill="1.4224" shape="long" rot="R90"/>
<pad name="4" x="1.75" y="5.25" drill="1.4224" shape="long" rot="R90"/>
<pad name="5" x="5.25" y="5.25" drill="1.4224" shape="long" rot="R90"/>
<pad name="6" x="8.75" y="5.25" drill="1.4224" shape="long" rot="R90"/>
<text x="-3.67" y="7.635" size="1.27" layer="25">&gt;NAME</text>
<text x="-3.67" y="-6.505" size="1.27" layer="27">&gt;VALUE</text>
</package>
<package name="JST-6-SMD-1.25MM-LOCKING">
<wire x1="-4.25" y1="-0.93" x2="4.25" y2="-0.93" width="0.2032" layer="21"/>
<smd name="1" x="-3.125" y="3.3" dx="0.6" dy="1.7" layer="1" rot="R180"/>
<smd name="NC1" x="4.975" y="0.1" dx="2.7" dy="1" layer="1" rot="R270"/>
<smd name="NC2" x="-4.975" y="0.1" dx="2.7" dy="1" layer="1" rot="R270"/>
<wire x1="-5.375" y1="3.05" x2="5.375" y2="3.05" width="0.01" layer="51"/>
<wire x1="5.375" y1="3.05" x2="5.375" y2="-1" width="0.01" layer="51"/>
<wire x1="5.375" y1="-1" x2="-5.375" y2="-1" width="0.01" layer="51"/>
<wire x1="-5.375" y1="-1" x2="-5.375" y2="3.05" width="0.01" layer="51"/>
<text x="0" y="1" size="0.5" layer="25" align="center">&gt;Name</text>
<text x="0" y="0" size="0.5" layer="27" align="center">&gt;Value</text>
<smd name="2" x="-1.875" y="3.3" dx="0.6" dy="1.7" layer="1" rot="R180"/>
<smd name="3" x="-0.625" y="3.3" dx="0.6" dy="1.7" layer="1" rot="R180"/>
<smd name="4" x="0.625" y="3.3" dx="0.6" dy="1.7" layer="1" rot="R180"/>
<rectangle x1="-3.225" y1="3.05" x2="-3.025" y2="3.85" layer="51"/>
<rectangle x1="-1.975" y1="3.05" x2="-1.775" y2="3.85" layer="51"/>
<rectangle x1="-0.725" y1="3.05" x2="-0.525" y2="3.85" layer="51"/>
<rectangle x1="0.525" y1="3.05" x2="0.725" y2="3.85" layer="51"/>
<rectangle x1="4.875" y1="-1" x2="5.075" y2="1.2" layer="51"/>
<rectangle x1="-5.075" y1="-1" x2="-4.875" y2="1.2" layer="51"/>
<wire x1="-5.3" y1="2" x2="-5.3" y2="2.95" width="0.2032" layer="21"/>
<wire x1="-5.3" y1="2.95" x2="-4.25" y2="2.95" width="0.2032" layer="21"/>
<wire x1="4.25" y1="2.95" x2="5.3" y2="2.95" width="0.2032" layer="21"/>
<wire x1="5.3" y1="2" x2="5.3" y2="2.95" width="0.2032" layer="21"/>
<smd name="5" x="1.875" y="3.3" dx="0.6" dy="1.7" layer="1" rot="R180"/>
<smd name="6" x="3.125" y="3.3" dx="0.6" dy="1.7" layer="1" rot="R180"/>
<rectangle x1="1.775" y1="3.05" x2="1.975" y2="3.85" layer="51"/>
<rectangle x1="3.025" y1="3.05" x2="3.225" y2="3.85" layer="51"/>
</package>
</packages>
<symbols>
<symbol name="CONN_06">
<description>&lt;h3&gt;6 Pin Connection&lt;/h3&gt;</description>
<wire x1="1.27" y1="-7.62" x2="-5.08" y2="-7.62" width="0.4064" layer="94"/>
<wire x1="-1.27" y1="0" x2="0" y2="0" width="0.6096" layer="94"/>
<wire x1="-1.27" y1="-2.54" x2="0" y2="-2.54" width="0.6096" layer="94"/>
<wire x1="-1.27" y1="-5.08" x2="0" y2="-5.08" width="0.6096" layer="94"/>
<wire x1="-5.08" y1="10.16" x2="-5.08" y2="-7.62" width="0.4064" layer="94"/>
<wire x1="1.27" y1="-7.62" x2="1.27" y2="10.16" width="0.4064" layer="94"/>
<wire x1="-5.08" y1="10.16" x2="1.27" y2="10.16" width="0.4064" layer="94"/>
<wire x1="-1.27" y1="5.08" x2="0" y2="5.08" width="0.6096" layer="94"/>
<wire x1="-1.27" y1="2.54" x2="0" y2="2.54" width="0.6096" layer="94"/>
<wire x1="-1.27" y1="7.62" x2="0" y2="7.62" width="0.6096" layer="94"/>
<text x="-5.08" y="-9.906" size="1.778" layer="96" font="vector">&gt;VALUE</text>
<text x="-5.08" y="10.668" size="1.778" layer="95" font="vector">&gt;NAME</text>
<pin name="1" x="5.08" y="-5.08" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="2" x="5.08" y="-2.54" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="3" x="5.08" y="0" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="4" x="5.08" y="2.54" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="5" x="5.08" y="5.08" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="6" x="5.08" y="7.62" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="CONN_06" prefix="J" uservalue="yes">
<description>&lt;h3&gt;Multi connection point. Often used as Generic Header-pin footprint for 0.1 inch spaced/style header connections&lt;/h3&gt;

&lt;p&gt;&lt;/p&gt;
&lt;b&gt;On any of the 0.1 inch spaced packages, you can populate with these:&lt;/b&gt;
&lt;ul&gt;
&lt;li&gt;&lt;a href="https://www.sparkfun.com/products/116"&gt; Break Away Headers - Straight&lt;/a&gt; (PRT-00116)&lt;/li&gt;
&lt;li&gt;&lt;a href="https://www.sparkfun.com/products/553"&gt; Break Away Male Headers - Right Angle&lt;/a&gt; (PRT-00553)&lt;/li&gt;
&lt;li&gt;&lt;a href="https://www.sparkfun.com/products/115"&gt; Female Headers&lt;/a&gt; (PRT-00115)&lt;/li&gt;
&lt;li&gt;&lt;a href="https://www.sparkfun.com/products/117"&gt; Break Away Headers - Machine Pin&lt;/a&gt; (PRT-00117)&lt;/li&gt;
&lt;li&gt;&lt;a href="https://www.sparkfun.com/products/743"&gt; Break Away Female Headers - Swiss Machine Pin&lt;/a&gt; (PRT-00743)&lt;/li&gt;
&lt;li&gt;&lt;a href="https://www.sparkfun.com/products/9280"&gt; Arduino Stackable Header - 6 Pin&lt;/a&gt; (PRT-09280)&lt;/li&gt;
&lt;/ul&gt;

&lt;p&gt;&lt;/p&gt;
&lt;b&gt; For SCREWTERMINALS and SPRING TERMINALS visit here:&lt;/b&gt;
&lt;ul&gt;
&lt;li&gt;&lt;a href="https://www.sparkfun.com/search/results?term=Screw+Terminals"&gt; Screw Terimnals on SparkFun.com&lt;/a&gt; (5mm/3.5mm/2.54mm spacing)&lt;/li&gt;
&lt;/ul&gt;

&lt;p&gt;&lt;/p&gt;
&lt;b&gt;This device is also useful as a general connection point to wire up your design to another part of your project. Our various solder wires solder well into these plated through hole pads.&lt;/b&gt;
&lt;ul&gt;
&lt;li&gt;&lt;a href="https://www.sparkfun.com/products/11375"&gt; Hook-Up Wire - Assortment (Stranded, 22 AWG)&lt;/a&gt; (PRT-11375)&lt;/li&gt;
&lt;li&gt;&lt;a href="https://www.sparkfun.com/products/11367"&gt; Hook-Up Wire - Assortment (Solid Core, 22 AWG)&lt;/a&gt; (PRT-11367)&lt;/li&gt;
&lt;li&gt;&lt;a href="https://www.sparkfun.com/categories/141"&gt; View the entire wire category on our website here&lt;/a&gt;&lt;/li&gt;
&lt;p&gt;&lt;/p&gt;
&lt;/ul&gt;</description>
<gates>
<gate name="G$1" symbol="CONN_06" x="-2.54" y="0"/>
</gates>
<devices>
<device name="SILK_FEMALE_PTH" package="1X06">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CONN-08437"/>
</technology>
</technologies>
</device>
<device name="POLAR" package="MOLEX-1X6">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="RA" package="MOLEX-1X6-RA">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="SMD" package="1X06-SMD_RA_MALE">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CONN-08971" constant="no"/>
<attribute name="VALUE" value="RA 6Pin SMD" constant="no"/>
</technology>
</technologies>
</device>
<device name="LOCK" package="1X06_LOCK">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="LOCK_LONGPADS" package="1X06_LOCK_LONGPADS">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="POLAR_LOCK" package="MOLEX-1X6_LOCK">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="RA_LOCK" package="MOLEX_1X6_RA_LOCK">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="FEMALE_LOCK" package="1X06_FEMALE_LOCK.010">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="LONGPADS" package="1X06_LONGPADS">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="3.5MM-6" package="SCREWTERMINAL-3.5MM-6">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CONN-13617" constant="no"/>
</technology>
</technologies>
</device>
<device name="SMD-FEMALE-V2" package="1X06-SMD-FEMALE">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CONN-09668"/>
</technology>
</technologies>
</device>
<device name="POGOPIN_HOLES_ONLY" package="1X06_HOLES_ONLY">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CONN-08437"/>
</technology>
</technologies>
</device>
<device name="SMD-STRAIGHT-FEMALE" package="1X06_SMD_STRAIGHT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CONN-10203"/>
</technology>
</technologies>
</device>
<device name="SMD-STRAIGHT-ALT-FEMALE" package="1X06_SMD_STRAIGHT_ALT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CONN-10203"/>
</technology>
</technologies>
</device>
<device name="SMD-STRAIGHT-COMBO-FEMALE" package="1X06_SMD_STRAIGHT_COMBO">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CONN-10203"/>
</technology>
</technologies>
</device>
<device name="SMD_MALE" package="1X06_SMD_MALE">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CONN-11293"/>
</technology>
</technologies>
</device>
<device name="SMD-1MM" package="1X06-1MM">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CONN-08249" constant="no"/>
<attribute name="SF_ID" value="GPS-00579" constant="no"/>
</technology>
</technologies>
</device>
<device name="NO_SILK_FEMALE_PTH" package="1X06_NO_SILK">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CONN-08437"/>
</technology>
</technologies>
</device>
<device name="1.27MM" package="1X06_1.27MM">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="NO_SILK_NO_POP" package="1X06_NO_SILK">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="2.5MM-6-90" package="1X06_SCREW_TERMINAL_BLOCK">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="JST-SMD-LOCKING" package="JST-6-SMD-1.25MM-LOCKING">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="CONN-16497" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="pinhead" urn="urn:adsk.eagle:library:325">
<description>&lt;b&gt;Pin Header Connectors&lt;/b&gt;&lt;p&gt;
&lt;author&gt;Created by librarian@cadsoft.de&lt;/author&gt;</description>
<packages>
<package name="2X05" urn="urn:adsk.eagle:footprint:22358/1" library_version="4">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<wire x1="-6.35" y1="-1.905" x2="-5.715" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-4.445" y1="-2.54" x2="-3.81" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="-1.905" x2="-3.175" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="-2.54" x2="-1.27" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="-1.905" x2="-0.635" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="0.635" y1="-2.54" x2="1.27" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="1.27" y1="-1.905" x2="1.905" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="3.175" y1="-2.54" x2="3.81" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-6.35" y1="-1.905" x2="-6.35" y2="1.905" width="0.1524" layer="21"/>
<wire x1="-6.35" y1="1.905" x2="-5.715" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-5.715" y1="2.54" x2="-4.445" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-4.445" y1="2.54" x2="-3.81" y2="1.905" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="1.905" x2="-3.175" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="2.54" x2="-1.905" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="2.54" x2="-1.27" y2="1.905" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="1.905" x2="-0.635" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-0.635" y1="2.54" x2="0.635" y2="2.54" width="0.1524" layer="21"/>
<wire x1="0.635" y1="2.54" x2="1.27" y2="1.905" width="0.1524" layer="21"/>
<wire x1="1.27" y1="1.905" x2="1.905" y2="2.54" width="0.1524" layer="21"/>
<wire x1="1.905" y1="2.54" x2="3.175" y2="2.54" width="0.1524" layer="21"/>
<wire x1="3.175" y1="2.54" x2="3.81" y2="1.905" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="1.905" x2="-3.81" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="1.905" x2="-1.27" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="1.27" y1="1.905" x2="1.27" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="3.81" y1="1.905" x2="3.81" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="1.905" y1="-2.54" x2="3.175" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-0.635" y1="-2.54" x2="0.635" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="-2.54" x2="-1.905" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-5.715" y1="-2.54" x2="-4.445" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="3.81" y1="-1.905" x2="4.445" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="5.715" y1="-2.54" x2="6.35" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="3.81" y1="1.905" x2="4.445" y2="2.54" width="0.1524" layer="21"/>
<wire x1="4.445" y1="2.54" x2="5.715" y2="2.54" width="0.1524" layer="21"/>
<wire x1="5.715" y1="2.54" x2="6.35" y2="1.905" width="0.1524" layer="21"/>
<wire x1="6.35" y1="1.905" x2="6.35" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="4.445" y1="-2.54" x2="5.715" y2="-2.54" width="0.1524" layer="21"/>
<pad name="1" x="-5.08" y="-1.27" drill="1.016" shape="octagon"/>
<pad name="2" x="-5.08" y="1.27" drill="1.016" shape="octagon"/>
<pad name="3" x="-2.54" y="-1.27" drill="1.016" shape="octagon"/>
<pad name="4" x="-2.54" y="1.27" drill="1.016" shape="octagon"/>
<pad name="5" x="0" y="-1.27" drill="1.016" shape="octagon"/>
<pad name="6" x="0" y="1.27" drill="1.016" shape="octagon"/>
<pad name="7" x="2.54" y="-1.27" drill="1.016" shape="octagon"/>
<pad name="8" x="2.54" y="1.27" drill="1.016" shape="octagon"/>
<pad name="9" x="5.08" y="-1.27" drill="1.016" shape="octagon"/>
<pad name="10" x="5.08" y="1.27" drill="1.016" shape="octagon"/>
<text x="-6.35" y="3.175" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-6.35" y="-4.445" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-5.334" y1="-1.524" x2="-4.826" y2="-1.016" layer="51"/>
<rectangle x1="-5.334" y1="1.016" x2="-4.826" y2="1.524" layer="51"/>
<rectangle x1="-2.794" y1="1.016" x2="-2.286" y2="1.524" layer="51"/>
<rectangle x1="-2.794" y1="-1.524" x2="-2.286" y2="-1.016" layer="51"/>
<rectangle x1="-0.254" y1="1.016" x2="0.254" y2="1.524" layer="51"/>
<rectangle x1="-0.254" y1="-1.524" x2="0.254" y2="-1.016" layer="51"/>
<rectangle x1="2.286" y1="1.016" x2="2.794" y2="1.524" layer="51"/>
<rectangle x1="2.286" y1="-1.524" x2="2.794" y2="-1.016" layer="51"/>
<rectangle x1="4.826" y1="1.016" x2="5.334" y2="1.524" layer="51"/>
<rectangle x1="4.826" y1="-1.524" x2="5.334" y2="-1.016" layer="51"/>
</package>
<package name="2X05/90" urn="urn:adsk.eagle:footprint:22359/1" library_version="4">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<wire x1="-6.35" y1="-1.905" x2="-3.81" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="-1.905" x2="-3.81" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="0.635" x2="-6.35" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-6.35" y1="0.635" x2="-6.35" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="6.985" x2="-5.08" y2="1.27" width="0.762" layer="21"/>
<wire x1="-3.81" y1="-1.905" x2="-1.27" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="-1.905" x2="-1.27" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="0.635" x2="-3.81" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="6.985" x2="-2.54" y2="1.27" width="0.762" layer="21"/>
<wire x1="-1.27" y1="-1.905" x2="1.27" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="1.27" y1="-1.905" x2="1.27" y2="0.635" width="0.1524" layer="21"/>
<wire x1="1.27" y1="0.635" x2="-1.27" y2="0.635" width="0.1524" layer="21"/>
<wire x1="0" y1="6.985" x2="0" y2="1.27" width="0.762" layer="21"/>
<wire x1="1.27" y1="-1.905" x2="3.81" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="3.81" y1="-1.905" x2="3.81" y2="0.635" width="0.1524" layer="21"/>
<wire x1="3.81" y1="0.635" x2="1.27" y2="0.635" width="0.1524" layer="21"/>
<wire x1="2.54" y1="6.985" x2="2.54" y2="1.27" width="0.762" layer="21"/>
<wire x1="3.81" y1="-1.905" x2="6.35" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="6.35" y1="-1.905" x2="6.35" y2="0.635" width="0.1524" layer="21"/>
<wire x1="6.35" y1="0.635" x2="3.81" y2="0.635" width="0.1524" layer="21"/>
<wire x1="5.08" y1="6.985" x2="5.08" y2="1.27" width="0.762" layer="21"/>
<pad name="2" x="-5.08" y="-3.81" drill="1.016" shape="octagon"/>
<pad name="4" x="-2.54" y="-3.81" drill="1.016" shape="octagon"/>
<pad name="6" x="0" y="-3.81" drill="1.016" shape="octagon"/>
<pad name="8" x="2.54" y="-3.81" drill="1.016" shape="octagon"/>
<pad name="10" x="5.08" y="-3.81" drill="1.016" shape="octagon"/>
<pad name="1" x="-5.08" y="-6.35" drill="1.016" shape="octagon"/>
<pad name="3" x="-2.54" y="-6.35" drill="1.016" shape="octagon"/>
<pad name="5" x="0" y="-6.35" drill="1.016" shape="octagon"/>
<pad name="7" x="2.54" y="-6.35" drill="1.016" shape="octagon"/>
<pad name="9" x="5.08" y="-6.35" drill="1.016" shape="octagon"/>
<text x="-6.985" y="-3.81" size="1.27" layer="25" ratio="10" rot="R90">&gt;NAME</text>
<text x="8.255" y="-3.81" size="1.27" layer="27" rot="R90">&gt;VALUE</text>
<rectangle x1="-5.461" y1="0.635" x2="-4.699" y2="1.143" layer="21"/>
<rectangle x1="-2.921" y1="0.635" x2="-2.159" y2="1.143" layer="21"/>
<rectangle x1="-0.381" y1="0.635" x2="0.381" y2="1.143" layer="21"/>
<rectangle x1="2.159" y1="0.635" x2="2.921" y2="1.143" layer="21"/>
<rectangle x1="4.699" y1="0.635" x2="5.461" y2="1.143" layer="21"/>
<rectangle x1="-5.461" y1="-2.921" x2="-4.699" y2="-1.905" layer="21"/>
<rectangle x1="-2.921" y1="-2.921" x2="-2.159" y2="-1.905" layer="21"/>
<rectangle x1="-5.461" y1="-5.461" x2="-4.699" y2="-4.699" layer="21"/>
<rectangle x1="-5.461" y1="-4.699" x2="-4.699" y2="-2.921" layer="51"/>
<rectangle x1="-2.921" y1="-4.699" x2="-2.159" y2="-2.921" layer="51"/>
<rectangle x1="-2.921" y1="-5.461" x2="-2.159" y2="-4.699" layer="21"/>
<rectangle x1="-0.381" y1="-2.921" x2="0.381" y2="-1.905" layer="21"/>
<rectangle x1="2.159" y1="-2.921" x2="2.921" y2="-1.905" layer="21"/>
<rectangle x1="-0.381" y1="-5.461" x2="0.381" y2="-4.699" layer="21"/>
<rectangle x1="-0.381" y1="-4.699" x2="0.381" y2="-2.921" layer="51"/>
<rectangle x1="2.159" y1="-4.699" x2="2.921" y2="-2.921" layer="51"/>
<rectangle x1="2.159" y1="-5.461" x2="2.921" y2="-4.699" layer="21"/>
<rectangle x1="4.699" y1="-2.921" x2="5.461" y2="-1.905" layer="21"/>
<rectangle x1="4.699" y1="-5.461" x2="5.461" y2="-4.699" layer="21"/>
<rectangle x1="4.699" y1="-4.699" x2="5.461" y2="-2.921" layer="51"/>
</package>
</packages>
<packages3d>
<package3d name="2X05" urn="urn:adsk.eagle:package:22470/2" type="model" library_version="4">
<description>PIN HEADER</description>
<packageinstances>
<packageinstance name="2X05"/>
</packageinstances>
</package3d>
<package3d name="2X05/90" urn="urn:adsk.eagle:package:22471/2" type="model" library_version="4">
<description>PIN HEADER</description>
<packageinstances>
<packageinstance name="2X05/90"/>
</packageinstances>
</package3d>
</packages3d>
<symbols>
<symbol name="PINH2X5" urn="urn:adsk.eagle:symbol:22357/1" library_version="4">
<wire x1="-6.35" y1="-7.62" x2="8.89" y2="-7.62" width="0.4064" layer="94"/>
<wire x1="8.89" y1="-7.62" x2="8.89" y2="7.62" width="0.4064" layer="94"/>
<wire x1="8.89" y1="7.62" x2="-6.35" y2="7.62" width="0.4064" layer="94"/>
<wire x1="-6.35" y1="7.62" x2="-6.35" y2="-7.62" width="0.4064" layer="94"/>
<text x="-6.35" y="8.255" size="1.778" layer="95">&gt;NAME</text>
<text x="-6.35" y="-10.16" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-2.54" y="5.08" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="2" x="5.08" y="5.08" visible="pad" length="short" direction="pas" function="dot" rot="R180"/>
<pin name="3" x="-2.54" y="2.54" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="4" x="5.08" y="2.54" visible="pad" length="short" direction="pas" function="dot" rot="R180"/>
<pin name="5" x="-2.54" y="0" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="6" x="5.08" y="0" visible="pad" length="short" direction="pas" function="dot" rot="R180"/>
<pin name="7" x="-2.54" y="-2.54" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="8" x="5.08" y="-2.54" visible="pad" length="short" direction="pas" function="dot" rot="R180"/>
<pin name="9" x="-2.54" y="-5.08" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="10" x="5.08" y="-5.08" visible="pad" length="short" direction="pas" function="dot" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="PINHD-2X5" urn="urn:adsk.eagle:component:22531/4" prefix="JP" uservalue="yes" library_version="4">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<gates>
<gate name="A" symbol="PINH2X5" x="0" y="0"/>
</gates>
<devices>
<device name="" package="2X05">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="10" pad="10"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
<connect gate="A" pin="7" pad="7"/>
<connect gate="A" pin="8" pad="8"/>
<connect gate="A" pin="9" pad="9"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:22470/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="35" constant="no"/>
</technology>
</technologies>
</device>
<device name="/90" package="2X05/90">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="10" pad="10"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
<connect gate="A" pin="7" pad="7"/>
<connect gate="A" pin="8" pad="8"/>
<connect gate="A" pin="9" pad="9"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:22471/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="SparkFun-Fuses">
<description>&lt;h3&gt;SparkFun Fuses&lt;/h3&gt;
In this library you'll find fuses, or fuse like components such as PTCs. Reference designator F.
&lt;br&gt;
&lt;br&gt;
We've spent an enormous amount of time creating and checking these footprints and parts, but it is &lt;b&gt; the end user's responsibility&lt;/b&gt; to ensure correctness and suitablity for a given componet or application. 
&lt;br&gt;
&lt;br&gt;If you enjoy using this library, please buy one of our products at &lt;a href=" www.sparkfun.com"&gt;SparkFun.com&lt;/a&gt;.
&lt;br&gt;
&lt;br&gt;
&lt;b&gt;Licensing:&lt;/b&gt; Creative Commons ShareAlike 4.0 International - https://creativecommons.org/licenses/by-sa/4.0/ 
&lt;br&gt;
&lt;br&gt;
You are welcome to use this library for commercial purposes. For attribution, we ask that when you begin to sell your device using our footprint, you email us with a link to the product being sold. We want bragging rights that we helped (in a very small part) to create your 8th world wonder. We would like the opportunity to feature your device on our homepage.</description>
<packages>
<package name="PTH">
<description>Two 0.8 mm PTHs spaced 0.2 in apart for through hole parts.</description>
<wire x1="-3.81" y1="1.524" x2="3.81" y2="1.524" width="0.2032" layer="21"/>
<wire x1="3.81" y1="1.524" x2="3.81" y2="-1.524" width="0.2032" layer="21"/>
<wire x1="3.81" y1="-1.524" x2="-3.81" y2="-1.524" width="0.2032" layer="21"/>
<wire x1="-3.81" y1="-1.524" x2="-3.81" y2="1.524" width="0.2032" layer="21"/>
<pad name="P$1" x="-2.54" y="0" drill="0.8" diameter="1.8796"/>
<pad name="P$2" x="2.54" y="0" drill="0.8" diameter="1.8796"/>
<text x="0" y="1.778" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;Name</text>
<text x="0" y="-1.778" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;Value</text>
</package>
<package name="1206">
<description>&lt;p&gt;&lt;b&gt;Generic 3216 (1206) package&lt;/b&gt;&lt;/p&gt;
&lt;p&gt;0.2mm courtyard excess rounded to nearest 0.05mm.&lt;/p&gt;</description>
<wire x1="-2.4" y1="1.1" x2="2.4" y2="1.1" width="0.0508" layer="39"/>
<wire x1="2.4" y1="-1.1" x2="-2.4" y2="-1.1" width="0.0508" layer="39"/>
<wire x1="-2.4" y1="-1.1" x2="-2.4" y2="1.1" width="0.0508" layer="39"/>
<wire x1="2.4" y1="1.1" x2="2.4" y2="-1.1" width="0.0508" layer="39"/>
<wire x1="-0.965" y1="0.787" x2="0.965" y2="0.787" width="0.1016" layer="51"/>
<wire x1="-0.965" y1="-0.787" x2="0.965" y2="-0.787" width="0.1016" layer="51"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<text x="0" y="1.143" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.143" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
<rectangle x1="-1.7018" y1="-0.8509" x2="-0.9517" y2="0.8491" layer="51"/>
<rectangle x1="0.9517" y1="-0.8491" x2="1.7018" y2="0.8509" layer="51"/>
<rectangle x1="-0.1999" y1="-0.4001" x2="0.1999" y2="0.4001" layer="35"/>
</package>
<package name="0805">
<description>&lt;p&gt;&lt;b&gt;Generic 2012 (0805) package&lt;/b&gt;&lt;/p&gt;
&lt;p&gt;0.2mm courtyard excess rounded to nearest 0.05mm.&lt;/p&gt;</description>
<smd name="1" x="-0.9" y="0" dx="0.8" dy="1.2" layer="1"/>
<smd name="2" x="0.9" y="0" dx="0.8" dy="1.2" layer="1"/>
<text x="0" y="0.889" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-0.889" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
<wire x1="-1.5" y1="0.8" x2="1.5" y2="0.8" width="0.0508" layer="39"/>
<wire x1="1.5" y1="0.8" x2="1.5" y2="-0.8" width="0.0508" layer="39"/>
<wire x1="1.5" y1="-0.8" x2="-1.5" y2="-0.8" width="0.0508" layer="39"/>
<wire x1="-1.5" y1="-0.8" x2="-1.5" y2="0.8" width="0.0508" layer="39"/>
</package>
<package name="1210">
<description>&lt;p&gt;&lt;b&gt;Generic 3225 (1210) package&lt;/b&gt;&lt;/p&gt;
&lt;p&gt;0.2mm courtyard excess rounded to nearest 0.05mm.&lt;/p&gt; Footprint dimensions are combination from &lt;a href="http://www.vishay.com/docs/45017/vjw1bcsoldfootdesign.pdf"&gt;Vishay&lt;/a&gt; and &lt;a href="https://belfuse.com/resources/CircuitProtection/datasheets/0ZCH%20Nov2016.pdf"&gt;Bel&lt;/a&gt;</description>
<wire x1="-1.625" y1="1.25" x2="1.625" y2="1.25" width="0.127" layer="51"/>
<wire x1="1.625" y1="1.25" x2="1.6245" y2="-1.25" width="0.127" layer="51"/>
<wire x1="1.6245" y1="-1.25" x2="-1.625" y2="-1.25" width="0.127" layer="51"/>
<wire x1="-1.625" y1="-1.25" x2="-1.625" y2="1.25" width="0.127" layer="51"/>
<smd name="1" x="-1.5" y="0" dx="1" dy="2.8" layer="1"/>
<smd name="2" x="1.5" y="0" dx="1" dy="2.8" layer="1"/>
<text x="0" y="1.397" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.397" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
<wire x1="-2.215" y1="1.575" x2="2.215" y2="1.575" width="0.0508" layer="39"/>
<wire x1="2.215" y1="1.575" x2="2.215" y2="-1.575" width="0.0508" layer="39"/>
<wire x1="2.215" y1="-1.575" x2="-2.215" y2="-1.575" width="0.0508" layer="39"/>
<wire x1="-2.215" y1="-1.575" x2="-2.215" y2="1.575" width="0.0508" layer="39"/>
</package>
<package name="1812">
<wire x1="-2.286" y1="1.524" x2="2.286" y2="1.524" width="0.127" layer="51"/>
<wire x1="2.286" y1="1.524" x2="2.286" y2="-1.524" width="0.127" layer="51"/>
<wire x1="2.286" y1="-1.524" x2="-2.286" y2="-1.524" width="0.127" layer="51"/>
<wire x1="-2.286" y1="-1.524" x2="-2.286" y2="1.524" width="0.127" layer="51"/>
<smd name="1" x="-2.3876" y="0" dx="1.6764" dy="2.8956" layer="1"/>
<smd name="2" x="2.3876" y="0" dx="1.6764" dy="2.8956" layer="1"/>
<text x="0" y="1.778" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.778" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
<wire x1="-2.215" y1="1.575" x2="2.215" y2="1.575" width="0.0508" layer="39"/>
<wire x1="2.215" y1="1.575" x2="2.215" y2="-1.575" width="0.0508" layer="39"/>
<wire x1="2.215" y1="-1.575" x2="-2.215" y2="-1.575" width="0.0508" layer="39"/>
<wire x1="-2.215" y1="-1.575" x2="-2.215" y2="1.575" width="0.0508" layer="39"/>
</package>
</packages>
<symbols>
<symbol name="PPTC">
<description>A polymeric positive temperature coefficient device (PPTC, commonly known as a resettable fuse, polyfuse or polyswitch) is a passive electronic component used to protect against overcurrent faults in electronic circuits. - Wikipedia</description>
<wire x1="5.08" y1="1.27" x2="5.08" y2="-1.27" width="0.1524" layer="94"/>
<wire x1="5.08" y1="-1.27" x2="-2.54" y2="-1.27" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-1.27" x2="-2.54" y2="1.27" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="1.27" x2="5.08" y2="1.27" width="0.1524" layer="94"/>
<wire x1="-1.524" y1="-2.54" x2="3.81" y2="2.54" width="0.1524" layer="94"/>
<wire x1="3.81" y1="2.54" x2="5.08" y2="2.54" width="0.1524" layer="94"/>
<text x="1.905" y="3.175" size="1.778" layer="95" font="vector" align="bottom-center">&gt;NAME</text>
<text x="1.27" y="-2.794" size="1.778" layer="96" font="vector" align="top-center">&gt;VALUE</text>
<pin name="1" x="-5.08" y="0" visible="off" length="short"/>
<pin name="2" x="7.62" y="0" visible="off" length="short" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="PPTC" prefix="F">
<description>&lt;h3&gt;Resettable Fuse PPTC&lt;/h3&gt;
&lt;p&gt;Resettable Fuse. Really a sort of resistor with a &lt;b&gt;p&lt;/b&gt;olymeric &lt;b&gt;p&lt;/b&gt;ositive &lt;b&gt;t&lt;/b&gt;emperature &lt;b&gt;c&lt;/b&gt;oefficient whose resistance increases dramatically with an increase in temperature. When heated by the power passing through the resistance rises causing the current to be limited, protecting the circuit. This is achieved by the transition of the polymer from a crystalline to an amorphous state where the conductive carbon separates breaking the conductive pathways found in the cool crystalline structure. When a PPTC cools back down it resumes conducting letting the circuit turn back on.&lt;/p&gt;
&lt;p&gt;SparkFun Products:
&lt;ul&gt;&lt;li&gt;&lt;a href="https://www.sparkfun.com/products/12757"&gt;SparkFun RedBoard - Programmed with Arduino&lt;/a&gt;&lt;/li&gt;
&lt;li&gt;&lt;a href="https://www.sparkfun.com/products/12640"&gt;Pro Micro - 5V/16MHz&lt;/a&gt;&lt;/li&gt;
&lt;li&gt;&lt;a href="https://www.sparkfun.com/products/10915"&gt;Arduino Pro 328 - 5V/16MHz&lt;/a&gt;&lt;/li&gt;
&lt;li&gt;&lt;a href="https://www.sparkfun.com/products/13720"&gt;MP3 Trigger&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;</description>
<gates>
<gate name="F1" symbol="PPTC" x="0" y="0"/>
</gates>
<devices>
<device name="_PTH" package="PTH">
<connects>
<connect gate="F1" pin="1" pad="P$1"/>
<connect gate="F1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-08490"/>
<attribute name="VALUE" value="72V/0.25A"/>
</technology>
</technologies>
</device>
<device name="_6V500MA-2" package="1206">
<connects>
<connect gate="F1" pin="1" pad="1"/>
<connect gate="F1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-08585"/>
<attribute name="VALUE" value="6V/0.5A"/>
</technology>
</technologies>
</device>
<device name="_0.75A" package="1206">
<connects>
<connect gate="F1" pin="1" pad="1"/>
<connect gate="F1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-11150"/>
<attribute name="VALUE" value="6V/0.75A"/>
</technology>
</technologies>
</device>
<device name="_6V500MA" package="0805">
<connects>
<connect gate="F1" pin="1" pad="1"/>
<connect gate="F1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-13945"/>
<attribute name="VALUE" value="6V 0.5A"/>
</technology>
</technologies>
</device>
<device name="_6V2A" package="1210">
<connects>
<connect gate="F1" pin="1" pad="1"/>
<connect gate="F1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-14313" constant="no"/>
<attribute name="VALUE" value="6V/2A" constant="no"/>
</technology>
</technologies>
</device>
<device name="_16V_2.5A" package="1812">
<connects>
<connect gate="F1" pin="1" pad="1"/>
<connect gate="F1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="RES-14390" constant="no"/>
<attribute name="VALUE" value="16V/2.5A(5A TRIP)" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="SparkFun-DiscreteSemi">
<description>&lt;h3&gt;SparkFun Discrete Semiconductors&lt;/h3&gt;
This library contains diodes, optoisolators, TRIACs, MOSFETs, transistors, etc. 
&lt;br&gt;
&lt;br&gt;
We've spent an enormous amount of time creating and checking these footprints and parts, but it is &lt;b&gt; the end user's responsibility&lt;/b&gt; to ensure correctness and suitablity for a given componet or application. 
&lt;br&gt;
&lt;br&gt;If you enjoy using this library, please buy one of our products at &lt;a href=" www.sparkfun.com"&gt;SparkFun.com&lt;/a&gt;.
&lt;br&gt;
&lt;br&gt;
&lt;b&gt;Licensing:&lt;/b&gt; Creative Commons ShareAlike 4.0 International - https://creativecommons.org/licenses/by-sa/4.0/ 
&lt;br&gt;
&lt;br&gt;
You are welcome to use this library for commercial purposes. For attribution, we ask that when you begin to sell your device using our footprint, you email us with a link to the product being sold. We want bragging rights that we helped (in a very small part) to create your 8th world wonder. We would like the opportunity to feature your device on our homepage.</description>
<packages>
<package name="SOD-323">
<description>SOD-323 (Small Outline Diode)</description>
<wire x1="-1.77" y1="0.625" x2="-1.77" y2="-0.625" width="0.2032" layer="21"/>
<smd name="C" x="-1.15" y="0" dx="0.63" dy="0.83" layer="1"/>
<smd name="A" x="1.15" y="0" dx="0.63" dy="0.83" layer="1"/>
<text x="0" y="0.762" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-0.762" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
<wire x1="-0.9" y1="0.625" x2="0.9" y2="0.625" width="0.2032" layer="21"/>
<wire x1="-0.9" y1="-0.625" x2="0.9" y2="-0.625" width="0.2032" layer="21"/>
<wire x1="-1.651" y1="0.762" x2="1.651" y2="0.762" width="0.127" layer="39"/>
<wire x1="1.651" y1="0.762" x2="1.651" y2="-0.762" width="0.127" layer="39"/>
<wire x1="1.651" y1="-0.762" x2="-1.651" y2="-0.762" width="0.127" layer="39"/>
<wire x1="-1.651" y1="-0.762" x2="-1.651" y2="0.762" width="0.127" layer="39"/>
</package>
<package name="PANASONIC_SMINI2-F5-B">
<description>From http://www.semicon.panasonic.co.jp/ds4/DZ2J150_E.pdf</description>
<wire x1="-1.897" y1="0.625" x2="-1.897" y2="-0.625" width="0.2032" layer="21"/>
<smd name="C" x="-1.2" y="0" dx="0.9" dy="1.1" layer="1"/>
<smd name="A" x="1.2" y="0" dx="0.9" dy="0.9" layer="1"/>
<text x="0" y="0.762" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-0.762" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
<wire x1="-0.85" y1="0.625" x2="0.85" y2="0.625" width="0.127" layer="21"/>
<wire x1="-0.85" y1="-0.625" x2="0.85" y2="-0.625" width="0.127" layer="21"/>
</package>
<package name="SOT23-3">
<description>&lt;h3&gt;SOT23-3X&lt;/h3&gt;

&lt;ul&gt;
&lt;li&gt;Total Size: 3mm x 2.5mm&lt;/li&gt;
&lt;li&gt;Landing Pad Size: .8mm x .9mm&lt;/li&gt;
&lt;li&gt;Pitch: 2 (vertical) .95mm (horizontal)&lt;/li&gt;
&lt;li&gt;&lt;/li&gt;
&lt;li&gt;&lt;/li&gt;
&lt;li&gt;&lt;/li&gt;
&lt;/ul&gt;</description>
<wire x1="1.4224" y1="0.6604" x2="1.4224" y2="-0.6604" width="0.1524" layer="51"/>
<wire x1="1.4224" y1="-0.6604" x2="-1.4224" y2="-0.6604" width="0.1524" layer="51"/>
<wire x1="-1.4224" y1="-0.6604" x2="-1.4224" y2="0.6604" width="0.1524" layer="51"/>
<wire x1="-1.4224" y1="0.6604" x2="1.4224" y2="0.6604" width="0.1524" layer="51"/>
<wire x1="-0.8" y1="0.7" x2="-1.4" y2="0.7" width="0.2032" layer="21"/>
<wire x1="-1.4" y1="0.7" x2="-1.4" y2="-0.1" width="0.2032" layer="21"/>
<wire x1="0.8" y1="0.7" x2="1.4" y2="0.7" width="0.2032" layer="21"/>
<wire x1="1.4" y1="0.7" x2="1.4" y2="-0.1" width="0.2032" layer="21"/>
<smd name="1" x="-0.95" y="-1" dx="0.8" dy="0.9" layer="1"/>
<smd name="2" x="0.95" y="-1" dx="0.8" dy="0.9" layer="1"/>
<smd name="3" x="0" y="1.1" dx="0.8" dy="0.9" layer="1"/>
<text x="-1.651" y="0" size="0.6096" layer="25" font="vector" ratio="20" rot="R90" align="bottom-center">&gt;NAME</text>
<text x="1.651" y="0" size="0.6096" layer="27" font="vector" ratio="20" rot="R90" align="top-center">&gt;VALUE</text>
</package>
</packages>
<symbols>
<symbol name="DIODE-ZENER">
<description>&lt;h3&gt;Zener Diode&lt;/h3&gt;
Allows current flow in one direction, but allows reverse flow when above breakdown voltage.</description>
<wire x1="1.27" y1="0.889" x2="1.27" y2="0" width="0.1524" layer="94"/>
<wire x1="1.27" y1="0" x2="1.27" y2="-0.889" width="0.1524" layer="94"/>
<wire x1="1.27" y1="0.889" x2="1.778" y2="1.397" width="0.1524" layer="94"/>
<wire x1="1.27" y1="-0.889" x2="0.762" y2="-1.397" width="0.1524" layer="94"/>
<text x="-2.54" y="2.032" size="1.778" layer="95" font="vector">&gt;NAME</text>
<text x="-2.54" y="-2.032" size="1.778" layer="96" font="vector" align="top-left">&gt;VALUE</text>
<pin name="A" x="-2.54" y="0" visible="off" length="point" direction="pas"/>
<pin name="C" x="2.54" y="0" visible="off" length="point" direction="pas" rot="R180"/>
<wire x1="-2.54" y1="0" x2="-1.27" y2="0" width="0.1524" layer="94"/>
<wire x1="2.54" y1="0" x2="1.27" y2="0" width="0.1524" layer="94"/>
<polygon width="0.254" layer="94">
<vertex x="-1.27" y="1.27"/>
<vertex x="1.27" y="0"/>
<vertex x="-1.27" y="-1.27"/>
</polygon>
</symbol>
</symbols>
<devicesets>
<deviceset name="DIODE-ZENER" prefix="D">
<description>&lt;h3&gt;Zener Diode&lt;/h3&gt;
&lt;p&gt;A Zener diode allows current to flow from its anode to its cathode like a normal semiconductor diode, but it also permits current to flow in the reverse direction when its "Zener voltage" is reached. - WIkipedia&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="DIODE-ZENER" x="0" y="0"/>
</gates>
<devices>
<device name="-MM3Z3V3T1G" package="SOD-323">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="DIO-11284"/>
<attribute name="VALUE" value="3.3V"/>
</technology>
</technologies>
</device>
<device name="-MMSZ5232BS" package="SOD-323">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="DIO-12442"/>
<attribute name="VALUE" value="5.6V"/>
</technology>
</technologies>
</device>
<device name="-DZ2J150M0L" package="PANASONIC_SMINI2-F5-B">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="DIO-12989"/>
<attribute name="VALUE" value="15V"/>
</technology>
</technologies>
</device>
<device name="-BZT52C3V6S" package="SOD-323">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="DIO-08199" constant="no"/>
<attribute name="VALUE" value="3.6V" constant="no"/>
</technology>
</technologies>
</device>
<device name="-MMBZ5233BLT1G" package="SOT23-3">
<connects>
<connect gate="G$1" pin="A" pad="1"/>
<connect gate="G$1" pin="C" pad="3"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="DIO-14123"/>
<attribute name="VALUE" value="6V"/>
</technology>
</technologies>
</device>
<device name="-BZX84C15LT3G" package="SOT23-3">
<connects>
<connect gate="G$1" pin="A" pad="1"/>
<connect gate="G$1" pin="C" pad="3"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="DIO-15071" constant="no"/>
<attribute name="VALUE" value="15V" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
</libraries>
<attributes>
</attributes>
<variantdefs>
</variantdefs>
<classes>
<class number="0" name="default" width="0" drill="0">
</class>
</classes>
<parts>
<part name="IC1" library="SamacSys_Parts" deviceset="STM32F427VIT6" device=""/>
<part name="GND1" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="GND2" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="GND3" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="GND5" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="C3" library="SparkFun-Capacitors" deviceset="9.0PF" device="-0603-50V-10%" value="8.0pF"/>
<part name="C4" library="SparkFun-Capacitors" deviceset="9.0PF" device="-0603-50V-10%" value="8.0pF"/>
<part name="GND6" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="GND7" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="GND4" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="C5" library="SparkFun-Capacitors" deviceset="0.1UF" device="-0402-6.3V-10%-X7R" value="0.1uF"/>
<part name="GND8" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="IC2" library="SamacSys_Parts" deviceset="MCP131T-300E_TT" device=""/>
<part name="GND9" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="C6" library="SparkFun-Capacitors" deviceset="0.1UF" device="-0402-6.3V-10%-X7R" value="0.1uF"/>
<part name="R1" library="SamacSys_Parts" deviceset="CRMA1206AF10K0FKEF" device=""/>
<part name="R2" library="SamacSys_Parts" deviceset="CRMA1206AF10K0FKEF" device=""/>
<part name="C1" library="SparkFun-Capacitors" deviceset="2.2UF" device="-1206-50V-10%" value="2.2uF"/>
<part name="C7" library="SparkFun-Capacitors" deviceset="2.2UF" device="-1206-50V-10%" value="2.2uF"/>
<part name="C2" library="SparkFun-Capacitors" deviceset="0.1UF" device="-0603-100V-10%-X7R-WE" value="0.1uF"/>
<part name="C8" library="SparkFun-Capacitors" deviceset="0.1UF" device="-0603-100V-10%-X7R-WE" value="0.1uF"/>
<part name="C9" library="SparkFun-Capacitors" deviceset="0.1UF" device="-0603-100V-10%-X7R-WE" value="0.1uF"/>
<part name="C10" library="SparkFun-Capacitors" deviceset="0.1UF" device="-0603-100V-10%-X7R-WE" value="0.1uF"/>
<part name="C11" library="SparkFun-Capacitors" deviceset="0.1UF" device="-0603-100V-10%-X7R-WE" value="0.1uF"/>
<part name="C12" library="SparkFun-Capacitors" deviceset="2.2UF" device="-1206-50V-10%" value="2.2uF"/>
<part name="C13" library="SparkFun-Capacitors" deviceset="2.2UF" device="-1206-50V-10%" value="2.2uF"/>
<part name="GND10" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="U2" library="SparkFun-IC-Power" deviceset="V_REG_LP5907" device="SOT23-3.0V" value="3.3V"/>
<part name="C14" library="SparkFun-Capacitors" deviceset="2.2UF" device="-1206-50V-10%" value="2.2uF"/>
<part name="GND11" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="R3" library="SparkFun-Resistors" deviceset="220OHM" device="-0603-1/10W-1%" value="220"/>
<part name="C15" library="SparkFun-Capacitors" deviceset="10UF" device="-1206-6.3V-20%" value="10uF"/>
<part name="R4" library="SparkFun-Resistors" deviceset="1KOHM" device="-0603-1/10W-1%" value="1k"/>
<part name="C16" library="SamacSys_Parts" deviceset="4TPE220MBB" device=""/>
<part name="IC4" library="SamacSys_Parts" deviceset="ICM-20948" device=""/>
<part name="C17" library="SparkFun-Capacitors" deviceset="2.2UF" device="-1206-50V-10%" value="2.2uF"/>
<part name="C18" library="SparkFun-Capacitors" deviceset="0.1UF" device="-0603-100V-10%-X7R-WE" value="0.1uF"/>
<part name="GND12" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="GND13" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="C19" library="SparkFun-Capacitors" deviceset="0.1UF" device="-0603-100V-10%-X7R-WE" value="0.1uF"/>
<part name="C20" library="SparkFun-Capacitors" deviceset="2.2UF" device="-1206-50V-10%" value="2.2uF"/>
<part name="C21" library="SparkFun-Capacitors" deviceset="0.1UF" device="-0603-100V-10%-X7R-WE" value="0.1uF"/>
<part name="GND14" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="C22" library="SparkFun-Capacitors" deviceset="2.2UF" device="-1206-50V-10%" value="2.2uF"/>
<part name="C23" library="SparkFun-Capacitors" deviceset="0.1UF" device="-0603-100V-10%-X7R-WE" value="0.1uF"/>
<part name="GND15" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="C24" library="SparkFun-Capacitors" deviceset="470NF" device="-0603-10V-10%-X5R" value="470nF"/>
<part name="GND16" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="IC6" library="SamacSys_Parts" deviceset="MS561101BA03-50" device=""/>
<part name="C25" library="SparkFun-Capacitors" deviceset="0.1UF" device="-0603-100V-10%-X7R-WE" value="0.1uF"/>
<part name="GND17" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="U1" library="SparkFun-IC-Power" deviceset="V_REG_LP5907" device="SOT23-3.0V" value="3.0V"/>
<part name="GND18" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="GND19" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="C27" library="SparkFun-Capacitors" deviceset="2.2UF" device="-1206-50V-10%" value="2.2uF"/>
<part name="C28" library="SparkFun-Capacitors" deviceset="0.1UF" device="-0603-100V-10%-X7R-WE" value="0.1uF"/>
<part name="C29" library="SparkFun-Capacitors" deviceset="10UF" device="-1206-6.3V-20%" value="10uF"/>
<part name="R5" library="SparkFun-Resistors" deviceset="220OHM" device="-0603-1/10W-1%" value="220"/>
<part name="IC7" library="SamacSys_Parts" deviceset="NCP163ASN180T1G" device=""/>
<part name="C31" library="SparkFun-Capacitors" deviceset="0.1UF" device="-0603-100V-10%-X7R-WE" value="0.1uF"/>
<part name="C30" library="SparkFun-Capacitors" deviceset="0.1UF" device="-0603-100V-10%-X7R-WE" value="0.1uF"/>
<part name="GND20" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="Y1" library="SamacSys_Parts" deviceset="FA-20H_24.0000MF20X-K3" device=""/>
<part name="J2" library="SamacSys_Parts" deviceset="47346-0001" device=""/>
<part name="GND21" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="R6" library="SparkFun-Resistors" deviceset="22OHM" device="-0603-1/10W-1%" value="22Ω"/>
<part name="R7" library="SparkFun-Resistors" deviceset="22OHM" device="-0603-1/10W-1%" value="22Ω"/>
<part name="C32" library="SparkFun-Capacitors" deviceset="0.1UF" device="-0603-100V-10%-X7R-WE" value="0.1uF"/>
<part name="GND22" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="J3" library="SamacSys_Parts" deviceset="SM06B-GHS-TB_LF__SN_" device=""/>
<part name="GND23" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="R8" library="SparkFun-Resistors" deviceset="1KOHM" device="-0603-1/10W-1%" value="1k"/>
<part name="R9" library="SparkFun-Resistors" deviceset="1KOHM" device="-0603-1/10W-1%" value="1k"/>
<part name="R10" library="SparkFun-Resistors" deviceset="1MOHM" device="-0603-1/4W-5%" value="1M"/>
<part name="R11" library="SparkFun-Resistors" deviceset="1MOHM" device="-0603-1/4W-5%" value="1M"/>
<part name="C33" library="SparkFun-Capacitors" deviceset="10NF" device="-0603-50V-10%" value="10nF"/>
<part name="C34" library="SparkFun-Capacitors" deviceset="10NF" device="-0603-50V-10%" value="10nF"/>
<part name="GND24" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="GND25" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="R12" library="SamacSys_Parts" deviceset="CRMA1206AF10K0FKEF" device=""/>
<part name="R13" library="SamacSys_Parts" deviceset="CRMA1206AF10K0FKEF" device=""/>
<part name="GND26" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="J4" library="SamacSys_Parts" deviceset="PJS008-2120-0" device=""/>
<part name="GND27" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="R14" library="SparkFun-Resistors" deviceset="100KOHM" device="-0603-1/10W-1%" value="100k"/>
<part name="R15" library="SparkFun-Resistors" deviceset="100KOHM" device="-0603-1/10W-1%" value="100k"/>
<part name="R16" library="SparkFun-Resistors" deviceset="100KOHM" device="-0603-1/10W-1%" value="100k"/>
<part name="R17" library="SparkFun-Resistors" deviceset="100KOHM" device="-0603-1/10W-1%" value="100k"/>
<part name="R18" library="SparkFun-Resistors" deviceset="100KOHM" device="-0603-1/10W-1%" value="100k"/>
<part name="GND28" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="C35" library="SparkFun-Capacitors" deviceset="0.1UF" device="-0603-100V-10%-X7R-WE" value="0.1uF"/>
<part name="GND29" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="IC8" library="SamacSys_Parts" deviceset="TJA1051TK_3,118" device=""/>
<part name="J5" library="SamacSys_Parts" deviceset="SM04B-GHS-TB_LF__SN_" device=""/>
<part name="GND30" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="C36" library="SparkFun-Capacitors" deviceset="2.2UF" device="-1206-50V-10%" value="2.2uF"/>
<part name="GND31" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="GND32" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="GND33" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="R19" library="SparkFun-Resistors" deviceset="120OHM" device=""/>
<part name="J6" library="SamacSys_Parts" deviceset="SM05B-GHS-TB_LF__SN_" device=""/>
<part name="R20" library="SparkFun-Resistors" deviceset="220OHM" device="-0603-1/10W-1%" value="220"/>
<part name="GND34" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="R21" library="SamacSys_Parts" deviceset="CRMA1206AF10K0FKEF" device=""/>
<part name="IC9" library="SamacSys_Parts" deviceset="74LVC1G86SE-7" device=""/>
<part name="GND35" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="IC10" library="SamacSys_Parts" deviceset="74LVC2G86DC,125" device=""/>
<part name="R22" library="SparkFun-Resistors" deviceset="1KOHM" device="-0603-1/10W-1%" value="1k"/>
<part name="R23" library="SparkFun-Resistors" deviceset="1KOHM" device="-0603-1/10W-1%" value="1k"/>
<part name="GND36" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="J7" library="SamacSys_Parts" deviceset="SM06B-GHS-TB_LF__SN_" device=""/>
<part name="C37" library="SparkFun-Capacitors" deviceset="2.2UF" device="-1206-50V-10%" value="2.2uF"/>
<part name="GND37" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="R24" library="SparkFun-Resistors" deviceset="220OHM" device="-0603-1/10W-1%" value="220"/>
<part name="R25" library="SparkFun-Resistors" deviceset="220OHM" device="-0603-1/10W-1%" value="220"/>
<part name="R26" library="SparkFun-Resistors" deviceset="220OHM" device="-0603-1/10W-1%" value="220"/>
<part name="R27" library="SparkFun-Resistors" deviceset="220OHM" device="-0603-1/10W-1%" value="220"/>
<part name="GND38" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="J8" library="SamacSys_Parts" deviceset="SM06B-GHS-TB_LF__SN_" device=""/>
<part name="C38" library="SparkFun-Capacitors" deviceset="2.2UF" device="-1206-50V-10%" value="2.2uF"/>
<part name="GND39" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="R28" library="SparkFun-Resistors" deviceset="220OHM" device="-0603-1/10W-1%" value="220"/>
<part name="R29" library="SparkFun-Resistors" deviceset="220OHM" device="-0603-1/10W-1%" value="220"/>
<part name="R30" library="SparkFun-Resistors" deviceset="220OHM" device="-0603-1/10W-1%" value="220"/>
<part name="R31" library="SparkFun-Resistors" deviceset="220OHM" device="-0603-1/10W-1%" value="220"/>
<part name="GND40" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="J9" library="SamacSys_Parts" deviceset="SM06B-GHS-TB_LF__SN_" device=""/>
<part name="GND41" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="GND42" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="R32" library="SparkFun-Resistors" deviceset="1.5KOHM" device="-0603-1/10W-1%" value="1.5k"/>
<part name="R33" library="SparkFun-Resistors" deviceset="1.5KOHM" device="-0603-1/10W-1%" value="1.5k"/>
<part name="J1" library="SamacSys_Parts" deviceset="SM06B-SRSS-TB__LF__SN_" device=""/>
<part name="J10" library="SparkFun-Connectors" deviceset="CONN_06" device="NO_SILK_NO_POP"/>
<part name="J11" library="SparkFun-Connectors" deviceset="CONN_06" device="NO_SILK_NO_POP"/>
<part name="J12" library="SparkFun-Connectors" deviceset="CONN_06" device="NO_SILK_NO_POP"/>
<part name="GND43" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="R34" library="SparkFun-Resistors" deviceset="220OHM" device="-0603-1/10W-1%" value="220"/>
<part name="R35" library="SparkFun-Resistors" deviceset="220OHM" device="-0603-1/10W-1%" value="220"/>
<part name="R36" library="SparkFun-Resistors" deviceset="220OHM" device="-0603-1/10W-1%" value="220"/>
<part name="R37" library="SparkFun-Resistors" deviceset="220OHM" device="-0603-1/10W-1%" value="220"/>
<part name="R38" library="SparkFun-Resistors" deviceset="220OHM" device="-0603-1/10W-1%" value="220"/>
<part name="R39" library="SparkFun-Resistors" deviceset="220OHM" device="-0603-1/10W-1%" value="220"/>
<part name="J13" library="SamacSys_Parts" deviceset="SM05B-GHS-TB_LF__SN_" device=""/>
<part name="R40" library="SparkFun-Resistors" deviceset="1.5KOHM" device="-0603-1/10W-1%" value="1.5k"/>
<part name="GND44" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="R41" library="SparkFun-Resistors" deviceset="68OHM" device="-0603-1/10W-1%"/>
<part name="J14" library="SamacSys_Parts" deviceset="SM04B-GHS-TB_LF__SN_" device=""/>
<part name="C40" library="SparkFun-Capacitors" deviceset="2.2UF" device="-1206-50V-10%" value="2.2uF"/>
<part name="GND45" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="GND46" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="JP1" library="pinhead" library_urn="urn:adsk.eagle:library:325" deviceset="PINHD-2X5" device="" package3d_urn="urn:adsk.eagle:package:22470/2"/>
<part name="GND47" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="R42" library="SamacSys_Parts" deviceset="CRMA1206AF10K0FKEF" device=""/>
<part name="R43" library="SparkFun-Resistors" deviceset="470OHM" device="-0603-1/10W-1%" value="470"/>
<part name="GND48" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="D2" library="SamacSys_Parts" deviceset="PMEG2020CPASX" device=""/>
<part name="F1" library="SparkFun-Fuses" deviceset="PPTC" device="_6V500MA-2" value="2A RST FUSE"/>
<part name="C41" library="SparkFun-Capacitors" deviceset="100UF-POLAR" device="-1206-6.3V-20%(TANT)" value="100uF"/>
<part name="GND49" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="R44" library="SparkFun-Resistors" deviceset="220OHM" device="-0603-1/10W-1%" value="220"/>
<part name="R45" library="SparkFun-Resistors" deviceset="220OHM" device="-0603-1/10W-1%" value="220"/>
<part name="D3" library="SparkFun-DiscreteSemi" deviceset="DIODE-ZENER" device="-MMBZ5233BLT1G" value="5.6V"/>
<part name="GND50" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="LED1" library="SamacSys_Parts" deviceset="APG1608ZGCK" device=""/>
<part name="R46" library="SparkFun-Resistors" deviceset="220OHM" device="-0603-1/10W-1%" value="220"/>
<part name="GND51" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="C42" library="SparkFun-Capacitors" deviceset="100UF-POLAR" device="-1206-6.3V-20%(TANT)" value="100uF"/>
<part name="D4" library="SamacSys_Parts" deviceset="PMEG1030EJ,115" device=""/>
<part name="F2" library="SparkFun-Fuses" deviceset="PPTC" device="_6V500MA" value="0.3A RST FUSE"/>
<part name="F3" library="SamacSys_Parts" deviceset="0603L100SLYR" device=""/>
<part name="R47" library="SparkFun-Resistors" deviceset="10OHM" device="-0603-1/10W-5%" value="10"/>
<part name="R48" library="SamacSys_Parts" deviceset="CRMA1206AF10K0FKEF" device=""/>
<part name="R49" library="SamacSys_Parts" deviceset="CRMA1206AF10K0FKEF" device=""/>
<part name="D5" library="SamacSys_Parts" deviceset="1N4448X-TP" device=""/>
<part name="LED2" library="SamacSys_Parts" deviceset="LTST-C19HE1WT" device=""/>
<part name="R50" library="SparkFun-Resistors" deviceset="100OHM" device="-0603-1/10W-1%" value="100"/>
<part name="R51" library="SparkFun-Resistors" deviceset="100OHM" device="-0603-1/10W-1%" value="100"/>
<part name="R52" library="SparkFun-Resistors" deviceset="100OHM" device="-0603-1/10W-1%" value="100"/>
<part name="IC11" library="SamacSys_Parts" deviceset="AP7365-33WG-7" device=""/>
<part name="R53" library="SamacSys_Parts" deviceset="CRMA1206AF10K0FKEF" device=""/>
<part name="C43" library="SparkFun-Capacitors" deviceset="10UF" device="-1206-6.3V-20%" value="10uF"/>
<part name="C44" library="SparkFun-Capacitors" deviceset="10UF-POLAR" device="-0603-6.3V-20%(TANT)" value="10uF"/>
<part name="C45" library="SparkFun-Capacitors" deviceset="0.1UF" device="-0603-100V-10%-X7R-WE" value="0.1uF"/>
<part name="GND52" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="D1" library="SamacSys_Parts" deviceset="CDBU70" device=""/>
<part name="C39" library="SamacSys_Parts" deviceset="W2H13C1048AT1F" device=""/>
<part name="C26" library="SamacSys_Parts" deviceset="W2H13C1048AT1F" device=""/>
<part name="Q1" library="SamacSys_Parts" deviceset="XP151A12A2MR-G" device=""/>
<part name="Q2" library="SamacSys_Parts" deviceset="BSS209PW_H6327" device=""/>
<part name="IC5" library="SamacSys_Parts" deviceset="ICM-20602" device=""/>
<part name="IC3" library="SamacSys_Parts" deviceset="FM25V02A-GTR" device=""/>
<part name="GND53" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
</parts>
<sheets>
<sheet>
<plain>
</plain>
<instances>
<instance part="IC1" gate="G$1" x="25.4" y="66.04" smashed="yes">
<attribute name="NAME" x="97.79" y="83.82" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="97.79" y="81.28" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="GND1" gate="1" x="60.96" y="-78.74" smashed="yes">
<attribute name="VALUE" x="58.42" y="-81.28" size="1.778" layer="96"/>
</instance>
<instance part="GND2" gate="1" x="91.44" y="-68.58" smashed="yes">
<attribute name="VALUE" x="88.9" y="-71.12" size="1.778" layer="96"/>
</instance>
<instance part="GND3" gate="1" x="157.48" y="60.96" smashed="yes" rot="R90">
<attribute name="VALUE" x="160.02" y="58.42" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="GND5" gate="1" x="81.28" y="134.62" smashed="yes" rot="R90">
<attribute name="VALUE" x="83.82" y="132.08" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="C3" gate="G$1" x="-40.64" y="12.7" smashed="yes" rot="R270">
<attribute name="NAME" x="-37.719" y="11.176" size="1.778" layer="95" font="vector" rot="R270"/>
<attribute name="VALUE" x="-42.799" y="11.176" size="1.778" layer="96" font="vector" rot="R270"/>
</instance>
<instance part="C4" gate="G$1" x="-33.02" y="71.12" smashed="yes" rot="R90">
<attribute name="NAME" x="-35.941" y="72.644" size="1.778" layer="95" font="vector" rot="R90"/>
<attribute name="VALUE" x="-30.861" y="72.644" size="1.778" layer="96" font="vector" rot="R90"/>
</instance>
<instance part="GND6" gate="1" x="-45.72" y="22.86" smashed="yes" rot="R270">
<attribute name="VALUE" x="-48.26" y="22.86" size="1.778" layer="96" rot="R270"/>
</instance>
<instance part="GND7" gate="1" x="-27.94" y="63.5" smashed="yes" rot="R90">
<attribute name="VALUE" x="-25.4" y="60.96" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="GND4" gate="1" x="200.66" y="96.52" smashed="yes">
<attribute name="VALUE" x="198.12" y="93.98" size="1.778" layer="96"/>
</instance>
<instance part="C5" gate="G$1" x="198.12" y="109.22" smashed="yes" rot="R180">
<attribute name="NAME" x="196.596" y="106.299" size="1.778" layer="95" font="vector" rot="R180"/>
<attribute name="VALUE" x="196.596" y="111.379" size="1.778" layer="96" font="vector" rot="R180"/>
</instance>
<instance part="GND8" gate="1" x="208.28" y="66.04" smashed="yes" rot="R270">
<attribute name="VALUE" x="205.74" y="68.58" size="1.778" layer="96" rot="R270"/>
</instance>
<instance part="IC2" gate="G$1" x="205.74" y="43.18" smashed="yes">
<attribute name="NAME" x="229.87" y="50.8" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="229.87" y="48.26" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="GND9" gate="1" x="226.06" y="25.4" smashed="yes">
<attribute name="VALUE" x="223.52" y="22.86" size="1.778" layer="96"/>
</instance>
<instance part="C6" gate="G$1" x="198.12" y="35.56" smashed="yes" rot="R180">
<attribute name="NAME" x="196.596" y="32.639" size="1.778" layer="95" font="vector" rot="R180"/>
<attribute name="VALUE" x="196.596" y="37.719" size="1.778" layer="96" font="vector" rot="R180"/>
</instance>
<instance part="R1" gate="G$1" x="48.26" y="134.62" smashed="yes">
<attribute name="NAME" x="52.07" y="140.97" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="52.07" y="138.43" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="R2" gate="G$1" x="60.96" y="-68.58" smashed="yes" rot="R90">
<attribute name="NAME" x="64.77" y="-54.61" size="1.778" layer="95" rot="R270" align="center-left"/>
<attribute name="VALUE" x="67.31" y="-54.61" size="1.778" layer="96" rot="R270" align="center-left"/>
</instance>
<instance part="C1" gate="G$1" x="144.78" y="60.96" smashed="yes" rot="R90">
<attribute name="NAME" x="141.859" y="62.484" size="1.778" layer="95" font="vector" rot="R90"/>
<attribute name="VALUE" x="146.939" y="62.484" size="1.778" layer="96" font="vector" rot="R90"/>
</instance>
<instance part="C7" gate="G$1" x="91.44" y="-55.88" smashed="yes">
<attribute name="NAME" x="92.964" y="-52.959" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="92.964" y="-58.039" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="C2" gate="G$1" x="-10.16" y="-48.26" smashed="yes" rot="R90">
<attribute name="NAME" x="-13.081" y="-46.736" size="1.778" layer="95" font="vector" rot="R90"/>
<attribute name="VALUE" x="-8.001" y="-46.736" size="1.778" layer="96" font="vector" rot="R90"/>
</instance>
<instance part="C8" gate="G$1" x="-10.16" y="-55.88" smashed="yes" rot="R90">
<attribute name="NAME" x="-13.081" y="-54.356" size="1.778" layer="95" font="vector" rot="R90"/>
<attribute name="VALUE" x="-8.001" y="-54.356" size="1.778" layer="96" font="vector" rot="R90"/>
</instance>
<instance part="C9" gate="G$1" x="-10.16" y="-63.5" smashed="yes" rot="R90">
<attribute name="NAME" x="-13.081" y="-61.976" size="1.778" layer="95" font="vector" rot="R90"/>
<attribute name="VALUE" x="-8.001" y="-61.976" size="1.778" layer="96" font="vector" rot="R90"/>
</instance>
<instance part="C10" gate="G$1" x="-10.16" y="-71.12" smashed="yes" rot="R90">
<attribute name="NAME" x="-13.081" y="-69.596" size="1.778" layer="95" font="vector" rot="R90"/>
<attribute name="VALUE" x="-8.001" y="-69.596" size="1.778" layer="96" font="vector" rot="R90"/>
</instance>
<instance part="C11" gate="G$1" x="-10.16" y="-78.74" smashed="yes" rot="R90">
<attribute name="NAME" x="-13.081" y="-77.216" size="1.778" layer="95" font="vector" rot="R90"/>
<attribute name="VALUE" x="-8.001" y="-77.216" size="1.778" layer="96" font="vector" rot="R90"/>
</instance>
<instance part="C12" gate="G$1" x="-10.16" y="-88.9" smashed="yes" rot="R90">
<attribute name="NAME" x="-13.081" y="-87.376" size="1.778" layer="95" font="vector" rot="R90"/>
<attribute name="VALUE" x="-8.001" y="-87.376" size="1.778" layer="96" font="vector" rot="R90"/>
</instance>
<instance part="C13" gate="G$1" x="-10.16" y="-101.6" smashed="yes" rot="R90">
<attribute name="NAME" x="-13.081" y="-100.076" size="1.778" layer="95" font="vector" rot="R90"/>
<attribute name="VALUE" x="-8.001" y="-100.076" size="1.778" layer="96" font="vector" rot="R90"/>
</instance>
<instance part="GND10" gate="1" x="-17.78" y="-111.76" smashed="yes">
<attribute name="VALUE" x="-20.32" y="-114.3" size="1.778" layer="96"/>
</instance>
<instance part="U2" gate="G$1" x="210.82" y="-2.54" smashed="yes">
<attribute name="NAME" x="203.2" y="5.334" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="203.2" y="-10.414" size="1.778" layer="96" font="vector" align="top-left"/>
</instance>
<instance part="C14" gate="G$1" x="190.5" y="-7.62" smashed="yes">
<attribute name="NAME" x="192.024" y="-4.699" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="192.024" y="-9.779" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="GND11" gate="1" x="198.12" y="-17.78" smashed="yes">
<attribute name="VALUE" x="195.58" y="-20.32" size="1.778" layer="96"/>
</instance>
<instance part="R3" gate="G$1" x="226.06" y="-7.62" smashed="yes" rot="R90">
<attribute name="NAME" x="224.536" y="-7.62" size="1.778" layer="95" font="vector" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="227.584" y="-7.62" size="1.778" layer="96" font="vector" rot="R90" align="top-center"/>
</instance>
<instance part="C15" gate="G$1" x="233.68" y="-7.62" smashed="yes">
<attribute name="NAME" x="235.204" y="-4.699" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="235.204" y="-9.779" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="R4" gate="G$1" x="243.84" y="-30.48" smashed="yes" rot="R180">
<attribute name="NAME" x="243.84" y="-32.004" size="1.778" layer="95" font="vector" rot="R180" align="bottom-center"/>
<attribute name="VALUE" x="243.84" y="-28.956" size="1.778" layer="96" font="vector" rot="R180" align="top-center"/>
</instance>
<instance part="C16" gate="G$1" x="195.58" y="-33.02" smashed="yes" rot="R270">
<attribute name="NAME" x="201.93" y="-41.91" size="1.778" layer="95" rot="R270" align="center-left"/>
<attribute name="VALUE" x="199.39" y="-41.91" size="1.778" layer="96" rot="R270" align="center-left"/>
</instance>
<instance part="Y1" gate="G$1" x="-38.1" y="22.86" smashed="yes" rot="R90">
<attribute name="NAME" x="-45.72" y="59.69" size="1.778" layer="95" rot="R90" align="center-left"/>
<attribute name="VALUE" x="-43.18" y="59.69" size="1.778" layer="96" rot="R90" align="center-left"/>
</instance>
<instance part="J1" gate="G$1" x="220.98" y="78.74" smashed="yes">
<attribute name="NAME" x="237.49" y="86.36" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="237.49" y="83.82" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="D1" gate="G$1" x="203.2" y="-30.48" smashed="yes">
<attribute name="NAME" x="215.9" y="-21.59" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="215.9" y="-24.13" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="IC3" gate="G$1" x="203.2" y="119.38" smashed="yes">
<attribute name="NAME" x="227.33" y="127" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="227.33" y="124.46" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="GND53" gate="1" x="195.58" y="-48.26" smashed="yes">
<attribute name="VALUE" x="193.04" y="-50.8" size="1.778" layer="96"/>
</instance>
</instances>
<busses>
</busses>
<nets>
<net name="BATT_VOLT_SENS" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PA2"/>
<wire x1="25.4" y1="5.08" x2="12.7" y2="5.08" width="0.1524" layer="91"/>
<label x="-7.62" y="5.08" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_USART4_RX" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PA1"/>
<wire x1="25.4" y1="7.62" x2="12.7" y2="7.62" width="0.1524" layer="91"/>
<label x="-5.08" y="7.62" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_USART4_TX" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PA0"/>
<wire x1="25.4" y1="10.16" x2="12.7" y2="10.16" width="0.1524" layer="91"/>
<label x="-5.08" y="10.16" size="1.778" layer="95"/>
</segment>
</net>
<net name="LED_SAFETY" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PC3"/>
<wire x1="25.4" y1="22.86" x2="12.7" y2="22.86" width="0.1524" layer="91"/>
<label x="0" y="22.86" size="1.778" layer="95"/>
</segment>
</net>
<net name="MPU9250_CS" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PC2"/>
<wire x1="25.4" y1="25.4" x2="12.7" y2="25.4" width="0.1524" layer="91"/>
<label x="0" y="25.4" size="1.778" layer="95"/>
</segment>
</net>
<net name="RSSI_IN" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PC1"/>
<wire x1="25.4" y1="27.94" x2="12.7" y2="27.94" width="0.1524" layer="91"/>
<label x="5.08" y="27.94" size="1.778" layer="95"/>
</segment>
</net>
<net name="VBUS_VALID" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PC0"/>
<wire x1="25.4" y1="30.48" x2="12.7" y2="30.48" width="0.1524" layer="91"/>
<label x="0" y="30.48" size="1.778" layer="95"/>
</segment>
</net>
<net name="NRST" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="NRST"/>
<wire x1="25.4" y1="33.02" x2="12.7" y2="33.02" width="0.1524" layer="91"/>
<label x="7.62" y="33.02" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="IC2" gate="G$1" pin="~RST"/>
<wire x1="205.74" y1="43.18" x2="187.96" y2="43.18" width="0.1524" layer="91"/>
<label x="182.88" y="43.18" size="1.778" layer="95"/>
</segment>
</net>
<net name="20608_CS" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PC15"/>
<wire x1="25.4" y1="45.72" x2="12.7" y2="45.72" width="0.1524" layer="91"/>
<label x="2.54" y="45.72" size="1.778" layer="95"/>
</segment>
</net>
<net name="20608_DRDY" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PC14"/>
<wire x1="25.4" y1="48.26" x2="12.7" y2="48.26" width="0.1524" layer="91"/>
<label x="0" y="48.26" size="1.778" layer="95"/>
</segment>
</net>
<net name="SBUS_INV" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PC13"/>
<wire x1="25.4" y1="50.8" x2="12.7" y2="50.8" width="0.1524" layer="91"/>
<label x="2.54" y="50.8" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_VBAT" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="VBAT"/>
<wire x1="25.4" y1="53.34" x2="12.7" y2="53.34" width="0.1524" layer="91"/>
<label x="2.54" y="53.34" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="205.74" y1="-30.48" x2="195.58" y2="-30.48" width="0.1524" layer="91"/>
<pinref part="C16" gate="G$1" pin="+"/>
<wire x1="195.58" y1="-30.48" x2="185.42" y2="-30.48" width="0.1524" layer="91"/>
<wire x1="195.58" y1="-33.02" x2="195.58" y2="-30.48" width="0.1524" layer="91"/>
<junction x="195.58" y="-30.48"/>
<label x="180.34" y="-30.48" size="1.778" layer="95"/>
<pinref part="D1" gate="G$1" pin="K"/>
</segment>
</net>
<net name="8266_RST" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PE6"/>
<wire x1="25.4" y1="55.88" x2="12.7" y2="55.88" width="0.1524" layer="91"/>
<label x="2.54" y="55.88" size="1.778" layer="95"/>
</segment>
</net>
<net name="8266_PD" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PE5"/>
<wire x1="25.4" y1="58.42" x2="12.7" y2="58.42" width="0.1524" layer="91"/>
<label x="2.54" y="58.42" size="1.778" layer="95"/>
</segment>
</net>
<net name="SPEKTRUM_POWER" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PE4"/>
<wire x1="25.4" y1="60.96" x2="12.7" y2="60.96" width="0.1524" layer="91"/>
<label x="-10.16" y="60.96" size="1.778" layer="95"/>
</segment>
</net>
<net name="VDD_3V3_SENSORS_EN" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PE3"/>
<wire x1="25.4" y1="63.5" x2="12.7" y2="63.5" width="0.1524" layer="91"/>
<label x="-15.24" y="63.5" size="1.778" layer="95"/>
</segment>
</net>
<net name="8266_GPIO0" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PE2"/>
<wire x1="25.4" y1="66.04" x2="12.7" y2="66.04" width="0.1524" layer="91"/>
<label x="0" y="66.04" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_USART8_TX" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PE1"/>
<wire x1="38.1" y1="83.82" x2="38.1" y2="99.06" width="0.1524" layer="91"/>
<label x="38.1" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="FMU_USART8_RX" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PE0"/>
<wire x1="40.64" y1="83.82" x2="40.64" y2="99.06" width="0.1524" layer="91"/>
<label x="40.64" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="FMU_I2C1_SDA" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PB9"/>
<wire x1="43.18" y1="83.82" x2="43.18" y2="99.06" width="0.1524" layer="91"/>
<label x="43.18" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="FMU_I2C1_SCL" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PB8"/>
<wire x1="45.72" y1="83.82" x2="45.72" y2="99.06" width="0.1524" layer="91"/>
<label x="45.72" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="BOOT0" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="BOOT0"/>
<wire x1="48.26" y1="83.82" x2="48.26" y2="134.62" width="0.1524" layer="91"/>
<label x="48.26" y="149.86" size="1.778" layer="95" rot="R90"/>
<pinref part="R1" gate="G$1" pin="1"/>
<wire x1="48.26" y1="134.62" x2="48.26" y2="149.86" width="0.1524" layer="91"/>
</segment>
</net>
<net name="FMU_USART_RX" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PB7"/>
<wire x1="50.8" y1="83.82" x2="50.8" y2="99.06" width="0.1524" layer="91"/>
<label x="50.8" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="FMU_USART1_TX" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PB6"/>
<wire x1="53.34" y1="83.82" x2="53.34" y2="99.06" width="0.1524" layer="91"/>
<label x="53.34" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="VDD_BRICK_VALID" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PB5"/>
<wire x1="55.88" y1="83.82" x2="55.88" y2="99.06" width="0.1524" layer="91"/>
<label x="55.88" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="8266_GPIO2" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PB4"/>
<wire x1="58.42" y1="83.82" x2="58.42" y2="99.06" width="0.1524" layer="91"/>
<label x="58.42" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="FMU_LED_BLUE" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PB3"/>
<wire x1="60.96" y1="83.82" x2="60.96" y2="99.06" width="0.1524" layer="91"/>
<label x="60.96" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="BARO_CS" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PD7"/>
<wire x1="63.5" y1="83.82" x2="63.5" y2="99.06" width="0.1524" layer="91"/>
<label x="63.5" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="FMU_USART2_RX" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PD6"/>
<wire x1="66.04" y1="83.82" x2="66.04" y2="99.06" width="0.1524" layer="91"/>
<label x="66.04" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="FMU_USART2_TX" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PD5"/>
<wire x1="68.58" y1="83.82" x2="68.58" y2="99.06" width="0.1524" layer="91"/>
<label x="68.58" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="FMU_USART2_RTS" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PD4"/>
<wire x1="71.12" y1="83.82" x2="71.12" y2="99.06" width="0.1524" layer="91"/>
<label x="71.12" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="FMU_USART2_CTS" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PD3"/>
<wire x1="73.66" y1="83.82" x2="73.66" y2="99.06" width="0.1524" layer="91"/>
<label x="73.66" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="SDIO_CMD" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PD2"/>
<wire x1="76.2" y1="83.82" x2="76.2" y2="99.06" width="0.1524" layer="91"/>
<label x="76.2" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="CAN1_TX" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PD1"/>
<wire x1="78.74" y1="83.82" x2="78.74" y2="99.06" width="0.1524" layer="91"/>
<label x="78.74" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="CAN1_RX" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PD0"/>
<wire x1="81.28" y1="83.82" x2="81.28" y2="99.06" width="0.1524" layer="91"/>
<label x="81.28" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="SDIO_CK" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PC12"/>
<wire x1="83.82" y1="83.82" x2="83.82" y2="99.06" width="0.1524" layer="91"/>
<label x="83.82" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="SDIO_D3" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PC11"/>
<wire x1="86.36" y1="83.82" x2="86.36" y2="99.06" width="0.1524" layer="91"/>
<label x="86.36" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="SDIO_D2" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PC10"/>
<wire x1="88.9" y1="83.82" x2="88.9" y2="99.06" width="0.1524" layer="91"/>
<label x="88.9" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="ALARM" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PA15"/>
<wire x1="91.44" y1="83.82" x2="91.44" y2="99.06" width="0.1524" layer="91"/>
<label x="91.44" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="FMU_SWCLK" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PA14"/>
<wire x1="93.98" y1="83.82" x2="93.98" y2="99.06" width="0.1524" layer="91"/>
<label x="93.98" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="223.52" y1="68.58" x2="193.04" y2="68.58" width="0.1524" layer="91"/>
<label x="193.04" y="68.58" size="1.778" layer="95"/>
<wire x1="223.52" y1="68.58" x2="226.06" y2="66.04" width="0.1524" layer="91"/>
<wire x1="226.06" y1="66.04" x2="233.68" y2="66.04" width="0.1524" layer="91"/>
<wire x1="233.68" y1="66.04" x2="236.22" y2="68.58" width="0.1524" layer="91"/>
<wire x1="236.22" y1="68.58" x2="243.84" y2="68.58" width="0.1524" layer="91"/>
<wire x1="243.84" y1="68.58" x2="243.84" y2="76.2" width="0.1524" layer="91"/>
<pinref part="J1" gate="G$1" pin="5"/>
<wire x1="243.84" y1="76.2" x2="241.3" y2="76.2" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$53" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="VCAP_2"/>
<wire x1="101.6" y1="60.96" x2="139.7" y2="60.96" width="0.1524" layer="91"/>
<pinref part="C1" gate="G$1" pin="1"/>
</segment>
</net>
<net name="FMU_SWDIO" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PA13"/>
<wire x1="101.6" y1="58.42" x2="114.3" y2="58.42" width="0.1524" layer="91"/>
<label x="114.3" y="58.42" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="223.52" y1="71.12" x2="193.04" y2="71.12" width="0.1524" layer="91"/>
<label x="193.04" y="71.12" size="1.778" layer="95"/>
<wire x1="223.52" y1="71.12" x2="226.06" y2="68.58" width="0.1524" layer="91"/>
<wire x1="226.06" y1="68.58" x2="231.14" y2="68.58" width="0.1524" layer="91"/>
<wire x1="231.14" y1="68.58" x2="231.14" y2="83.82" width="0.1524" layer="91"/>
<wire x1="231.14" y1="83.82" x2="243.84" y2="83.82" width="0.1524" layer="91"/>
<wire x1="243.84" y1="83.82" x2="243.84" y2="78.74" width="0.1524" layer="91"/>
<pinref part="J1" gate="G$1" pin="4"/>
<wire x1="243.84" y1="78.74" x2="241.3" y2="78.74" width="0.1524" layer="91"/>
</segment>
</net>
<net name="OTG_FM_DP" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PA12"/>
<wire x1="101.6" y1="55.88" x2="114.3" y2="55.88" width="0.1524" layer="91"/>
<label x="114.3" y="55.88" size="1.778" layer="95"/>
</segment>
</net>
<net name="OTG_FS_DM" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PA11"/>
<wire x1="101.6" y1="53.34" x2="114.3" y2="53.34" width="0.1524" layer="91"/>
<label x="114.3" y="53.34" size="1.778" layer="95"/>
</segment>
</net>
<net name="FRSKY_INV" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PA10"/>
<wire x1="101.6" y1="50.8" x2="114.3" y2="50.8" width="0.1524" layer="91"/>
<label x="114.3" y="50.8" size="1.778" layer="95"/>
</segment>
</net>
<net name="VBUS" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PA9"/>
<wire x1="101.6" y1="48.26" x2="114.3" y2="48.26" width="0.1524" layer="91"/>
<label x="114.3" y="48.26" size="1.778" layer="95"/>
</segment>
</net>
<net name="8266_RTS" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PA8"/>
<wire x1="101.6" y1="45.72" x2="114.3" y2="45.72" width="0.1524" layer="91"/>
<label x="114.3" y="45.72" size="1.778" layer="95"/>
</segment>
</net>
<net name="SDIO_D1" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PC9"/>
<wire x1="101.6" y1="43.18" x2="114.3" y2="43.18" width="0.1524" layer="91"/>
<label x="114.3" y="43.18" size="1.778" layer="95"/>
</segment>
</net>
<net name="SDIO_D0" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PC8"/>
<wire x1="101.6" y1="40.64" x2="114.3" y2="40.64" width="0.1524" layer="91"/>
<label x="114.3" y="40.64" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_RC_INPUT" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PC7"/>
<wire x1="101.6" y1="38.1" x2="114.3" y2="38.1" width="0.1524" layer="91"/>
<label x="114.3" y="38.1" size="1.778" layer="95"/>
</segment>
</net>
<net name="MPU9250_DRDY" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PD15"/>
<wire x1="101.6" y1="33.02" x2="114.3" y2="33.02" width="0.1524" layer="91"/>
<label x="114.3" y="33.02" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_CH6" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PD14"/>
<wire x1="101.6" y1="30.48" x2="114.3" y2="30.48" width="0.1524" layer="91"/>
<label x="114.3" y="30.48" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_CH5" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PD13"/>
<wire x1="101.6" y1="27.94" x2="114.3" y2="27.94" width="0.1524" layer="91"/>
<label x="114.3" y="27.94" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_USART3_RTS" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PD12"/>
<wire x1="101.6" y1="25.4" x2="114.3" y2="25.4" width="0.1524" layer="91"/>
<label x="114.3" y="25.4" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_USART3_CTS" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PD11"/>
<wire x1="101.6" y1="22.86" x2="114.3" y2="22.86" width="0.1524" layer="91"/>
<label x="114.3" y="22.86" size="1.778" layer="95"/>
</segment>
</net>
<net name="FRAM_CS" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PD10"/>
<wire x1="101.6" y1="20.32" x2="114.3" y2="20.32" width="0.1524" layer="91"/>
<label x="114.3" y="20.32" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="203.2" y1="119.38" x2="185.42" y2="119.38" width="0.1524" layer="91"/>
<label x="180.34" y="119.38" size="1.778" layer="95"/>
<pinref part="IC3" gate="G$1" pin="!CS"/>
</segment>
</net>
<net name="FMU_USART3_RX" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PD9"/>
<wire x1="101.6" y1="17.78" x2="114.3" y2="17.78" width="0.1524" layer="91"/>
<label x="114.3" y="17.78" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_USART3_TX" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PD8"/>
<wire x1="101.6" y1="15.24" x2="114.3" y2="15.24" width="0.1524" layer="91"/>
<label x="114.3" y="15.24" size="1.778" layer="95"/>
</segment>
</net>
<net name="FRAM_MOSI" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PB15"/>
<wire x1="101.6" y1="12.7" x2="114.3" y2="12.7" width="0.1524" layer="91"/>
<label x="114.3" y="12.7" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="231.14" y1="114.3" x2="241.3" y2="114.3" width="0.1524" layer="91"/>
<label x="241.3" y="114.3" size="1.778" layer="95"/>
<pinref part="IC3" gate="G$1" pin="SCK"/>
</segment>
</net>
<net name="FRAM_MISO" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PB14"/>
<wire x1="101.6" y1="10.16" x2="114.3" y2="10.16" width="0.1524" layer="91"/>
<label x="114.3" y="10.16" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="203.2" y1="116.84" x2="185.42" y2="116.84" width="0.1524" layer="91"/>
<label x="180.34" y="116.84" size="1.778" layer="95"/>
<pinref part="IC3" gate="G$1" pin="SO"/>
</segment>
</net>
<net name="CAN2_TX" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PB13"/>
<wire x1="101.6" y1="7.62" x2="114.3" y2="7.62" width="0.1524" layer="91"/>
<label x="114.3" y="7.62" size="1.778" layer="95"/>
</segment>
</net>
<net name="CAN2_RX" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PB12"/>
<wire x1="101.6" y1="5.08" x2="114.3" y2="5.08" width="0.1524" layer="91"/>
<label x="114.3" y="5.08" size="1.778" layer="95"/>
</segment>
</net>
<net name="BATT_CURRENT_SENS" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PA3"/>
<wire x1="33.02" y1="-12.7" x2="33.02" y2="-22.86" width="0.1524" layer="91"/>
<label x="33.02" y="-40.64" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="GND" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="VSS_2"/>
<wire x1="35.56" y1="-12.7" x2="35.56" y2="-22.86" width="0.1524" layer="91"/>
<label x="35.56" y="-27.94" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<pinref part="GND1" gate="1" pin="GND"/>
<wire x1="60.96" y1="-76.2" x2="60.96" y2="-68.58" width="0.1524" layer="91"/>
<pinref part="R2" gate="G$1" pin="1"/>
</segment>
<segment>
<wire x1="91.44" y1="-58.42" x2="91.44" y2="-66.04" width="0.1524" layer="91"/>
<pinref part="GND2" gate="1" pin="GND"/>
<pinref part="C7" gate="G$1" pin="2"/>
</segment>
<segment>
<wire x1="147.32" y1="60.96" x2="154.94" y2="60.96" width="0.1524" layer="91"/>
<pinref part="GND3" gate="1" pin="GND"/>
<pinref part="C1" gate="G$1" pin="2"/>
</segment>
<segment>
<pinref part="IC1" gate="G$1" pin="VSS_3"/>
<wire x1="101.6" y1="63.5" x2="114.3" y2="63.5" width="0.1524" layer="91"/>
<label x="114.3" y="63.5" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="GND5" gate="1" pin="GND"/>
<pinref part="R1" gate="G$1" pin="2"/>
<wire x1="66.04" y1="134.62" x2="78.74" y2="134.62" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC1" gate="G$1" pin="VSS_4"/>
<wire x1="35.56" y1="83.82" x2="35.56" y2="99.06" width="0.1524" layer="91"/>
<label x="35.56" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<pinref part="IC1" gate="G$1" pin="VSS_1"/>
<wire x1="25.4" y1="43.18" x2="12.7" y2="43.18" width="0.1524" layer="91"/>
<label x="7.62" y="43.18" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="IC1" gate="G$1" pin="VSSA"/>
<wire x1="25.4" y1="17.78" x2="12.7" y2="17.78" width="0.1524" layer="91"/>
<label x="7.62" y="17.78" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C3" gate="G$1" pin="2"/>
<wire x1="-43.18" y1="22.86" x2="-43.18" y2="12.7" width="0.1524" layer="91"/>
<pinref part="GND6" gate="1" pin="GND"/>
<pinref part="Y1" gate="G$1" pin="GND_2"/>
<wire x1="-38.1" y1="22.86" x2="-43.18" y2="22.86" width="0.1524" layer="91"/>
<junction x="-43.18" y="22.86"/>
</segment>
<segment>
<pinref part="C4" gate="G$1" pin="2"/>
<pinref part="GND7" gate="1" pin="GND"/>
<wire x1="-30.48" y1="63.5" x2="-30.48" y2="71.12" width="0.1524" layer="91"/>
<pinref part="Y1" gate="G$1" pin="GND_1"/>
<wire x1="-35.56" y1="63.5" x2="-30.48" y2="63.5" width="0.1524" layer="91"/>
<junction x="-30.48" y="63.5"/>
</segment>
<segment>
<wire x1="203.2" y1="111.76" x2="203.2" y2="101.6" width="0.1524" layer="91"/>
<wire x1="203.2" y1="101.6" x2="200.66" y2="101.6" width="0.1524" layer="91"/>
<wire x1="200.66" y1="101.6" x2="198.12" y2="101.6" width="0.1524" layer="91"/>
<junction x="200.66" y="101.6"/>
<wire x1="200.66" y1="101.6" x2="200.66" y2="99.06" width="0.1524" layer="91"/>
<pinref part="GND4" gate="1" pin="GND"/>
<pinref part="C5" gate="G$1" pin="1"/>
<wire x1="198.12" y1="104.14" x2="198.12" y2="101.6" width="0.1524" layer="91"/>
<pinref part="IC3" gate="G$1" pin="VSS"/>
</segment>
<segment>
<pinref part="GND8" gate="1" pin="GND"/>
<wire x1="223.52" y1="66.04" x2="210.82" y2="66.04" width="0.1524" layer="91"/>
<wire x1="223.52" y1="66.04" x2="226.06" y2="63.5" width="0.1524" layer="91"/>
<wire x1="226.06" y1="63.5" x2="241.3" y2="63.5" width="0.1524" layer="91"/>
<pinref part="J1" gate="G$1" pin="6"/>
<wire x1="241.3" y1="63.5" x2="241.3" y2="73.66" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC2" gate="G$1" pin="VSS"/>
<wire x1="233.68" y1="43.18" x2="236.22" y2="43.18" width="0.1524" layer="91"/>
<wire x1="236.22" y1="43.18" x2="236.22" y2="27.94" width="0.1524" layer="91"/>
<pinref part="GND9" gate="1" pin="GND"/>
<wire x1="236.22" y1="27.94" x2="226.06" y2="27.94" width="0.1524" layer="91"/>
<wire x1="198.12" y1="27.94" x2="226.06" y2="27.94" width="0.1524" layer="91"/>
<junction x="226.06" y="27.94"/>
<wire x1="198.12" y1="30.48" x2="198.12" y2="27.94" width="0.1524" layer="91"/>
<pinref part="C6" gate="G$1" pin="1"/>
</segment>
<segment>
<pinref part="C2" gate="G$1" pin="1"/>
<wire x1="-15.24" y1="-48.26" x2="-17.78" y2="-48.26" width="0.1524" layer="91"/>
<wire x1="-17.78" y1="-48.26" x2="-17.78" y2="-55.88" width="0.1524" layer="91"/>
<pinref part="C13" gate="G$1" pin="1"/>
<wire x1="-17.78" y1="-55.88" x2="-17.78" y2="-63.5" width="0.1524" layer="91"/>
<wire x1="-17.78" y1="-63.5" x2="-17.78" y2="-71.12" width="0.1524" layer="91"/>
<wire x1="-17.78" y1="-71.12" x2="-17.78" y2="-78.74" width="0.1524" layer="91"/>
<wire x1="-17.78" y1="-78.74" x2="-17.78" y2="-88.9" width="0.1524" layer="91"/>
<wire x1="-17.78" y1="-88.9" x2="-17.78" y2="-101.6" width="0.1524" layer="91"/>
<wire x1="-17.78" y1="-101.6" x2="-17.78" y2="-109.22" width="0.1524" layer="91"/>
<wire x1="-15.24" y1="-101.6" x2="-17.78" y2="-101.6" width="0.1524" layer="91"/>
<junction x="-17.78" y="-101.6"/>
<pinref part="C12" gate="G$1" pin="1"/>
<wire x1="-15.24" y1="-88.9" x2="-17.78" y2="-88.9" width="0.1524" layer="91"/>
<junction x="-17.78" y="-88.9"/>
<pinref part="C11" gate="G$1" pin="1"/>
<wire x1="-15.24" y1="-78.74" x2="-17.78" y2="-78.74" width="0.1524" layer="91"/>
<junction x="-17.78" y="-78.74"/>
<pinref part="C10" gate="G$1" pin="1"/>
<wire x1="-15.24" y1="-71.12" x2="-17.78" y2="-71.12" width="0.1524" layer="91"/>
<junction x="-17.78" y="-71.12"/>
<pinref part="C9" gate="G$1" pin="1"/>
<wire x1="-15.24" y1="-63.5" x2="-17.78" y2="-63.5" width="0.1524" layer="91"/>
<junction x="-17.78" y="-63.5"/>
<pinref part="C8" gate="G$1" pin="1"/>
<wire x1="-15.24" y1="-55.88" x2="-17.78" y2="-55.88" width="0.1524" layer="91"/>
<junction x="-17.78" y="-55.88"/>
<pinref part="GND10" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="U2" gate="G$1" pin="GND"/>
<wire x1="200.66" y1="-7.62" x2="198.12" y2="-7.62" width="0.1524" layer="91"/>
<wire x1="198.12" y1="-7.62" x2="198.12" y2="-15.24" width="0.1524" layer="91"/>
<wire x1="198.12" y1="-15.24" x2="190.5" y2="-15.24" width="0.1524" layer="91"/>
<pinref part="C14" gate="G$1" pin="2"/>
<wire x1="190.5" y1="-15.24" x2="190.5" y2="-10.16" width="0.1524" layer="91"/>
<pinref part="GND11" gate="1" pin="GND"/>
<junction x="198.12" y="-15.24"/>
<pinref part="R3" gate="G$1" pin="1"/>
<wire x1="226.06" y1="-12.7" x2="226.06" y2="-15.24" width="0.1524" layer="91"/>
<wire x1="226.06" y1="-15.24" x2="198.12" y2="-15.24" width="0.1524" layer="91"/>
<pinref part="C15" gate="G$1" pin="2"/>
<wire x1="233.68" y1="-10.16" x2="233.68" y2="-15.24" width="0.1524" layer="91"/>
<wire x1="233.68" y1="-15.24" x2="226.06" y2="-15.24" width="0.1524" layer="91"/>
<junction x="226.06" y="-15.24"/>
</segment>
<segment>
<pinref part="GND53" gate="1" pin="GND"/>
<pinref part="C16" gate="G$1" pin="-"/>
</segment>
</net>
<net name="FMU_VDD_3V3" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="VDD_3"/>
<wire x1="38.1" y1="-12.7" x2="38.1" y2="-22.86" width="0.1524" layer="91"/>
<label x="38.1" y="-40.64" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<pinref part="IC1" gate="G$1" pin="VDD_4"/>
<wire x1="93.98" y1="-12.7" x2="93.98" y2="-22.86" width="0.1524" layer="91"/>
<label x="93.98" y="-40.64" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<pinref part="IC1" gate="G$1" pin="VDD_5"/>
<wire x1="101.6" y1="66.04" x2="114.3" y2="66.04" width="0.1524" layer="91"/>
<label x="114.3" y="66.04" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="IC1" gate="G$1" pin="VDD_6"/>
<wire x1="33.02" y1="83.82" x2="33.02" y2="99.06" width="0.1524" layer="91"/>
<label x="33.02" y="99.06" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<pinref part="IC1" gate="G$1" pin="VDD_1"/>
<wire x1="25.4" y1="40.64" x2="12.7" y2="40.64" width="0.1524" layer="91"/>
<label x="-5.08" y="40.64" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="IC1" gate="G$1" pin="VDD_2"/>
<wire x1="25.4" y1="20.32" x2="12.7" y2="20.32" width="0.1524" layer="91"/>
<label x="-5.08" y="20.32" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="IC1" gate="G$1" pin="VREF+"/>
<wire x1="25.4" y1="15.24" x2="12.7" y2="15.24" width="0.1524" layer="91"/>
<label x="-5.08" y="15.24" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="IC1" gate="G$1" pin="VDDA"/>
<wire x1="25.4" y1="12.7" x2="12.7" y2="12.7" width="0.1524" layer="91"/>
<label x="-5.08" y="12.7" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="220.98" y1="78.74" x2="193.04" y2="78.74" width="0.1524" layer="91"/>
<label x="193.04" y="78.74" size="1.778" layer="95"/>
<pinref part="J1" gate="G$1" pin="1"/>
</segment>
<segment>
<pinref part="IC2" gate="G$1" pin="VDD"/>
<wire x1="205.74" y1="40.64" x2="198.12" y2="40.64" width="0.1524" layer="91"/>
<wire x1="198.12" y1="40.64" x2="198.12" y2="38.1" width="0.1524" layer="91"/>
<pinref part="C6" gate="G$1" pin="2"/>
<wire x1="198.12" y1="40.64" x2="187.96" y2="40.64" width="0.1524" layer="91"/>
<junction x="198.12" y="40.64"/>
<label x="182.88" y="40.64" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C2" gate="G$1" pin="2"/>
<wire x1="-7.62" y1="-48.26" x2="-5.08" y2="-48.26" width="0.1524" layer="91"/>
<wire x1="-5.08" y1="-48.26" x2="-5.08" y2="-55.88" width="0.1524" layer="91"/>
<pinref part="C13" gate="G$1" pin="2"/>
<wire x1="-5.08" y1="-55.88" x2="-5.08" y2="-63.5" width="0.1524" layer="91"/>
<wire x1="-5.08" y1="-63.5" x2="-5.08" y2="-71.12" width="0.1524" layer="91"/>
<wire x1="-5.08" y1="-71.12" x2="-5.08" y2="-78.74" width="0.1524" layer="91"/>
<wire x1="-5.08" y1="-78.74" x2="-5.08" y2="-88.9" width="0.1524" layer="91"/>
<wire x1="-5.08" y1="-88.9" x2="-5.08" y2="-101.6" width="0.1524" layer="91"/>
<wire x1="-5.08" y1="-101.6" x2="-7.62" y2="-101.6" width="0.1524" layer="91"/>
<pinref part="C8" gate="G$1" pin="2"/>
<wire x1="-7.62" y1="-55.88" x2="-5.08" y2="-55.88" width="0.1524" layer="91"/>
<junction x="-5.08" y="-55.88"/>
<pinref part="C9" gate="G$1" pin="2"/>
<wire x1="-7.62" y1="-63.5" x2="-5.08" y2="-63.5" width="0.1524" layer="91"/>
<junction x="-5.08" y="-63.5"/>
<pinref part="C10" gate="G$1" pin="2"/>
<wire x1="-7.62" y1="-71.12" x2="-5.08" y2="-71.12" width="0.1524" layer="91"/>
<junction x="-5.08" y="-71.12"/>
<pinref part="C11" gate="G$1" pin="2"/>
<wire x1="-7.62" y1="-78.74" x2="-5.08" y2="-78.74" width="0.1524" layer="91"/>
<junction x="-5.08" y="-78.74"/>
<pinref part="C12" gate="G$1" pin="2"/>
<wire x1="-7.62" y1="-88.9" x2="-5.08" y2="-88.9" width="0.1524" layer="91"/>
<junction x="-5.08" y="-88.9"/>
<wire x1="-5.08" y1="-48.26" x2="-5.08" y2="-35.56" width="0.1524" layer="91"/>
<junction x="-5.08" y="-48.26"/>
<label x="-2.54" y="-50.8" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<pinref part="C5" gate="G$1" pin="2"/>
<wire x1="198.12" y1="114.3" x2="203.2" y2="114.3" width="0.1524" layer="91"/>
<wire x1="198.12" y1="114.3" x2="198.12" y2="111.76" width="0.1524" layer="91"/>
<wire x1="198.12" y1="114.3" x2="185.42" y2="114.3" width="0.1524" layer="91"/>
<junction x="198.12" y="114.3"/>
<wire x1="185.42" y1="114.3" x2="185.42" y2="91.44" width="0.1524" layer="91"/>
<wire x1="185.42" y1="91.44" x2="236.22" y2="91.44" width="0.1524" layer="91"/>
<wire x1="236.22" y1="91.44" x2="236.22" y2="116.84" width="0.1524" layer="91"/>
<wire x1="236.22" y1="116.84" x2="236.22" y2="119.38" width="0.1524" layer="91"/>
<wire x1="236.22" y1="119.38" x2="231.14" y2="119.38" width="0.1524" layer="91"/>
<wire x1="231.14" y1="116.84" x2="236.22" y2="116.84" width="0.1524" layer="91"/>
<junction x="236.22" y="116.84"/>
<label x="238.76" y="104.14" size="1.778" layer="95"/>
<pinref part="IC3" gate="G$1" pin="!WP"/>
<pinref part="IC3" gate="G$1" pin="VDD"/>
<pinref part="IC3" gate="G$1" pin="!HOLD"/>
</segment>
<segment>
<pinref part="U2" gate="G$1" pin="OUT"/>
<pinref part="C15" gate="G$1" pin="1"/>
<wire x1="218.44" y1="2.54" x2="226.06" y2="2.54" width="0.1524" layer="91"/>
<wire x1="226.06" y1="2.54" x2="233.68" y2="2.54" width="0.1524" layer="91"/>
<wire x1="233.68" y1="2.54" x2="233.68" y2="-2.54" width="0.1524" layer="91"/>
<pinref part="R3" gate="G$1" pin="2"/>
<wire x1="226.06" y1="-2.54" x2="226.06" y2="2.54" width="0.1524" layer="91"/>
<junction x="226.06" y="2.54"/>
<wire x1="233.68" y1="2.54" x2="251.46" y2="2.54" width="0.1524" layer="91"/>
<junction x="233.68" y="2.54"/>
<pinref part="R4" gate="G$1" pin="1"/>
<wire x1="251.46" y1="2.54" x2="251.46" y2="-30.48" width="0.1524" layer="91"/>
<wire x1="251.46" y1="-30.48" x2="248.92" y2="-30.48" width="0.1524" layer="91"/>
<label x="236.22" y="5.08" size="1.778" layer="95"/>
</segment>
</net>
<net name="VDD_5V_SENS" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PA4"/>
<wire x1="40.64" y1="-12.7" x2="40.64" y2="-22.86" width="0.1524" layer="91"/>
<label x="40.64" y="-40.64" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="ICM20948_SCK" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PA5"/>
<wire x1="43.18" y1="-12.7" x2="43.18" y2="-22.86" width="0.1524" layer="91"/>
<label x="43.18" y="-40.64" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="ICM20948_MISO" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PA6"/>
<wire x1="45.72" y1="-12.7" x2="45.72" y2="-22.86" width="0.1524" layer="91"/>
<label x="45.72" y="-40.64" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="ICM20948_MOSI" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PA7"/>
<wire x1="48.26" y1="-12.7" x2="48.26" y2="-22.86" width="0.1524" layer="91"/>
<label x="48.26" y="-40.64" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="SAFETY_SWITCH_IN" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PC4"/>
<wire x1="50.8" y1="-12.7" x2="50.8" y2="-22.86" width="0.1524" layer="91"/>
<label x="50.8" y="-40.64" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="VDD_3V3_PERIPH_EN" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PC5"/>
<wire x1="53.34" y1="-12.7" x2="53.34" y2="-22.86" width="0.1524" layer="91"/>
<label x="53.34" y="-40.64" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="RC_INPUT" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PB0"/>
<wire x1="55.88" y1="-12.7" x2="55.88" y2="-22.86" width="0.1524" layer="91"/>
<label x="55.88" y="-35.56" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="FMU_LED_GREEN" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PB1"/>
<wire x1="58.42" y1="-12.7" x2="58.42" y2="-22.86" width="0.1524" layer="91"/>
<label x="58.42" y="-40.64" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="FMU_UART7_RX" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PE7"/>
<wire x1="63.5" y1="-12.7" x2="63.5" y2="-22.86" width="0.1524" layer="91"/>
<label x="63.5" y="-40.64" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="220.98" y1="73.66" x2="193.04" y2="73.66" width="0.1524" layer="91"/>
<label x="193.04" y="73.66" size="1.778" layer="95"/>
<pinref part="J1" gate="G$1" pin="3"/>
</segment>
</net>
<net name="FMU_UART7_TX" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PE8"/>
<wire x1="66.04" y1="-12.7" x2="66.04" y2="-22.86" width="0.1524" layer="91"/>
<label x="66.04" y="-40.64" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="220.98" y1="76.2" x2="193.04" y2="76.2" width="0.1524" layer="91"/>
<label x="193.04" y="76.2" size="1.778" layer="95"/>
<pinref part="J1" gate="G$1" pin="2"/>
</segment>
</net>
<net name="FMU_CH4" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PE9"/>
<wire x1="68.58" y1="-12.7" x2="68.58" y2="-22.86" width="0.1524" layer="91"/>
<label x="68.58" y="-33.02" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="8266_CTS" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PE10"/>
<wire x1="71.12" y1="-12.7" x2="71.12" y2="-22.86" width="0.1524" layer="91"/>
<label x="71.12" y="-33.02" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="FMU_CH3" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PE11"/>
<wire x1="73.66" y1="-12.7" x2="73.66" y2="-22.86" width="0.1524" layer="91"/>
<label x="73.66" y="-33.02" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="HMC5983_DRDY" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PE12"/>
<wire x1="76.2" y1="-12.7" x2="76.2" y2="-22.86" width="0.1524" layer="91"/>
<label x="76.2" y="-40.64" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="FMU_CH2" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PE13"/>
<wire x1="78.74" y1="-12.7" x2="78.74" y2="-22.86" width="0.1524" layer="91"/>
<label x="78.74" y="-33.02" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="FMU_CH1" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PE14"/>
<wire x1="81.28" y1="-12.7" x2="81.28" y2="-22.86" width="0.1524" layer="91"/>
<label x="81.28" y="-33.02" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="HMC5983_CS" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PE15"/>
<wire x1="83.82" y1="-12.7" x2="83.82" y2="-22.86" width="0.1524" layer="91"/>
<label x="83.82" y="-38.1" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="FRAM_SCK" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PB10"/>
<wire x1="86.36" y1="-12.7" x2="86.36" y2="-22.86" width="0.1524" layer="91"/>
<label x="86.36" y="-35.56" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="231.14" y1="111.76" x2="241.3" y2="111.76" width="0.1524" layer="91"/>
<label x="241.3" y="111.76" size="1.778" layer="95"/>
<pinref part="IC3" gate="G$1" pin="SI"/>
</segment>
</net>
<net name="FMU_LED_RED" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PB11"/>
<wire x1="88.9" y1="-12.7" x2="88.9" y2="-22.86" width="0.1524" layer="91"/>
<label x="88.9" y="-40.64" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="N$99" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="VCAP_1"/>
<wire x1="91.44" y1="-12.7" x2="91.44" y2="-50.8" width="0.1524" layer="91"/>
<pinref part="C7" gate="G$1" pin="1"/>
</segment>
</net>
<net name="BOOT1" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PB2"/>
<wire x1="60.96" y1="-12.7" x2="60.96" y2="-50.8" width="0.1524" layer="91"/>
<label x="60.96" y="-48.26" size="1.778" layer="95" rot="R90"/>
<pinref part="R2" gate="G$1" pin="2"/>
</segment>
</net>
<net name="OSC_IN" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PH0"/>
<wire x1="25.4" y1="38.1" x2="-17.78" y2="38.1" width="0.1524" layer="91"/>
<wire x1="-17.78" y1="38.1" x2="-17.78" y2="81.28" width="0.1524" layer="91"/>
<label x="-25.4" y="81.28" size="1.778" layer="95"/>
<pinref part="C4" gate="G$1" pin="1"/>
<wire x1="-38.1" y1="63.5" x2="-38.1" y2="71.12" width="0.1524" layer="91"/>
<pinref part="Y1" gate="G$1" pin="CRYSTAL_2"/>
<wire x1="-38.1" y1="71.12" x2="-38.1" y2="81.28" width="0.1524" layer="91"/>
<junction x="-38.1" y="71.12"/>
<wire x1="-38.1" y1="81.28" x2="-17.78" y2="81.28" width="0.1524" layer="91"/>
</segment>
</net>
<net name="OSC_OUT" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PH1"/>
<wire x1="25.4" y1="35.56" x2="-17.78" y2="35.56" width="0.1524" layer="91"/>
<pinref part="C3" gate="G$1" pin="1"/>
<wire x1="-35.56" y1="12.7" x2="-17.78" y2="12.7" width="0.1524" layer="91"/>
<wire x1="-17.78" y1="12.7" x2="-17.78" y2="35.56" width="0.1524" layer="91"/>
<label x="-30.48" y="10.16" size="1.778" layer="95"/>
<pinref part="Y1" gate="G$1" pin="CRYSTAL_1"/>
<wire x1="-35.56" y1="22.86" x2="-35.56" y2="12.7" width="0.1524" layer="91"/>
<junction x="-35.56" y="12.7"/>
</segment>
</net>
<net name="VDD_5V_IN" class="0">
<segment>
<pinref part="U2" gate="G$1" pin="IN"/>
<wire x1="200.66" y1="2.54" x2="190.5" y2="2.54" width="0.1524" layer="91"/>
<pinref part="U2" gate="G$1" pin="EN"/>
<wire x1="190.5" y1="2.54" x2="180.34" y2="2.54" width="0.1524" layer="91"/>
<wire x1="200.66" y1="-2.54" x2="190.5" y2="-2.54" width="0.1524" layer="91"/>
<wire x1="190.5" y1="-2.54" x2="190.5" y2="2.54" width="0.1524" layer="91"/>
<junction x="190.5" y="2.54"/>
<pinref part="C14" gate="G$1" pin="1"/>
<junction x="190.5" y="-2.54"/>
<label x="177.8" y="2.54" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$3" class="0">
<segment>
<pinref part="R4" gate="G$1" pin="2"/>
<wire x1="220.98" y1="-30.48" x2="238.76" y2="-30.48" width="0.1524" layer="91"/>
<pinref part="D1" gate="G$1" pin="A"/>
</segment>
</net>
</nets>
</sheet>
<sheet>
<plain>
<text x="-15.24" y="165.1" size="1.778" layer="91">MPU9250 Alternative
Changed to ICM-20948</text>
<text x="76.2" y="86.36" size="1.778" layer="91">Not Suitable For New Design
Meaning it may not be suitable for ICM-20948</text>
<text x="375.92" y="109.22" size="1.778" layer="91">DNP</text>
<text x="241.3" y="38.1" size="1.778" layer="91">Unsure if this 1.8V regulator circuit is sufficient</text>
</plain>
<instances>
<instance part="IC4" gate="G$1" x="10.16" y="152.4" smashed="yes">
<attribute name="NAME" x="36.83" y="175.26" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="36.83" y="172.72" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="C17" gate="G$1" x="55.88" y="134.62" smashed="yes">
<attribute name="NAME" x="57.404" y="137.541" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="57.404" y="132.461" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="C18" gate="G$1" x="66.04" y="134.62" smashed="yes">
<attribute name="NAME" x="67.564" y="137.541" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="67.564" y="132.461" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="GND12" gate="1" x="55.88" y="129.54" smashed="yes">
<attribute name="VALUE" x="53.34" y="127" size="1.778" layer="96"/>
</instance>
<instance part="GND13" gate="1" x="50.8" y="154.94" smashed="yes" rot="R90">
<attribute name="VALUE" x="53.34" y="152.4" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="C19" gate="G$1" x="35.56" y="109.22" smashed="yes">
<attribute name="NAME" x="37.084" y="112.141" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="37.084" y="107.061" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="C20" gate="G$1" x="-2.54" y="99.06" smashed="yes">
<attribute name="NAME" x="-1.016" y="101.981" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="-1.016" y="96.901" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="C21" gate="G$1" x="7.62" y="99.06" smashed="yes">
<attribute name="NAME" x="9.144" y="101.981" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="9.144" y="96.901" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="GND14" gate="1" x="-2.54" y="93.98" smashed="yes">
<attribute name="VALUE" x="-5.08" y="91.44" size="1.778" layer="96"/>
</instance>
<instance part="C22" gate="G$1" x="104.14" y="129.54" smashed="yes">
<attribute name="NAME" x="105.664" y="132.461" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="105.664" y="127.381" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="C23" gate="G$1" x="114.3" y="129.54" smashed="yes">
<attribute name="NAME" x="115.824" y="132.461" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="115.824" y="127.381" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="GND15" gate="1" x="104.14" y="124.46" smashed="yes">
<attribute name="VALUE" x="101.6" y="121.92" size="1.778" layer="96"/>
</instance>
<instance part="C24" gate="G$1" x="160.02" y="137.16" smashed="yes" rot="R90">
<attribute name="NAME" x="157.099" y="138.684" size="1.778" layer="95" font="vector" rot="R90"/>
<attribute name="VALUE" x="162.179" y="138.684" size="1.778" layer="96" font="vector" rot="R90"/>
</instance>
<instance part="GND16" gate="1" x="167.64" y="114.3" smashed="yes" rot="R90">
<attribute name="VALUE" x="170.18" y="111.76" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="IC6" gate="G$1" x="210.82" y="172.72" smashed="yes">
<attribute name="NAME" x="240.03" y="180.34" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="240.03" y="177.8" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="C25" gate="G$1" x="195.58" y="167.64" smashed="yes">
<attribute name="NAME" x="197.104" y="170.561" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="197.104" y="165.481" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="GND17" gate="1" x="205.74" y="162.56" smashed="yes">
<attribute name="VALUE" x="203.2" y="160.02" size="1.778" layer="96"/>
</instance>
<instance part="U1" gate="G$1" x="330.2" y="114.3" smashed="yes">
<attribute name="NAME" x="322.58" y="122.174" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="322.58" y="106.426" size="1.778" layer="96" font="vector" align="top-left"/>
</instance>
<instance part="GND18" gate="1" x="231.14" y="91.44" smashed="yes">
<attribute name="VALUE" x="228.6" y="88.9" size="1.778" layer="96"/>
</instance>
<instance part="GND19" gate="1" x="304.8" y="106.68" smashed="yes">
<attribute name="VALUE" x="302.26" y="104.14" size="1.778" layer="96"/>
</instance>
<instance part="C27" gate="G$1" x="304.8" y="111.76" smashed="yes">
<attribute name="NAME" x="306.324" y="114.681" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="306.324" y="109.601" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="C28" gate="G$1" x="347.98" y="111.76" smashed="yes">
<attribute name="NAME" x="349.504" y="114.681" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="349.504" y="109.601" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="C29" gate="G$1" x="360.68" y="111.76" smashed="yes">
<attribute name="NAME" x="362.204" y="114.681" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="362.204" y="109.601" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="R5" gate="G$1" x="373.38" y="114.3" smashed="yes" rot="R90">
<attribute name="NAME" x="371.856" y="114.3" size="1.778" layer="95" font="vector" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="374.904" y="114.3" size="1.778" layer="96" font="vector" rot="R90" align="top-center"/>
</instance>
<instance part="IC7" gate="G$1" x="246.38" y="63.5" smashed="yes">
<attribute name="NAME" x="267.97" y="71.12" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="267.97" y="68.58" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="C31" gate="G$1" x="281.94" y="50.8" smashed="yes">
<attribute name="NAME" x="283.464" y="53.721" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="283.464" y="48.641" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="C30" gate="G$1" x="223.52" y="50.8" smashed="yes">
<attribute name="NAME" x="225.044" y="53.721" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="225.044" y="48.641" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="GND20" gate="1" x="236.22" y="43.18" smashed="yes">
<attribute name="VALUE" x="233.68" y="40.64" size="1.778" layer="96"/>
</instance>
<instance part="C26" gate="G$1" x="205.74" y="119.38" smashed="yes">
<attribute name="NAME" x="252.73" y="139.7" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="252.73" y="137.16" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="IC5" gate="G$1" x="124.46" y="114.3" smashed="yes">
<attribute name="NAME" x="156.21" y="132.08" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="156.21" y="129.54" size="1.778" layer="96" align="center-left"/>
</instance>
</instances>
<busses>
</busses>
<nets>
<net name="VDD_1V8_SENSORS" class="0">
<segment>
<wire x1="-2.54" y1="111.76" x2="-2.54" y2="104.14" width="0.1524" layer="91"/>
<pinref part="C20" gate="G$1" pin="1"/>
<junction x="-2.54" y="104.14"/>
<pinref part="C21" gate="G$1" pin="1"/>
<wire x1="-2.54" y1="104.14" x2="7.62" y2="104.14" width="0.1524" layer="91"/>
<label x="-5.08" y="111.76" size="1.778" layer="95"/>
<pinref part="IC4" gate="G$1" pin="VDDIO"/>
<wire x1="20.32" y1="116.84" x2="20.32" y2="111.76" width="0.1524" layer="91"/>
<wire x1="20.32" y1="111.76" x2="-2.54" y2="111.76" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC7" gate="G$1" pin="OUT"/>
<wire x1="281.94" y1="60.96" x2="271.78" y2="60.96" width="0.1524" layer="91"/>
<wire x1="281.94" y1="60.96" x2="297.18" y2="60.96" width="0.1524" layer="91"/>
<junction x="281.94" y="60.96"/>
<wire x1="281.94" y1="55.88" x2="281.94" y2="60.96" width="0.1524" layer="91"/>
<pinref part="C31" gate="G$1" pin="1"/>
<label x="289.56" y="60.96" size="1.778" layer="95"/>
</segment>
</net>
<net name="GND" class="0">
<segment>
<pinref part="C17" gate="G$1" pin="2"/>
<pinref part="C18" gate="G$1" pin="2"/>
<wire x1="55.88" y1="132.08" x2="66.04" y2="132.08" width="0.1524" layer="91"/>
<pinref part="GND12" gate="1" pin="GND"/>
<junction x="55.88" y="132.08"/>
</segment>
<segment>
<pinref part="IC4" gate="G$1" pin="RESV_2"/>
<wire x1="30.48" y1="175.26" x2="30.48" y2="177.8" width="0.1524" layer="91"/>
<wire x1="30.48" y1="177.8" x2="43.18" y2="177.8" width="0.1524" layer="91"/>
<wire x1="43.18" y1="177.8" x2="43.18" y2="154.94" width="0.1524" layer="91"/>
<pinref part="IC4" gate="G$1" pin="GND"/>
<wire x1="43.18" y1="154.94" x2="43.18" y2="152.4" width="0.1524" layer="91"/>
<wire x1="43.18" y1="152.4" x2="40.64" y2="152.4" width="0.1524" layer="91"/>
<wire x1="43.18" y1="154.94" x2="48.26" y2="154.94" width="0.1524" layer="91"/>
<junction x="43.18" y="154.94"/>
<pinref part="GND13" gate="1" pin="GND"/>
<pinref part="IC4" gate="G$1" pin="FSYNC"/>
<wire x1="27.94" y1="116.84" x2="27.94" y2="114.3" width="0.1524" layer="91"/>
<wire x1="27.94" y1="114.3" x2="35.56" y2="114.3" width="0.1524" layer="91"/>
<wire x1="35.56" y1="114.3" x2="43.18" y2="114.3" width="0.1524" layer="91"/>
<wire x1="43.18" y1="114.3" x2="43.18" y2="152.4" width="0.1524" layer="91"/>
<junction x="43.18" y="152.4"/>
<pinref part="C19" gate="G$1" pin="1"/>
<junction x="35.56" y="114.3"/>
</segment>
<segment>
<pinref part="C20" gate="G$1" pin="2"/>
<pinref part="C21" gate="G$1" pin="2"/>
<wire x1="-2.54" y1="96.52" x2="7.62" y2="96.52" width="0.1524" layer="91"/>
<pinref part="GND14" gate="1" pin="GND"/>
<junction x="-2.54" y="96.52"/>
</segment>
<segment>
<pinref part="C23" gate="G$1" pin="2"/>
<pinref part="C22" gate="G$1" pin="2"/>
<wire x1="114.3" y1="127" x2="104.14" y2="127" width="0.1524" layer="91"/>
<pinref part="GND15" gate="1" pin="GND"/>
<junction x="104.14" y="127"/>
</segment>
<segment>
<wire x1="142.24" y1="86.36" x2="142.24" y2="83.82" width="0.1524" layer="91"/>
<wire x1="142.24" y1="83.82" x2="144.78" y2="83.82" width="0.1524" layer="91"/>
<wire x1="144.78" y1="83.82" x2="165.1" y2="83.82" width="0.1524" layer="91"/>
<wire x1="165.1" y1="83.82" x2="165.1" y2="104.14" width="0.1524" layer="91"/>
<wire x1="165.1" y1="104.14" x2="165.1" y2="106.68" width="0.1524" layer="91"/>
<wire x1="165.1" y1="106.68" x2="165.1" y2="109.22" width="0.1524" layer="91"/>
<wire x1="165.1" y1="109.22" x2="165.1" y2="111.76" width="0.1524" layer="91"/>
<wire x1="165.1" y1="111.76" x2="165.1" y2="114.3" width="0.1524" layer="91"/>
<wire x1="144.78" y1="86.36" x2="144.78" y2="83.82" width="0.1524" layer="91"/>
<junction x="144.78" y="83.82"/>
<wire x1="160.02" y1="104.14" x2="165.1" y2="104.14" width="0.1524" layer="91"/>
<junction x="165.1" y="104.14"/>
<wire x1="160.02" y1="106.68" x2="165.1" y2="106.68" width="0.1524" layer="91"/>
<junction x="165.1" y="106.68"/>
<wire x1="160.02" y1="109.22" x2="165.1" y2="109.22" width="0.1524" layer="91"/>
<junction x="165.1" y="109.22"/>
<wire x1="160.02" y1="111.76" x2="165.1" y2="111.76" width="0.1524" layer="91"/>
<junction x="165.1" y="111.76"/>
<wire x1="160.02" y1="114.3" x2="165.1" y2="114.3" width="0.1524" layer="91"/>
<wire x1="142.24" y1="132.08" x2="142.24" y2="139.7" width="0.1524" layer="91"/>
<wire x1="142.24" y1="139.7" x2="165.1" y2="139.7" width="0.1524" layer="91"/>
<wire x1="165.1" y1="139.7" x2="165.1" y2="137.16" width="0.1524" layer="91"/>
<junction x="165.1" y="114.3"/>
<pinref part="C24" gate="G$1" pin="2"/>
<wire x1="165.1" y1="137.16" x2="165.1" y2="114.3" width="0.1524" layer="91"/>
<wire x1="162.56" y1="137.16" x2="165.1" y2="137.16" width="0.1524" layer="91"/>
<junction x="165.1" y="137.16"/>
<pinref part="GND16" gate="1" pin="GND"/>
<pinref part="IC5" gate="G$1" pin="RESV_1"/>
<pinref part="IC5" gate="G$1" pin="FSYNC"/>
<pinref part="IC5" gate="G$1" pin="RESV_2"/>
<pinref part="IC5" gate="G$1" pin="RESV_3"/>
<pinref part="IC5" gate="G$1" pin="RESV_4"/>
<pinref part="IC5" gate="G$1" pin="RESV_5"/>
<pinref part="IC5" gate="G$1" pin="GND"/>
<pinref part="IC5" gate="G$1" pin="RESV_6"/>
</segment>
<segment>
<pinref part="IC6" gate="G$1" pin="PS"/>
<wire x1="210.82" y1="170.18" x2="205.74" y2="170.18" width="0.1524" layer="91"/>
<wire x1="205.74" y1="170.18" x2="205.74" y2="167.64" width="0.1524" layer="91"/>
<pinref part="C25" gate="G$1" pin="2"/>
<wire x1="205.74" y1="167.64" x2="205.74" y2="165.1" width="0.1524" layer="91"/>
<wire x1="205.74" y1="165.1" x2="195.58" y2="165.1" width="0.1524" layer="91"/>
<pinref part="IC6" gate="G$1" pin="GND"/>
<wire x1="210.82" y1="167.64" x2="205.74" y2="167.64" width="0.1524" layer="91"/>
<junction x="205.74" y="167.64"/>
<pinref part="GND17" gate="1" pin="GND"/>
<junction x="205.74" y="165.1"/>
</segment>
<segment>
<pinref part="U1" gate="G$1" pin="GND"/>
<wire x1="304.8" y1="109.22" x2="314.96" y2="109.22" width="0.1524" layer="91"/>
<pinref part="GND19" gate="1" pin="GND"/>
<junction x="304.8" y="109.22"/>
<wire x1="314.96" y1="109.22" x2="320.04" y2="109.22" width="0.1524" layer="91"/>
<pinref part="C27" gate="G$1" pin="2"/>
<pinref part="R5" gate="G$1" pin="1"/>
<wire x1="373.38" y1="109.22" x2="373.38" y2="104.14" width="0.1524" layer="91"/>
<wire x1="373.38" y1="104.14" x2="360.68" y2="104.14" width="0.1524" layer="91"/>
<wire x1="360.68" y1="104.14" x2="347.98" y2="104.14" width="0.1524" layer="91"/>
<wire x1="347.98" y1="104.14" x2="314.96" y2="104.14" width="0.1524" layer="91"/>
<wire x1="314.96" y1="104.14" x2="314.96" y2="109.22" width="0.1524" layer="91"/>
<junction x="314.96" y="109.22"/>
<pinref part="C29" gate="G$1" pin="2"/>
<wire x1="360.68" y1="109.22" x2="360.68" y2="104.14" width="0.1524" layer="91"/>
<junction x="360.68" y="104.14"/>
<pinref part="C28" gate="G$1" pin="2"/>
<wire x1="347.98" y1="109.22" x2="347.98" y2="104.14" width="0.1524" layer="91"/>
<junction x="347.98" y="104.14"/>
</segment>
<segment>
<pinref part="IC7" gate="G$1" pin="GND"/>
<wire x1="246.38" y1="60.96" x2="236.22" y2="60.96" width="0.1524" layer="91"/>
<wire x1="236.22" y1="60.96" x2="236.22" y2="45.72" width="0.1524" layer="91"/>
<wire x1="236.22" y1="45.72" x2="281.94" y2="45.72" width="0.1524" layer="91"/>
<wire x1="223.52" y1="48.26" x2="223.52" y2="45.72" width="0.1524" layer="91"/>
<wire x1="223.52" y1="45.72" x2="236.22" y2="45.72" width="0.1524" layer="91"/>
<junction x="236.22" y="45.72"/>
<wire x1="281.94" y1="45.72" x2="281.94" y2="48.26" width="0.1524" layer="91"/>
<pinref part="C31" gate="G$1" pin="2"/>
<pinref part="C30" gate="G$1" pin="2"/>
<pinref part="GND20" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="C26" gate="G$1" pin="GROUND_1"/>
<wire x1="231.14" y1="139.7" x2="238.76" y2="139.7" width="0.1524" layer="91"/>
<wire x1="238.76" y1="139.7" x2="238.76" y2="93.98" width="0.1524" layer="91"/>
<wire x1="238.76" y1="93.98" x2="231.14" y2="93.98" width="0.1524" layer="91"/>
<pinref part="C26" gate="G$1" pin="GROUND_2"/>
<wire x1="231.14" y1="93.98" x2="231.14" y2="99.06" width="0.1524" layer="91"/>
<pinref part="GND18" gate="1" pin="GND"/>
<junction x="231.14" y="93.98"/>
</segment>
</net>
<net name="N$5" class="0">
<segment>
<pinref part="IC4" gate="G$1" pin="REGOUT"/>
<wire x1="25.4" y1="116.84" x2="25.4" y2="106.68" width="0.1524" layer="91"/>
<wire x1="25.4" y1="106.68" x2="35.56" y2="106.68" width="0.1524" layer="91"/>
<pinref part="C19" gate="G$1" pin="2"/>
</segment>
</net>
<net name="ICM20948_DRDY" class="0">
<segment>
<pinref part="IC4" gate="G$1" pin="INT1"/>
<wire x1="30.48" y1="116.84" x2="30.48" y2="93.98" width="0.1524" layer="91"/>
<label x="30.48" y="86.36" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="ICM20948_MISO" class="0">
<segment>
<pinref part="IC4" gate="G$1" pin="SDO_/_AD0"/>
<wire x1="22.86" y1="116.84" x2="22.86" y2="93.98" width="0.1524" layer="91"/>
<label x="22.86" y="91.44" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="124.46" y1="106.68" x2="104.14" y2="106.68" width="0.1524" layer="91"/>
<label x="101.6" y="106.68" size="1.778" layer="95"/>
<pinref part="IC5" gate="G$1" pin="SA0/SDO"/>
</segment>
</net>
<net name="ICM20948_MOSI" class="0">
<segment>
<pinref part="IC4" gate="G$1" pin="SDA_/_SDI"/>
<wire x1="20.32" y1="175.26" x2="20.32" y2="190.5" width="0.1524" layer="91"/>
<label x="20.32" y="180.34" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="124.46" y1="109.22" x2="104.14" y2="109.22" width="0.1524" layer="91"/>
<label x="101.6" y="109.22" size="1.778" layer="95"/>
<pinref part="IC5" gate="G$1" pin="SDA/SDI"/>
</segment>
</net>
<net name="ICM20948_SCK" class="0">
<segment>
<pinref part="IC4" gate="G$1" pin="SCL_/_SCLK"/>
<wire x1="22.86" y1="175.26" x2="22.86" y2="190.5" width="0.1524" layer="91"/>
<label x="22.86" y="180.34" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="124.46" y1="111.76" x2="104.14" y2="111.76" width="0.1524" layer="91"/>
<label x="101.6" y="111.76" size="1.778" layer="95"/>
<pinref part="IC5" gate="G$1" pin="SCL/SPC"/>
</segment>
</net>
<net name="ICM20948_CS" class="0">
<segment>
<pinref part="IC4" gate="G$1" pin="NCS"/>
<wire x1="25.4" y1="175.26" x2="25.4" y2="190.5" width="0.1524" layer="91"/>
<label x="25.4" y="180.34" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="N$1" class="0">
<segment>
<wire x1="139.7" y1="132.08" x2="139.7" y2="134.62" width="0.1524" layer="91"/>
<pinref part="C23" gate="G$1" pin="1"/>
<wire x1="139.7" y1="134.62" x2="124.46" y2="134.62" width="0.1524" layer="91"/>
<pinref part="C22" gate="G$1" pin="1"/>
<wire x1="124.46" y1="134.62" x2="114.3" y2="134.62" width="0.1524" layer="91"/>
<wire x1="114.3" y1="134.62" x2="104.14" y2="134.62" width="0.1524" layer="91"/>
<junction x="114.3" y="134.62"/>
<wire x1="124.46" y1="114.3" x2="124.46" y2="134.62" width="0.1524" layer="91"/>
<junction x="124.46" y="134.62"/>
<pinref part="IC5" gate="G$1" pin="VDDIO"/>
<pinref part="IC5" gate="G$1" pin="VDD"/>
</segment>
</net>
<net name="20608_DRDY" class="0">
<segment>
<wire x1="124.46" y1="104.14" x2="104.14" y2="104.14" width="0.1524" layer="91"/>
<label x="101.6" y="104.14" size="1.778" layer="95"/>
<pinref part="IC5" gate="G$1" pin="CS"/>
</segment>
</net>
<net name="N$9" class="0">
<segment>
<wire x1="144.78" y1="132.08" x2="144.78" y2="137.16" width="0.1524" layer="91"/>
<pinref part="C24" gate="G$1" pin="1"/>
<wire x1="144.78" y1="137.16" x2="154.94" y2="137.16" width="0.1524" layer="91"/>
<pinref part="IC5" gate="G$1" pin="REGOUT"/>
</segment>
</net>
<net name="20608_CS" class="0">
<segment>
<wire x1="139.7" y1="86.36" x2="139.7" y2="73.66" width="0.1524" layer="91"/>
<label x="139.7" y="71.12" size="1.778" layer="95" rot="R90"/>
<pinref part="IC5" gate="G$1" pin="INT"/>
</segment>
</net>
<net name="VDD_3V3_SENSORS" class="0">
<segment>
<pinref part="IC6" gate="G$1" pin="VDD"/>
<pinref part="C25" gate="G$1" pin="1"/>
<wire x1="210.82" y1="172.72" x2="195.58" y2="172.72" width="0.1524" layer="91"/>
<wire x1="195.58" y1="172.72" x2="182.88" y2="172.72" width="0.1524" layer="91"/>
<junction x="195.58" y="172.72"/>
<label x="180.34" y="172.72" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="IC4" gate="G$1" pin="VDD"/>
<wire x1="40.64" y1="139.7" x2="55.88" y2="139.7" width="0.1524" layer="91"/>
<pinref part="C17" gate="G$1" pin="1"/>
<junction x="55.88" y="139.7"/>
<pinref part="C18" gate="G$1" pin="1"/>
<wire x1="55.88" y1="139.7" x2="66.04" y2="139.7" width="0.1524" layer="91"/>
<label x="48.26" y="139.7" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U1" gate="G$1" pin="OUT"/>
<wire x1="337.82" y1="119.38" x2="347.98" y2="119.38" width="0.1524" layer="91"/>
<pinref part="R5" gate="G$1" pin="2"/>
<junction x="373.38" y="119.38"/>
<wire x1="347.98" y1="119.38" x2="360.68" y2="119.38" width="0.1524" layer="91"/>
<wire x1="360.68" y1="119.38" x2="373.38" y2="119.38" width="0.1524" layer="91"/>
<wire x1="373.38" y1="119.38" x2="396.24" y2="119.38" width="0.1524" layer="91"/>
<pinref part="C29" gate="G$1" pin="1"/>
<wire x1="360.68" y1="116.84" x2="360.68" y2="119.38" width="0.1524" layer="91"/>
<junction x="360.68" y="119.38"/>
<pinref part="C28" gate="G$1" pin="1"/>
<wire x1="347.98" y1="116.84" x2="347.98" y2="119.38" width="0.1524" layer="91"/>
<junction x="347.98" y="119.38"/>
<label x="378.46" y="119.38" size="1.778" layer="95"/>
</segment>
</net>
<net name="FRAM_SCK" class="0">
<segment>
<pinref part="IC6" gate="G$1" pin="SCLK"/>
<wire x1="243.84" y1="172.72" x2="261.62" y2="172.72" width="0.1524" layer="91"/>
<label x="248.92" y="172.72" size="1.778" layer="95"/>
</segment>
</net>
<net name="FRAM_MISO" class="0">
<segment>
<pinref part="IC6" gate="G$1" pin="SDO"/>
<wire x1="243.84" y1="167.64" x2="261.62" y2="167.64" width="0.1524" layer="91"/>
<label x="248.92" y="167.64" size="1.778" layer="95"/>
</segment>
</net>
<net name="BARO_CS" class="0">
<segment>
<pinref part="IC6" gate="G$1" pin="CSB_2"/>
<wire x1="243.84" y1="165.1" x2="261.62" y2="165.1" width="0.1524" layer="91"/>
<label x="248.92" y="165.1" size="1.778" layer="95"/>
</segment>
</net>
<net name="FRAM_MOSI" class="0">
<segment>
<pinref part="IC6" gate="G$1" pin="SDI/SDA"/>
<wire x1="243.84" y1="170.18" x2="261.62" y2="170.18" width="0.1524" layer="91"/>
<label x="248.92" y="170.18" size="1.778" layer="95"/>
</segment>
</net>
<net name="VDD_5V_IN" class="0">
<segment>
<wire x1="205.74" y1="119.38" x2="187.96" y2="119.38" width="0.1524" layer="91"/>
<label x="187.96" y="119.38" size="1.778" layer="95"/>
<pinref part="C26" gate="G$1" pin="SIGNAL/VCC_1"/>
</segment>
<segment>
<pinref part="IC7" gate="G$1" pin="IN"/>
<wire x1="246.38" y1="63.5" x2="223.52" y2="63.5" width="0.1524" layer="91"/>
<wire x1="223.52" y1="63.5" x2="210.82" y2="63.5" width="0.1524" layer="91"/>
<wire x1="223.52" y1="63.5" x2="223.52" y2="55.88" width="0.1524" layer="91"/>
<junction x="223.52" y="63.5"/>
<pinref part="C30" gate="G$1" pin="1"/>
<label x="210.82" y="63.5" size="1.778" layer="95"/>
</segment>
</net>
<net name="VDD_3V3_SENSORS_EN" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="EN"/>
<wire x1="320.04" y1="114.3" x2="259.08" y2="114.3" width="0.1524" layer="91"/>
<label x="259.08" y="114.3" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="IC7" gate="G$1" pin="EN"/>
<wire x1="246.38" y1="58.42" x2="210.82" y2="58.42" width="0.1524" layer="91"/>
<label x="203.2" y="58.42" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$4" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IN"/>
<wire x1="304.8" y1="119.38" x2="320.04" y2="119.38" width="0.1524" layer="91"/>
<wire x1="304.8" y1="119.38" x2="304.8" y2="116.84" width="0.1524" layer="91"/>
<pinref part="C27" gate="G$1" pin="1"/>
<pinref part="C26" gate="G$1" pin="SIGNAL/VCC_2"/>
<wire x1="304.8" y1="119.38" x2="256.54" y2="119.38" width="0.1524" layer="91"/>
<junction x="304.8" y="119.38"/>
</segment>
</net>
</nets>
</sheet>
<sheet>
<plain>
</plain>
<instances>
<instance part="J2" gate="G$1" x="27.94" y="81.28" smashed="yes" rot="R270">
<attribute name="NAME" x="50.8" y="67.31" size="1.778" layer="95" rot="R270" align="center-left"/>
<attribute name="VALUE" x="48.26" y="67.31" size="1.778" layer="96" rot="R270" align="center-left"/>
</instance>
<instance part="GND21" gate="1" x="22.86" y="91.44" smashed="yes" rot="R180">
<attribute name="VALUE" x="25.4" y="93.98" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="R6" gate="G$1" x="10.16" y="76.2" smashed="yes">
<attribute name="NAME" x="10.16" y="77.724" size="1.778" layer="95" font="vector" align="bottom-center"/>
<attribute name="VALUE" x="10.16" y="74.676" size="1.778" layer="96" font="vector" align="top-center"/>
</instance>
<instance part="R7" gate="G$1" x="10.16" y="73.66" smashed="yes">
<attribute name="NAME" x="10.16" y="75.184" size="1.778" layer="95" font="vector" align="bottom-center"/>
<attribute name="VALUE" x="10.16" y="72.136" size="1.778" layer="96" font="vector" align="top-center"/>
</instance>
<instance part="C32" gate="G$1" x="30.48" y="63.5" smashed="yes" rot="R270">
<attribute name="NAME" x="33.401" y="61.976" size="1.778" layer="95" font="vector" rot="R270"/>
<attribute name="VALUE" x="28.321" y="61.976" size="1.778" layer="96" font="vector" rot="R270"/>
</instance>
<instance part="GND22" gate="1" x="43.18" y="63.5" smashed="yes" rot="R90">
<attribute name="VALUE" x="45.72" y="60.96" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="J3" gate="G$1" x="-2.54" y="33.02" smashed="yes">
<attribute name="NAME" x="13.97" y="40.64" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="13.97" y="38.1" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="GND23" gate="1" x="25.4" y="27.94" smashed="yes" rot="R90">
<attribute name="VALUE" x="27.94" y="25.4" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="R8" gate="G$1" x="-22.86" y="27.94" smashed="yes">
<attribute name="NAME" x="-22.86" y="29.464" size="1.778" layer="95" font="vector" align="bottom-center"/>
<attribute name="VALUE" x="-22.86" y="26.416" size="1.778" layer="96" font="vector" align="top-center"/>
</instance>
<instance part="R9" gate="G$1" x="48.26" y="33.02" smashed="yes">
<attribute name="NAME" x="48.26" y="34.544" size="1.778" layer="95" font="vector" align="bottom-center"/>
<attribute name="VALUE" x="48.26" y="31.496" size="1.778" layer="96" font="vector" align="top-center"/>
</instance>
<instance part="R10" gate="G$1" x="-12.7" y="17.78" smashed="yes" rot="R90">
<attribute name="NAME" x="-14.224" y="17.78" size="1.778" layer="95" font="vector" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="-11.176" y="17.78" size="1.778" layer="96" font="vector" rot="R90" align="top-center"/>
</instance>
<instance part="R11" gate="G$1" x="38.1" y="20.32" smashed="yes" rot="R90">
<attribute name="NAME" x="36.576" y="20.32" size="1.778" layer="95" font="vector" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="39.624" y="20.32" size="1.778" layer="96" font="vector" rot="R90" align="top-center"/>
</instance>
<instance part="C33" gate="G$1" x="-35.56" y="17.78" smashed="yes">
<attribute name="NAME" x="-34.036" y="20.701" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="-34.036" y="15.621" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="C34" gate="G$1" x="58.42" y="20.32" smashed="yes">
<attribute name="NAME" x="59.944" y="23.241" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="59.944" y="18.161" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="GND24" gate="1" x="-25.4" y="7.62" smashed="yes">
<attribute name="VALUE" x="-27.94" y="5.08" size="1.778" layer="96"/>
</instance>
<instance part="GND25" gate="1" x="50.8" y="10.16" smashed="yes">
<attribute name="VALUE" x="48.26" y="7.62" size="1.778" layer="96"/>
</instance>
<instance part="R12" gate="G$1" x="-10.16" y="-17.78" smashed="yes">
<attribute name="NAME" x="3.81" y="-11.43" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="3.81" y="-13.97" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="R13" gate="G$1" x="15.24" y="-20.32" smashed="yes" rot="R270">
<attribute name="NAME" x="21.59" y="-34.29" size="1.778" layer="95" rot="R270" align="center-left"/>
<attribute name="VALUE" x="19.05" y="-34.29" size="1.778" layer="96" rot="R270" align="center-left"/>
</instance>
<instance part="GND26" gate="1" x="15.24" y="-45.72" smashed="yes">
<attribute name="VALUE" x="12.7" y="-48.26" size="1.778" layer="96"/>
</instance>
<instance part="J4" gate="G$1" x="106.68" y="83.82" smashed="yes">
<attribute name="NAME" x="140.97" y="91.44" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="140.97" y="88.9" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="GND27" gate="1" x="154.94" y="73.66" smashed="yes">
<attribute name="VALUE" x="152.4" y="71.12" size="1.778" layer="96"/>
</instance>
<instance part="R14" gate="G$1" x="172.72" y="83.82" smashed="yes">
<attribute name="NAME" x="172.72" y="85.344" size="1.778" layer="95" font="vector" align="bottom-center"/>
<attribute name="VALUE" x="172.72" y="82.296" size="1.778" layer="96" font="vector" align="top-center"/>
</instance>
<instance part="R15" gate="G$1" x="81.28" y="96.52" smashed="yes">
<attribute name="NAME" x="81.28" y="98.044" size="1.778" layer="95" font="vector" align="bottom-center"/>
<attribute name="VALUE" x="81.28" y="94.996" size="1.778" layer="96" font="vector" align="top-center"/>
</instance>
<instance part="R16" gate="G$1" x="81.28" y="88.9" smashed="yes">
<attribute name="NAME" x="81.28" y="90.424" size="1.778" layer="95" font="vector" align="bottom-center"/>
<attribute name="VALUE" x="81.28" y="87.376" size="1.778" layer="96" font="vector" align="top-center"/>
</instance>
<instance part="R17" gate="G$1" x="81.28" y="81.28" smashed="yes">
<attribute name="NAME" x="81.28" y="82.804" size="1.778" layer="95" font="vector" align="bottom-center"/>
<attribute name="VALUE" x="81.28" y="79.756" size="1.778" layer="96" font="vector" align="top-center"/>
</instance>
<instance part="R18" gate="G$1" x="76.2" y="60.96" smashed="yes">
<attribute name="NAME" x="76.2" y="62.484" size="1.778" layer="95" font="vector" align="bottom-center"/>
<attribute name="VALUE" x="76.2" y="59.436" size="1.778" layer="96" font="vector" align="top-center"/>
</instance>
<instance part="GND28" gate="1" x="99.06" y="68.58" smashed="yes">
<attribute name="VALUE" x="96.52" y="66.04" size="1.778" layer="96"/>
</instance>
<instance part="C35" gate="G$1" x="83.82" y="73.66" smashed="yes" rot="R180">
<attribute name="NAME" x="82.296" y="70.739" size="1.778" layer="95" font="vector" rot="R180"/>
<attribute name="VALUE" x="82.296" y="75.819" size="1.778" layer="96" font="vector" rot="R180"/>
</instance>
<instance part="GND29" gate="1" x="83.82" y="66.04" smashed="yes">
<attribute name="VALUE" x="81.28" y="63.5" size="1.778" layer="96"/>
</instance>
<instance part="IC8" gate="G$1" x="162.56" y="17.78" smashed="yes">
<attribute name="NAME" x="186.69" y="25.4" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="186.69" y="22.86" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="J5" gate="G$1" x="99.06" y="15.24" smashed="yes">
<attribute name="NAME" x="95.25" y="22.86" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="95.25" y="20.32" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="GND30" gate="1" x="121.92" y="5.08" smashed="yes">
<attribute name="VALUE" x="119.38" y="2.54" size="1.778" layer="96"/>
</instance>
<instance part="C36" gate="G$1" x="137.16" y="2.54" smashed="yes">
<attribute name="NAME" x="138.684" y="5.461" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="138.684" y="0.381" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="GND31" gate="1" x="137.16" y="-5.08" smashed="yes">
<attribute name="VALUE" x="134.62" y="-7.62" size="1.778" layer="96"/>
</instance>
<instance part="GND32" gate="1" x="149.86" y="15.24" smashed="yes" rot="R270">
<attribute name="VALUE" x="147.32" y="17.78" size="1.778" layer="96" rot="R270"/>
</instance>
<instance part="GND33" gate="1" x="195.58" y="7.62" smashed="yes">
<attribute name="VALUE" x="193.04" y="5.08" size="1.778" layer="96"/>
</instance>
<instance part="R19" gate="G$1" x="210.82" y="22.86" smashed="yes" rot="R90">
<attribute name="NAME" x="209.296" y="22.86" size="1.778" layer="95" font="vector" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="212.344" y="22.86" size="1.778" layer="96" font="vector" rot="R90" align="top-center"/>
</instance>
</instances>
<busses>
</busses>
<nets>
<net name="GND" class="0">
<segment>
<pinref part="J2" gate="G$1" pin="GND"/>
<wire x1="27.94" y1="81.28" x2="22.86" y2="81.28" width="0.1524" layer="91"/>
<pinref part="GND21" gate="1" pin="GND"/>
<wire x1="22.86" y1="81.28" x2="22.86" y2="88.9" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="C32" gate="G$1" pin="1"/>
<pinref part="GND22" gate="1" pin="GND"/>
<wire x1="35.56" y1="63.5" x2="40.64" y2="63.5" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="J3" gate="G$1" pin="5"/>
<wire x1="17.78" y1="30.48" x2="22.86" y2="30.48" width="0.1524" layer="91"/>
<wire x1="22.86" y1="30.48" x2="22.86" y2="27.94" width="0.1524" layer="91"/>
<pinref part="J3" gate="G$1" pin="6"/>
<wire x1="22.86" y1="27.94" x2="17.78" y2="27.94" width="0.1524" layer="91"/>
<pinref part="GND23" gate="1" pin="GND"/>
<junction x="22.86" y="27.94"/>
</segment>
<segment>
<pinref part="R10" gate="G$1" pin="1"/>
<wire x1="-12.7" y1="12.7" x2="-12.7" y2="10.16" width="0.1524" layer="91"/>
<wire x1="-12.7" y1="10.16" x2="-25.4" y2="10.16" width="0.1524" layer="91"/>
<pinref part="C33" gate="G$1" pin="2"/>
<wire x1="-25.4" y1="10.16" x2="-35.56" y2="10.16" width="0.1524" layer="91"/>
<wire x1="-35.56" y1="10.16" x2="-35.56" y2="15.24" width="0.1524" layer="91"/>
<pinref part="GND24" gate="1" pin="GND"/>
<junction x="-25.4" y="10.16"/>
</segment>
<segment>
<pinref part="R11" gate="G$1" pin="1"/>
<wire x1="38.1" y1="15.24" x2="38.1" y2="12.7" width="0.1524" layer="91"/>
<wire x1="38.1" y1="12.7" x2="50.8" y2="12.7" width="0.1524" layer="91"/>
<pinref part="C34" gate="G$1" pin="2"/>
<wire x1="50.8" y1="12.7" x2="58.42" y2="12.7" width="0.1524" layer="91"/>
<wire x1="58.42" y1="12.7" x2="58.42" y2="17.78" width="0.1524" layer="91"/>
<pinref part="GND25" gate="1" pin="GND"/>
<junction x="50.8" y="12.7"/>
</segment>
<segment>
<pinref part="R13" gate="G$1" pin="2"/>
<wire x1="15.24" y1="-38.1" x2="15.24" y2="-43.18" width="0.1524" layer="91"/>
<pinref part="GND26" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="J4" gate="G$1" pin="GND_3"/>
<pinref part="GND27" gate="1" pin="GND"/>
<wire x1="144.78" y1="76.2" x2="154.94" y2="76.2" width="0.1524" layer="91"/>
<pinref part="J4" gate="G$1" pin="GND_2"/>
<wire x1="144.78" y1="78.74" x2="154.94" y2="78.74" width="0.1524" layer="91"/>
<wire x1="154.94" y1="78.74" x2="154.94" y2="76.2" width="0.1524" layer="91"/>
<junction x="154.94" y="76.2"/>
<pinref part="J4" gate="G$1" pin="GND_1"/>
<wire x1="144.78" y1="81.28" x2="154.94" y2="81.28" width="0.1524" layer="91"/>
<wire x1="154.94" y1="81.28" x2="154.94" y2="78.74" width="0.1524" layer="91"/>
<junction x="154.94" y="78.74"/>
</segment>
<segment>
<pinref part="GND28" gate="1" pin="GND"/>
<pinref part="J4" gate="G$1" pin="6"/>
<wire x1="99.06" y1="71.12" x2="106.68" y2="71.12" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="C35" gate="G$1" pin="1"/>
<pinref part="GND29" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="J5" gate="G$1" pin="4"/>
<wire x1="119.38" y1="12.7" x2="121.92" y2="12.7" width="0.1524" layer="91"/>
<pinref part="GND30" gate="1" pin="GND"/>
<wire x1="121.92" y1="12.7" x2="121.92" y2="7.62" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="GND31" gate="1" pin="GND"/>
<pinref part="C36" gate="G$1" pin="2"/>
<wire x1="137.16" y1="-2.54" x2="137.16" y2="0" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC8" gate="G$1" pin="GND"/>
<wire x1="162.56" y1="15.24" x2="152.4" y2="15.24" width="0.1524" layer="91"/>
<pinref part="GND32" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="IC8" gate="G$1" pin="S"/>
<wire x1="190.5" y1="12.7" x2="195.58" y2="12.7" width="0.1524" layer="91"/>
<wire x1="195.58" y1="12.7" x2="195.58" y2="10.16" width="0.1524" layer="91"/>
<pinref part="IC8" gate="G$1" pin="EP"/>
<wire x1="195.58" y1="10.16" x2="190.5" y2="10.16" width="0.1524" layer="91"/>
<pinref part="GND33" gate="1" pin="GND"/>
<junction x="195.58" y="10.16"/>
</segment>
</net>
<net name="N$2" class="0">
<segment>
<pinref part="R6" gate="G$1" pin="2"/>
<pinref part="J2" gate="G$1" pin="D+"/>
<wire x1="15.24" y1="76.2" x2="27.94" y2="76.2" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$6" class="0">
<segment>
<pinref part="J2" gate="G$1" pin="D-"/>
<pinref part="R7" gate="G$1" pin="2"/>
<wire x1="27.94" y1="73.66" x2="15.24" y2="73.66" width="0.1524" layer="91"/>
</segment>
</net>
<net name="OTG_FS_DM" class="0">
<segment>
<pinref part="R7" gate="G$1" pin="1"/>
<wire x1="5.08" y1="73.66" x2="-5.08" y2="73.66" width="0.1524" layer="91"/>
<label x="-10.16" y="73.66" size="1.778" layer="95"/>
</segment>
</net>
<net name="VBUS" class="0">
<segment>
<pinref part="J2" gate="G$1" pin="VBUS"/>
<wire x1="27.94" y1="71.12" x2="27.94" y2="63.5" width="0.1524" layer="91"/>
<wire x1="27.94" y1="63.5" x2="5.08" y2="63.5" width="0.1524" layer="91"/>
<pinref part="C32" gate="G$1" pin="2"/>
<junction x="27.94" y="63.5"/>
<label x="5.08" y="63.5" size="1.778" layer="95"/>
</segment>
</net>
<net name="OTG_FS_DP" class="0">
<segment>
<pinref part="R6" gate="G$1" pin="1"/>
<wire x1="5.08" y1="76.2" x2="-5.08" y2="76.2" width="0.1524" layer="91"/>
<label x="-10.16" y="76.2" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$7" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="1"/>
<wire x1="-2.54" y1="33.02" x2="-10.16" y2="33.02" width="0.1524" layer="91"/>
<pinref part="J3" gate="G$1" pin="2"/>
<wire x1="-10.16" y1="33.02" x2="-20.32" y2="33.02" width="0.1524" layer="91"/>
<wire x1="-2.54" y1="30.48" x2="-10.16" y2="30.48" width="0.1524" layer="91"/>
<wire x1="-10.16" y1="30.48" x2="-10.16" y2="33.02" width="0.1524" layer="91"/>
<junction x="-10.16" y="33.02"/>
</segment>
</net>
<net name="N$8" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="3"/>
<pinref part="R8" gate="G$1" pin="2"/>
<wire x1="-2.54" y1="27.94" x2="-12.7" y2="27.94" width="0.1524" layer="91"/>
<pinref part="R10" gate="G$1" pin="2"/>
<wire x1="-12.7" y1="27.94" x2="-17.78" y2="27.94" width="0.1524" layer="91"/>
<wire x1="-12.7" y1="22.86" x2="-12.7" y2="27.94" width="0.1524" layer="91"/>
<junction x="-12.7" y="27.94"/>
</segment>
</net>
<net name="BATT_CURRENT_SENS" class="0">
<segment>
<pinref part="C33" gate="G$1" pin="1"/>
<wire x1="-35.56" y1="22.86" x2="-35.56" y2="27.94" width="0.1524" layer="91"/>
<pinref part="R8" gate="G$1" pin="1"/>
<wire x1="-35.56" y1="27.94" x2="-27.94" y2="27.94" width="0.1524" layer="91"/>
<wire x1="-35.56" y1="27.94" x2="-45.72" y2="27.94" width="0.1524" layer="91"/>
<junction x="-35.56" y="27.94"/>
<label x="-55.88" y="27.94" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$12" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="4"/>
<pinref part="R9" gate="G$1" pin="1"/>
<wire x1="17.78" y1="33.02" x2="38.1" y2="33.02" width="0.1524" layer="91"/>
<pinref part="R11" gate="G$1" pin="2"/>
<wire x1="38.1" y1="33.02" x2="43.18" y2="33.02" width="0.1524" layer="91"/>
<wire x1="38.1" y1="25.4" x2="38.1" y2="33.02" width="0.1524" layer="91"/>
<junction x="38.1" y="33.02"/>
</segment>
</net>
<net name="BAT_VOLT_SENS" class="0">
<segment>
<pinref part="C34" gate="G$1" pin="1"/>
<wire x1="58.42" y1="25.4" x2="58.42" y2="33.02" width="0.1524" layer="91"/>
<pinref part="R9" gate="G$1" pin="2"/>
<wire x1="58.42" y1="33.02" x2="53.34" y2="33.02" width="0.1524" layer="91"/>
<wire x1="58.42" y1="33.02" x2="68.58" y2="33.02" width="0.1524" layer="91"/>
<junction x="58.42" y="33.02"/>
<label x="55.88" y="33.02" size="1.778" layer="95"/>
</segment>
</net>
<net name="VDD_5V_IN" class="0">
<segment>
<pinref part="R12" gate="G$1" pin="1"/>
<wire x1="-10.16" y1="-17.78" x2="-27.94" y2="-17.78" width="0.1524" layer="91"/>
<label x="-27.94" y="-17.78" size="1.778" layer="95"/>
</segment>
</net>
<net name="VDD_5V_SENS" class="0">
<segment>
<pinref part="R12" gate="G$1" pin="2"/>
<wire x1="7.62" y1="-17.78" x2="15.24" y2="-17.78" width="0.1524" layer="91"/>
<pinref part="R13" gate="G$1" pin="1"/>
<wire x1="15.24" y1="-17.78" x2="15.24" y2="-20.32" width="0.1524" layer="91"/>
<wire x1="15.24" y1="-17.78" x2="35.56" y2="-17.78" width="0.1524" layer="91"/>
<junction x="15.24" y="-17.78"/>
<label x="22.86" y="-17.78" size="1.778" layer="95"/>
</segment>
</net>
<net name="SDIO_D0" class="0">
<segment>
<pinref part="J4" gate="G$1" pin="7"/>
<wire x1="106.68" y1="68.58" x2="104.14" y2="68.58" width="0.1524" layer="91"/>
<wire x1="104.14" y1="68.58" x2="104.14" y2="60.96" width="0.1524" layer="91"/>
<pinref part="R18" gate="G$1" pin="2"/>
<wire x1="104.14" y1="60.96" x2="81.28" y2="60.96" width="0.1524" layer="91"/>
<label x="91.44" y="60.96" size="1.778" layer="95"/>
</segment>
</net>
<net name="SDIO_D2" class="0">
<segment>
<pinref part="R15" gate="G$1" pin="2"/>
<wire x1="86.36" y1="96.52" x2="106.68" y2="96.52" width="0.1524" layer="91"/>
<pinref part="J4" gate="G$1" pin="1"/>
<wire x1="106.68" y1="96.52" x2="106.68" y2="83.82" width="0.1524" layer="91"/>
<label x="86.36" y="96.52" size="1.778" layer="95"/>
</segment>
</net>
<net name="SDIO_D3" class="0">
<segment>
<pinref part="R16" gate="G$1" pin="2"/>
<wire x1="86.36" y1="88.9" x2="101.6" y2="88.9" width="0.1524" layer="91"/>
<wire x1="101.6" y1="88.9" x2="101.6" y2="81.28" width="0.1524" layer="91"/>
<pinref part="J4" gate="G$1" pin="2"/>
<wire x1="101.6" y1="81.28" x2="106.68" y2="81.28" width="0.1524" layer="91"/>
<label x="86.36" y="88.9" size="1.778" layer="95"/>
</segment>
</net>
<net name="SDIO_CMD" class="0">
<segment>
<pinref part="J4" gate="G$1" pin="3"/>
<wire x1="106.68" y1="78.74" x2="96.52" y2="78.74" width="0.1524" layer="91"/>
<wire x1="96.52" y1="78.74" x2="96.52" y2="81.28" width="0.1524" layer="91"/>
<pinref part="R17" gate="G$1" pin="2"/>
<wire x1="96.52" y1="81.28" x2="86.36" y2="81.28" width="0.1524" layer="91"/>
<label x="86.36" y="81.28" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_VDD_3V3" class="0">
<segment>
<pinref part="J4" gate="G$1" pin="4"/>
<pinref part="C35" gate="G$1" pin="2"/>
<wire x1="106.68" y1="76.2" x2="83.82" y2="76.2" width="0.1524" layer="91"/>
<label x="88.9" y="76.2" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R14" gate="G$1" pin="2"/>
<wire x1="177.8" y1="83.82" x2="177.8" y2="104.14" width="0.1524" layer="91"/>
<wire x1="177.8" y1="104.14" x2="71.12" y2="104.14" width="0.1524" layer="91"/>
<wire x1="71.12" y1="104.14" x2="71.12" y2="96.52" width="0.1524" layer="91"/>
<pinref part="R18" gate="G$1" pin="1"/>
<wire x1="71.12" y1="96.52" x2="71.12" y2="88.9" width="0.1524" layer="91"/>
<wire x1="71.12" y1="88.9" x2="71.12" y2="81.28" width="0.1524" layer="91"/>
<pinref part="R16" gate="G$1" pin="1"/>
<wire x1="71.12" y1="81.28" x2="71.12" y2="60.96" width="0.1524" layer="91"/>
<wire x1="76.2" y1="88.9" x2="71.12" y2="88.9" width="0.1524" layer="91"/>
<junction x="71.12" y="88.9"/>
<pinref part="R15" gate="G$1" pin="1"/>
<wire x1="76.2" y1="96.52" x2="71.12" y2="96.52" width="0.1524" layer="91"/>
<junction x="71.12" y="96.52"/>
<pinref part="R17" gate="G$1" pin="1"/>
<wire x1="76.2" y1="81.28" x2="71.12" y2="81.28" width="0.1524" layer="91"/>
<junction x="71.12" y="81.28"/>
<label x="71.12" y="76.2" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<pinref part="IC8" gate="G$1" pin="VIO"/>
<wire x1="162.56" y1="7.62" x2="152.4" y2="7.62" width="0.1524" layer="91"/>
<label x="144.78" y="7.62" size="1.778" layer="95"/>
</segment>
</net>
<net name="SDIO_D1" class="0">
<segment>
<pinref part="J4" gate="G$1" pin="8"/>
<pinref part="R14" gate="G$1" pin="1"/>
<wire x1="144.78" y1="83.82" x2="167.64" y2="83.82" width="0.1524" layer="91"/>
<label x="149.86" y="83.82" size="1.778" layer="95"/>
</segment>
</net>
<net name="SDIO_CK" class="0">
<segment>
<pinref part="J4" gate="G$1" pin="5"/>
<wire x1="106.68" y1="73.66" x2="93.98" y2="73.66" width="0.1524" layer="91"/>
<label x="93.98" y="73.66" size="1.778" layer="95"/>
</segment>
</net>
<net name="CAN1_TX" class="0">
<segment>
<pinref part="IC8" gate="G$1" pin="TXD"/>
<wire x1="162.56" y1="17.78" x2="152.4" y2="17.78" width="0.1524" layer="91"/>
<label x="152.4" y="17.78" size="1.778" layer="95"/>
</segment>
</net>
<net name="VDD_5V_PERIPH" class="0">
<segment>
<pinref part="IC8" gate="G$1" pin="VCC"/>
<wire x1="162.56" y1="12.7" x2="137.16" y2="12.7" width="0.1524" layer="91"/>
<wire x1="137.16" y1="12.7" x2="137.16" y2="7.62" width="0.1524" layer="91"/>
<pinref part="C36" gate="G$1" pin="1"/>
<wire x1="137.16" y1="12.7" x2="134.62" y2="12.7" width="0.1524" layer="91"/>
<junction x="137.16" y="12.7"/>
<label x="127" y="12.7" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="J5" gate="G$1" pin="1"/>
<wire x1="99.06" y1="15.24" x2="86.36" y2="15.24" width="0.1524" layer="91"/>
<label x="78.74" y="15.24" size="1.778" layer="95"/>
</segment>
</net>
<net name="CAN1_RX" class="0">
<segment>
<pinref part="IC8" gate="G$1" pin="RXD"/>
<wire x1="162.56" y1="10.16" x2="152.4" y2="10.16" width="0.1524" layer="91"/>
<label x="152.4" y="10.16" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$17" class="0">
<segment>
<pinref part="IC8" gate="G$1" pin="CANH"/>
<wire x1="190.5" y1="15.24" x2="203.2" y2="15.24" width="0.1524" layer="91"/>
<wire x1="203.2" y1="15.24" x2="203.2" y2="-12.7" width="0.1524" layer="91"/>
<wire x1="203.2" y1="-12.7" x2="93.98" y2="-12.7" width="0.1524" layer="91"/>
<wire x1="93.98" y1="-12.7" x2="93.98" y2="12.7" width="0.1524" layer="91"/>
<pinref part="J5" gate="G$1" pin="2"/>
<wire x1="93.98" y1="12.7" x2="99.06" y2="12.7" width="0.1524" layer="91"/>
<pinref part="R19" gate="G$1" pin="1"/>
<wire x1="210.82" y1="17.78" x2="210.82" y2="15.24" width="0.1524" layer="91"/>
<wire x1="210.82" y1="15.24" x2="203.2" y2="15.24" width="0.1524" layer="91"/>
<junction x="203.2" y="15.24"/>
</segment>
</net>
<net name="N$19" class="0">
<segment>
<pinref part="J5" gate="G$1" pin="3"/>
<wire x1="119.38" y1="15.24" x2="139.7" y2="15.24" width="0.1524" layer="91"/>
<wire x1="139.7" y1="15.24" x2="139.7" y2="27.94" width="0.1524" layer="91"/>
<wire x1="139.7" y1="27.94" x2="195.58" y2="27.94" width="0.1524" layer="91"/>
<wire x1="195.58" y1="27.94" x2="195.58" y2="17.78" width="0.1524" layer="91"/>
<pinref part="IC8" gate="G$1" pin="CANL"/>
<wire x1="195.58" y1="17.78" x2="190.5" y2="17.78" width="0.1524" layer="91"/>
<pinref part="R19" gate="G$1" pin="2"/>
<wire x1="210.82" y1="27.94" x2="195.58" y2="27.94" width="0.1524" layer="91"/>
<junction x="195.58" y="27.94"/>
</segment>
</net>
</nets>
</sheet>
<sheet>
<plain>
<text x="43.18" y="147.32" size="1.778" layer="91">PMM_RSSI_SBUS_SPECTRUM</text>
<text x="35.56" y="27.94" size="1.778" layer="91">TELEM2+OSD</text>
<text x="38.1" y="-10.16" size="1.778" layer="91">TELEM1</text>
<text x="200.66" y="137.16" size="1.778" layer="91">GPS PORT</text>
<text x="292.1" y="185.42" size="1.778" layer="91">VDD_SERVO_1-6</text>
<text x="320.04" y="185.42" size="1.778" layer="91">GND_SERVO_1-6</text>
<text x="320.04" y="152.4" size="1.778" layer="91">SERVO_1-6</text>
<text x="309.88" y="88.9" size="1.778" layer="91">BUT/BUZ</text>
<text x="304.8" y="50.8" size="1.778" layer="91">SERIAL4/FrSky</text>
<text x="297.18" y="2.54" size="1.778" layer="91">ESP8266</text>
</plain>
<instances>
<instance part="J6" gate="G$1" x="27.94" y="132.08" smashed="yes">
<attribute name="NAME" x="29.21" y="139.7" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="29.21" y="137.16" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="R20" gate="G$1" x="17.78" y="124.46" smashed="yes" rot="R180">
<attribute name="NAME" x="17.78" y="122.936" size="1.778" layer="95" font="vector" rot="R180" align="bottom-center"/>
<attribute name="VALUE" x="17.78" y="125.984" size="1.778" layer="96" font="vector" rot="R180" align="top-center"/>
</instance>
<instance part="GND34" gate="1" x="53.34" y="124.46" smashed="yes">
<attribute name="VALUE" x="50.8" y="121.92" size="1.778" layer="96"/>
</instance>
<instance part="R21" gate="G$1" x="5.08" y="116.84" smashed="yes">
<attribute name="NAME" x="6.35" y="110.49" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="6.35" y="113.03" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="IC9" gate="G$1" x="20.32" y="88.9" smashed="yes">
<attribute name="NAME" x="41.91" y="96.52" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="41.91" y="93.98" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="GND35" gate="1" x="15.24" y="78.74" smashed="yes">
<attribute name="VALUE" x="12.7" y="76.2" size="1.778" layer="96"/>
</instance>
<instance part="IC10" gate="G$1" x="20.32" y="58.42" smashed="yes">
<attribute name="NAME" x="41.91" y="66.04" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="41.91" y="63.5" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="R22" gate="G$1" x="60.96" y="53.34" smashed="yes">
<attribute name="NAME" x="60.96" y="54.864" size="1.778" layer="95" font="vector" align="bottom-center"/>
<attribute name="VALUE" x="60.96" y="51.816" size="1.778" layer="96" font="vector" align="top-center"/>
</instance>
<instance part="R23" gate="G$1" x="60.96" y="45.72" smashed="yes">
<attribute name="NAME" x="60.96" y="47.244" size="1.778" layer="95" font="vector" align="bottom-center"/>
<attribute name="VALUE" x="60.96" y="44.196" size="1.778" layer="96" font="vector" align="top-center"/>
</instance>
<instance part="GND36" gate="1" x="15.24" y="45.72" smashed="yes">
<attribute name="VALUE" x="12.7" y="43.18" size="1.778" layer="96"/>
</instance>
<instance part="J7" gate="G$1" x="22.86" y="17.78" smashed="yes">
<attribute name="NAME" x="26.67" y="25.4" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="26.67" y="22.86" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="C37" gate="G$1" x="15.24" y="20.32" smashed="yes">
<attribute name="NAME" x="16.764" y="23.241" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="16.764" y="18.161" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="GND37" gate="1" x="15.24" y="30.48" smashed="yes" rot="R180">
<attribute name="VALUE" x="17.78" y="33.02" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="R24" gate="G$1" x="10.16" y="12.7" smashed="yes" rot="R180">
<attribute name="NAME" x="10.16" y="11.176" size="1.778" layer="95" font="vector" rot="R180" align="bottom-center"/>
<attribute name="VALUE" x="10.16" y="14.224" size="1.778" layer="96" font="vector" rot="R180" align="top-center"/>
</instance>
<instance part="R25" gate="G$1" x="10.16" y="5.08" smashed="yes" rot="R180">
<attribute name="NAME" x="10.16" y="3.556" size="1.778" layer="95" font="vector" rot="R180" align="bottom-center"/>
<attribute name="VALUE" x="10.16" y="6.604" size="1.778" layer="96" font="vector" rot="R180" align="top-center"/>
</instance>
<instance part="R26" gate="G$1" x="58.42" y="17.78" smashed="yes" rot="R180">
<attribute name="NAME" x="58.42" y="16.256" size="1.778" layer="95" font="vector" rot="R180" align="bottom-center"/>
<attribute name="VALUE" x="58.42" y="19.304" size="1.778" layer="96" font="vector" rot="R180" align="top-center"/>
</instance>
<instance part="R27" gate="G$1" x="58.42" y="10.16" smashed="yes" rot="R180">
<attribute name="NAME" x="58.42" y="8.636" size="1.778" layer="95" font="vector" rot="R180" align="bottom-center"/>
<attribute name="VALUE" x="58.42" y="11.684" size="1.778" layer="96" font="vector" rot="R180" align="top-center"/>
</instance>
<instance part="GND38" gate="1" x="45.72" y="7.62" smashed="yes">
<attribute name="VALUE" x="43.18" y="5.08" size="1.778" layer="96"/>
</instance>
<instance part="J8" gate="G$1" x="22.86" y="-20.32" smashed="yes">
<attribute name="NAME" x="26.67" y="-12.7" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="26.67" y="-15.24" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="C38" gate="G$1" x="15.24" y="-17.78" smashed="yes">
<attribute name="NAME" x="16.764" y="-14.859" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="16.764" y="-19.939" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="GND39" gate="1" x="15.24" y="-7.62" smashed="yes" rot="R180">
<attribute name="VALUE" x="17.78" y="-5.08" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="R28" gate="G$1" x="10.16" y="-25.4" smashed="yes" rot="R180">
<attribute name="NAME" x="10.16" y="-26.924" size="1.778" layer="95" font="vector" rot="R180" align="bottom-center"/>
<attribute name="VALUE" x="10.16" y="-23.876" size="1.778" layer="96" font="vector" rot="R180" align="top-center"/>
</instance>
<instance part="R29" gate="G$1" x="10.16" y="-33.02" smashed="yes" rot="R180">
<attribute name="NAME" x="10.16" y="-34.544" size="1.778" layer="95" font="vector" rot="R180" align="bottom-center"/>
<attribute name="VALUE" x="10.16" y="-31.496" size="1.778" layer="96" font="vector" rot="R180" align="top-center"/>
</instance>
<instance part="R30" gate="G$1" x="58.42" y="-20.32" smashed="yes" rot="R180">
<attribute name="NAME" x="58.42" y="-21.844" size="1.778" layer="95" font="vector" rot="R180" align="bottom-center"/>
<attribute name="VALUE" x="58.42" y="-18.796" size="1.778" layer="96" font="vector" rot="R180" align="top-center"/>
</instance>
<instance part="R31" gate="G$1" x="58.42" y="-27.94" smashed="yes" rot="R180">
<attribute name="NAME" x="58.42" y="-29.464" size="1.778" layer="95" font="vector" rot="R180" align="bottom-center"/>
<attribute name="VALUE" x="58.42" y="-26.416" size="1.778" layer="96" font="vector" rot="R180" align="top-center"/>
</instance>
<instance part="GND40" gate="1" x="45.72" y="-30.48" smashed="yes">
<attribute name="VALUE" x="43.18" y="-33.02" size="1.778" layer="96"/>
</instance>
<instance part="J9" gate="G$1" x="198.12" y="149.86" smashed="yes">
<attribute name="NAME" x="214.63" y="157.48" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="214.63" y="154.94" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="GND41" gate="1" x="147.32" y="119.38" smashed="yes">
<attribute name="VALUE" x="144.78" y="116.84" size="1.778" layer="96"/>
</instance>
<instance part="GND42" gate="1" x="220.98" y="139.7" smashed="yes">
<attribute name="VALUE" x="218.44" y="137.16" size="1.778" layer="96"/>
</instance>
<instance part="R32" gate="G$1" x="236.22" y="134.62" smashed="yes" rot="R90">
<attribute name="NAME" x="234.696" y="134.62" size="1.778" layer="95" font="vector" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="237.744" y="134.62" size="1.778" layer="96" font="vector" rot="R90" align="top-center"/>
</instance>
<instance part="R33" gate="G$1" x="228.6" y="134.62" smashed="yes" rot="R90">
<attribute name="NAME" x="227.076" y="134.62" size="1.778" layer="95" font="vector" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="230.124" y="134.62" size="1.778" layer="96" font="vector" rot="R90" align="top-center"/>
</instance>
<instance part="J10" gate="G$1" x="294.64" y="175.26" smashed="yes" rot="R180">
<attribute name="VALUE" x="299.72" y="185.166" size="1.778" layer="96" font="vector" rot="R180"/>
<attribute name="NAME" x="299.72" y="164.592" size="1.778" layer="95" font="vector" rot="R180"/>
</instance>
<instance part="J11" gate="G$1" x="322.58" y="175.26" smashed="yes" rot="R180">
<attribute name="VALUE" x="327.66" y="185.166" size="1.778" layer="96" font="vector" rot="R180"/>
<attribute name="NAME" x="327.66" y="164.592" size="1.778" layer="95" font="vector" rot="R180"/>
</instance>
<instance part="J12" gate="G$1" x="322.58" y="142.24" smashed="yes" rot="R180">
<attribute name="VALUE" x="327.66" y="152.146" size="1.778" layer="96" font="vector" rot="R180"/>
<attribute name="NAME" x="327.66" y="131.572" size="1.778" layer="95" font="vector" rot="R180"/>
</instance>
<instance part="GND43" gate="1" x="314.96" y="165.1" smashed="yes">
<attribute name="VALUE" x="312.42" y="162.56" size="1.778" layer="96"/>
</instance>
<instance part="R34" gate="G$1" x="304.8" y="147.32" smashed="yes" rot="R180">
<attribute name="NAME" x="330.2" y="148.336" size="1.778" layer="95" font="vector" rot="R180" align="bottom-center"/>
<attribute name="VALUE" x="337.82" y="148.336" size="1.778" layer="96" font="vector" align="top-center"/>
</instance>
<instance part="R35" gate="G$1" x="304.8" y="144.78" smashed="yes" rot="R180">
<attribute name="NAME" x="330.2" y="145.796" size="1.778" layer="95" font="vector" rot="R180" align="bottom-center"/>
<attribute name="VALUE" x="337.82" y="145.796" size="1.778" layer="96" font="vector" align="top-center"/>
</instance>
<instance part="R36" gate="G$1" x="304.8" y="142.24" smashed="yes" rot="R180">
<attribute name="NAME" x="330.2" y="143.256" size="1.778" layer="95" font="vector" rot="R180" align="bottom-center"/>
<attribute name="VALUE" x="337.82" y="143.256" size="1.778" layer="96" font="vector" align="top-center"/>
</instance>
<instance part="R37" gate="G$1" x="304.8" y="139.7" smashed="yes" rot="R180">
<attribute name="NAME" x="330.2" y="140.716" size="1.778" layer="95" font="vector" rot="R180" align="bottom-center"/>
<attribute name="VALUE" x="337.82" y="140.716" size="1.778" layer="96" font="vector" align="top-center"/>
</instance>
<instance part="R38" gate="G$1" x="304.8" y="137.16" smashed="yes" rot="R180">
<attribute name="NAME" x="330.2" y="138.176" size="1.778" layer="95" font="vector" rot="R180" align="bottom-center"/>
<attribute name="VALUE" x="337.82" y="138.176" size="1.778" layer="96" font="vector" align="top-center"/>
</instance>
<instance part="R39" gate="G$1" x="304.8" y="134.62" smashed="yes" rot="R180">
<attribute name="NAME" x="330.2" y="135.636" size="1.778" layer="95" font="vector" rot="R180" align="bottom-center"/>
<attribute name="VALUE" x="337.82" y="135.636" size="1.778" layer="96" font="vector" align="top-center"/>
</instance>
<instance part="J13" gate="G$1" x="302.26" y="101.6" smashed="yes">
<attribute name="NAME" x="303.53" y="109.22" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="303.53" y="106.68" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="R40" gate="G$1" x="287.02" y="109.22" smashed="yes" rot="R180">
<attribute name="NAME" x="287.02" y="107.696" size="1.778" layer="95" font="vector" rot="R180" align="bottom-center"/>
<attribute name="VALUE" x="287.02" y="110.744" size="1.778" layer="96" font="vector" rot="R180" align="top-center"/>
</instance>
<instance part="GND44" gate="1" x="276.86" y="109.22" smashed="yes" rot="R270">
<attribute name="VALUE" x="274.32" y="111.76" size="1.778" layer="96" rot="R270"/>
</instance>
<instance part="R41" gate="G$1" x="284.48" y="96.52" smashed="yes">
<attribute name="NAME" x="284.48" y="98.044" size="1.778" layer="95" font="vector" align="bottom-center"/>
<attribute name="VALUE" x="284.48" y="94.996" size="1.778" layer="96" font="vector" align="top-center"/>
</instance>
<instance part="J14" gate="G$1" x="302.26" y="60.96" smashed="yes">
<attribute name="NAME" x="306.07" y="68.58" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="306.07" y="66.04" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="C40" gate="G$1" x="294.64" y="66.04" smashed="yes">
<attribute name="NAME" x="296.164" y="68.961" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="296.164" y="63.881" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="GND45" gate="1" x="294.64" y="76.2" smashed="yes" rot="R180">
<attribute name="VALUE" x="297.18" y="78.74" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="GND46" gate="1" x="330.2" y="53.34" smashed="yes">
<attribute name="VALUE" x="327.66" y="50.8" size="1.778" layer="96"/>
</instance>
<instance part="JP1" gate="A" x="302.26" y="15.24" smashed="yes">
<attribute name="NAME" x="295.91" y="23.495" size="1.778" layer="95"/>
<attribute name="VALUE" x="295.91" y="5.08" size="1.778" layer="96"/>
</instance>
<instance part="GND47" gate="1" x="314.96" y="25.4" smashed="yes" rot="R180">
<attribute name="VALUE" x="317.5" y="27.94" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="C39" gate="G$1" x="121.92" y="149.86" smashed="yes">
<attribute name="NAME" x="168.91" y="170.18" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="168.91" y="167.64" size="1.778" layer="96" align="center-left"/>
</instance>
</instances>
<busses>
</busses>
<nets>
<net name="VDD_5V_RECEIVER" class="0">
<segment>
<pinref part="J6" gate="G$1" pin="1"/>
<wire x1="27.94" y1="132.08" x2="-2.54" y2="132.08" width="0.1524" layer="91"/>
<label x="-2.54" y="132.08" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$11" class="0">
<segment>
<pinref part="J6" gate="G$1" pin="2"/>
<wire x1="27.94" y1="129.54" x2="22.86" y2="129.54" width="0.1524" layer="91"/>
<pinref part="R20" gate="G$1" pin="1"/>
<wire x1="22.86" y1="129.54" x2="22.86" y2="124.46" width="0.1524" layer="91"/>
</segment>
</net>
<net name="RC_INPUT" class="0">
<segment>
<pinref part="R20" gate="G$1" pin="2"/>
<wire x1="12.7" y1="124.46" x2="-2.54" y2="124.46" width="0.1524" layer="91"/>
<label x="-2.54" y="124.46" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="IC9" gate="G$1" pin="A"/>
<wire x1="20.32" y1="88.9" x2="-2.54" y2="88.9" width="0.1524" layer="91"/>
<label x="-2.54" y="88.9" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$14" class="0">
<segment>
<pinref part="J6" gate="G$1" pin="3"/>
<wire x1="27.94" y1="127" x2="27.94" y2="116.84" width="0.1524" layer="91"/>
<wire x1="27.94" y1="116.84" x2="22.86" y2="116.84" width="0.1524" layer="91"/>
<pinref part="R21" gate="G$1" pin="2"/>
</segment>
</net>
<net name="RSSI_IN" class="0">
<segment>
<wire x1="5.08" y1="116.84" x2="-2.54" y2="116.84" width="0.1524" layer="91"/>
<pinref part="R21" gate="G$1" pin="1"/>
<label x="-5.08" y="116.84" size="1.778" layer="95"/>
</segment>
</net>
<net name="VDD_3V3_SPEKTRUM" class="0">
<segment>
<pinref part="J6" gate="G$1" pin="4"/>
<wire x1="48.26" y1="132.08" x2="68.58" y2="132.08" width="0.1524" layer="91"/>
<label x="53.34" y="132.08" size="1.778" layer="95"/>
</segment>
</net>
<net name="GND" class="0">
<segment>
<pinref part="J6" gate="G$1" pin="5"/>
<wire x1="48.26" y1="129.54" x2="53.34" y2="129.54" width="0.1524" layer="91"/>
<wire x1="53.34" y1="129.54" x2="53.34" y2="127" width="0.1524" layer="91"/>
<pinref part="GND34" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="IC9" gate="G$1" pin="GND"/>
<wire x1="20.32" y1="83.82" x2="15.24" y2="83.82" width="0.1524" layer="91"/>
<wire x1="15.24" y1="83.82" x2="15.24" y2="81.28" width="0.1524" layer="91"/>
<pinref part="GND35" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="IC10" gate="G$1" pin="GND"/>
<wire x1="20.32" y1="50.8" x2="15.24" y2="50.8" width="0.1524" layer="91"/>
<wire x1="15.24" y1="50.8" x2="15.24" y2="48.26" width="0.1524" layer="91"/>
<pinref part="GND36" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="GND37" gate="1" pin="GND"/>
<pinref part="C37" gate="G$1" pin="1"/>
<wire x1="15.24" y1="27.94" x2="15.24" y2="25.4" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="J7" gate="G$1" pin="6"/>
<wire x1="43.18" y1="12.7" x2="45.72" y2="12.7" width="0.1524" layer="91"/>
<pinref part="GND38" gate="1" pin="GND"/>
<wire x1="45.72" y1="12.7" x2="45.72" y2="10.16" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="GND39" gate="1" pin="GND"/>
<pinref part="C38" gate="G$1" pin="1"/>
<wire x1="15.24" y1="-10.16" x2="15.24" y2="-12.7" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="J8" gate="G$1" pin="6"/>
<wire x1="43.18" y1="-25.4" x2="45.72" y2="-25.4" width="0.1524" layer="91"/>
<pinref part="GND40" gate="1" pin="GND"/>
<wire x1="45.72" y1="-25.4" x2="45.72" y2="-27.94" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="J9" gate="G$1" pin="6"/>
<wire x1="218.44" y1="144.78" x2="220.98" y2="144.78" width="0.1524" layer="91"/>
<wire x1="220.98" y1="144.78" x2="220.98" y2="142.24" width="0.1524" layer="91"/>
<pinref part="GND42" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="J11" gate="G$1" pin="1"/>
<wire x1="317.5" y1="180.34" x2="314.96" y2="180.34" width="0.1524" layer="91"/>
<wire x1="314.96" y1="180.34" x2="314.96" y2="177.8" width="0.1524" layer="91"/>
<pinref part="J11" gate="G$1" pin="6"/>
<wire x1="314.96" y1="177.8" x2="314.96" y2="175.26" width="0.1524" layer="91"/>
<wire x1="314.96" y1="175.26" x2="314.96" y2="172.72" width="0.1524" layer="91"/>
<wire x1="314.96" y1="172.72" x2="314.96" y2="170.18" width="0.1524" layer="91"/>
<wire x1="314.96" y1="170.18" x2="314.96" y2="167.64" width="0.1524" layer="91"/>
<wire x1="314.96" y1="167.64" x2="317.5" y2="167.64" width="0.1524" layer="91"/>
<pinref part="J11" gate="G$1" pin="5"/>
<wire x1="317.5" y1="170.18" x2="314.96" y2="170.18" width="0.1524" layer="91"/>
<junction x="314.96" y="170.18"/>
<pinref part="J11" gate="G$1" pin="4"/>
<wire x1="317.5" y1="172.72" x2="314.96" y2="172.72" width="0.1524" layer="91"/>
<junction x="314.96" y="172.72"/>
<pinref part="J11" gate="G$1" pin="3"/>
<wire x1="317.5" y1="175.26" x2="314.96" y2="175.26" width="0.1524" layer="91"/>
<junction x="314.96" y="175.26"/>
<pinref part="J11" gate="G$1" pin="2"/>
<wire x1="317.5" y1="177.8" x2="314.96" y2="177.8" width="0.1524" layer="91"/>
<junction x="314.96" y="177.8"/>
<pinref part="GND43" gate="1" pin="GND"/>
<junction x="314.96" y="167.64"/>
</segment>
<segment>
<pinref part="GND44" gate="1" pin="GND"/>
<pinref part="R40" gate="G$1" pin="2"/>
<wire x1="279.4" y1="109.22" x2="281.94" y2="109.22" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="C40" gate="G$1" pin="1"/>
<pinref part="GND45" gate="1" pin="GND"/>
<wire x1="294.64" y1="71.12" x2="294.64" y2="73.66" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="J14" gate="G$1" pin="4"/>
<wire x1="322.58" y1="58.42" x2="330.2" y2="58.42" width="0.1524" layer="91"/>
<wire x1="330.2" y1="58.42" x2="330.2" y2="55.88" width="0.1524" layer="91"/>
<pinref part="GND46" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="JP1" gate="A" pin="2"/>
<wire x1="307.34" y1="20.32" x2="314.96" y2="20.32" width="0.1524" layer="91"/>
<wire x1="314.96" y1="20.32" x2="314.96" y2="22.86" width="0.1524" layer="91"/>
<pinref part="GND47" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="C39" gate="G$1" pin="GROUND_1"/>
<wire x1="147.32" y1="170.18" x2="147.32" y2="175.26" width="0.1524" layer="91"/>
<wire x1="147.32" y1="175.26" x2="152.4" y2="175.26" width="0.1524" layer="91"/>
<wire x1="152.4" y1="175.26" x2="152.4" y2="121.92" width="0.1524" layer="91"/>
<pinref part="GND41" gate="1" pin="GND"/>
<wire x1="152.4" y1="121.92" x2="147.32" y2="121.92" width="0.1524" layer="91"/>
<pinref part="C39" gate="G$1" pin="GROUND_2"/>
<wire x1="147.32" y1="129.54" x2="147.32" y2="121.92" width="0.1524" layer="91"/>
<junction x="147.32" y="121.92"/>
</segment>
</net>
<net name="SBUS_INV" class="0">
<segment>
<pinref part="IC9" gate="G$1" pin="B"/>
<wire x1="20.32" y1="86.36" x2="-2.54" y2="86.36" width="0.1524" layer="91"/>
<label x="-2.54" y="86.36" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_VDD_3V3" class="0">
<segment>
<pinref part="IC9" gate="G$1" pin="VCC"/>
<wire x1="45.72" y1="86.36" x2="60.96" y2="86.36" width="0.1524" layer="91"/>
<label x="48.26" y="86.36" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="IC10" gate="G$1" pin="VCC"/>
<wire x1="45.72" y1="58.42" x2="63.5" y2="58.42" width="0.1524" layer="91"/>
<label x="53.34" y="58.42" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R33" gate="G$1" pin="1"/>
<pinref part="R32" gate="G$1" pin="1"/>
<wire x1="228.6" y1="129.54" x2="236.22" y2="129.54" width="0.1524" layer="91"/>
<wire x1="236.22" y1="129.54" x2="243.84" y2="129.54" width="0.1524" layer="91"/>
<junction x="236.22" y="129.54"/>
<label x="238.76" y="129.54" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="J13" gate="G$1" pin="3"/>
<wire x1="302.26" y1="96.52" x2="302.26" y2="88.9" width="0.1524" layer="91"/>
<wire x1="302.26" y1="88.9" x2="264.16" y2="88.9" width="0.1524" layer="91"/>
<label x="264.16" y="88.9" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_RC_INPUT" class="0">
<segment>
<pinref part="IC9" gate="G$1" pin="Y"/>
<wire x1="45.72" y1="88.9" x2="60.96" y2="88.9" width="0.1524" layer="91"/>
<label x="48.26" y="88.9" size="1.778" layer="95"/>
</segment>
</net>
<net name="FRSKY_INV" class="0">
<segment>
<wire x1="33.02" y1="63.5" x2="33.02" y2="45.72" width="0.1524" layer="91"/>
<wire x1="33.02" y1="45.72" x2="48.26" y2="45.72" width="0.1524" layer="91"/>
<wire x1="48.26" y1="45.72" x2="48.26" y2="50.8" width="0.1524" layer="91"/>
<pinref part="IC10" gate="G$1" pin="2A"/>
<wire x1="48.26" y1="50.8" x2="45.72" y2="50.8" width="0.1524" layer="91"/>
<wire x1="33.02" y1="63.5" x2="15.24" y2="63.5" width="0.1524" layer="91"/>
<pinref part="IC10" gate="G$1" pin="1A"/>
<wire x1="15.24" y1="63.5" x2="0" y2="63.5" width="0.1524" layer="91"/>
<wire x1="20.32" y1="58.42" x2="15.24" y2="58.42" width="0.1524" layer="91"/>
<wire x1="15.24" y1="58.42" x2="15.24" y2="63.5" width="0.1524" layer="91"/>
<junction x="15.24" y="63.5"/>
<label x="0" y="63.5" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_USART8_RX" class="0">
<segment>
<pinref part="IC10" gate="G$1" pin="2Y"/>
<wire x1="20.32" y1="53.34" x2="0" y2="53.34" width="0.1524" layer="91"/>
<label x="-5.08" y="53.34" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$21" class="0">
<segment>
<pinref part="IC10" gate="G$1" pin="1Y"/>
<wire x1="45.72" y1="55.88" x2="53.34" y2="55.88" width="0.1524" layer="91"/>
<wire x1="53.34" y1="55.88" x2="53.34" y2="53.34" width="0.1524" layer="91"/>
<pinref part="R22" gate="G$1" pin="1"/>
<wire x1="53.34" y1="53.34" x2="55.88" y2="53.34" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$22" class="0">
<segment>
<pinref part="IC10" gate="G$1" pin="2B"/>
<wire x1="45.72" y1="53.34" x2="50.8" y2="53.34" width="0.1524" layer="91"/>
<wire x1="50.8" y1="53.34" x2="50.8" y2="45.72" width="0.1524" layer="91"/>
<pinref part="R23" gate="G$1" pin="1"/>
<wire x1="50.8" y1="45.72" x2="55.88" y2="45.72" width="0.1524" layer="91"/>
</segment>
</net>
<net name="FRSKY_OUT" class="0">
<segment>
<pinref part="R22" gate="G$1" pin="2"/>
<wire x1="66.04" y1="53.34" x2="81.28" y2="53.34" width="0.1524" layer="91"/>
<label x="71.12" y="53.34" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="J14" gate="G$1" pin="2"/>
<wire x1="302.26" y1="58.42" x2="271.78" y2="58.42" width="0.1524" layer="91"/>
<label x="271.78" y="58.42" size="1.778" layer="95"/>
</segment>
</net>
<net name="FRSKY_IN" class="0">
<segment>
<pinref part="R23" gate="G$1" pin="2"/>
<wire x1="66.04" y1="45.72" x2="81.28" y2="45.72" width="0.1524" layer="91"/>
<label x="71.12" y="45.72" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="J14" gate="G$1" pin="3"/>
<wire x1="322.58" y1="60.96" x2="347.98" y2="60.96" width="0.1524" layer="91"/>
<label x="335.28" y="60.96" size="1.778" layer="95"/>
</segment>
</net>
<net name="VDD_5V_PERIPH" class="0">
<segment>
<pinref part="J7" gate="G$1" pin="1"/>
<wire x1="22.86" y1="17.78" x2="15.24" y2="17.78" width="0.1524" layer="91"/>
<pinref part="C37" gate="G$1" pin="2"/>
<wire x1="15.24" y1="17.78" x2="5.08" y2="17.78" width="0.1524" layer="91"/>
<junction x="15.24" y="17.78"/>
<label x="-7.62" y="17.78" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="J8" gate="G$1" pin="1"/>
<wire x1="22.86" y1="-20.32" x2="15.24" y2="-20.32" width="0.1524" layer="91"/>
<pinref part="C38" gate="G$1" pin="2"/>
<wire x1="15.24" y1="-20.32" x2="5.08" y2="-20.32" width="0.1524" layer="91"/>
<junction x="15.24" y="-20.32"/>
<label x="-7.62" y="-20.32" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="121.92" y1="149.86" x2="104.14" y2="149.86" width="0.1524" layer="91"/>
<label x="99.06" y="149.86" size="1.778" layer="95"/>
<pinref part="C39" gate="G$1" pin="SIGNAL/VCC_1"/>
</segment>
<segment>
<pinref part="J14" gate="G$1" pin="1"/>
<wire x1="302.26" y1="60.96" x2="294.64" y2="60.96" width="0.1524" layer="91"/>
<pinref part="C40" gate="G$1" pin="2"/>
<wire x1="294.64" y1="60.96" x2="294.64" y2="63.5" width="0.1524" layer="91"/>
<wire x1="294.64" y1="60.96" x2="271.78" y2="60.96" width="0.1524" layer="91"/>
<junction x="294.64" y="60.96"/>
<label x="271.78" y="60.96" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$15" class="0">
<segment>
<pinref part="J7" gate="G$1" pin="2"/>
<wire x1="22.86" y1="15.24" x2="15.24" y2="15.24" width="0.1524" layer="91"/>
<pinref part="R24" gate="G$1" pin="1"/>
<wire x1="15.24" y1="15.24" x2="15.24" y2="12.7" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$16" class="0">
<segment>
<pinref part="J7" gate="G$1" pin="3"/>
<wire x1="22.86" y1="12.7" x2="17.78" y2="12.7" width="0.1524" layer="91"/>
<wire x1="17.78" y1="12.7" x2="17.78" y2="5.08" width="0.1524" layer="91"/>
<pinref part="R25" gate="G$1" pin="1"/>
<wire x1="17.78" y1="5.08" x2="15.24" y2="5.08" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$23" class="0">
<segment>
<pinref part="J7" gate="G$1" pin="4"/>
<wire x1="43.18" y1="17.78" x2="53.34" y2="17.78" width="0.1524" layer="91"/>
<pinref part="R26" gate="G$1" pin="2"/>
</segment>
</net>
<net name="N$24" class="0">
<segment>
<pinref part="J7" gate="G$1" pin="5"/>
<wire x1="43.18" y1="15.24" x2="53.34" y2="15.24" width="0.1524" layer="91"/>
<pinref part="R27" gate="G$1" pin="2"/>
<wire x1="53.34" y1="15.24" x2="53.34" y2="10.16" width="0.1524" layer="91"/>
</segment>
</net>
<net name="FMU_USART3_CTS" class="0">
<segment>
<pinref part="R26" gate="G$1" pin="1"/>
<wire x1="63.5" y1="17.78" x2="73.66" y2="17.78" width="0.1524" layer="91"/>
<label x="68.58" y="17.78" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_USART3_RTS" class="0">
<segment>
<pinref part="R27" gate="G$1" pin="1"/>
<wire x1="63.5" y1="10.16" x2="73.66" y2="10.16" width="0.1524" layer="91"/>
<label x="68.58" y="10.16" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$27" class="0">
<segment>
<pinref part="J8" gate="G$1" pin="2"/>
<wire x1="22.86" y1="-22.86" x2="15.24" y2="-22.86" width="0.1524" layer="91"/>
<pinref part="R28" gate="G$1" pin="1"/>
<wire x1="15.24" y1="-22.86" x2="15.24" y2="-25.4" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$28" class="0">
<segment>
<pinref part="J8" gate="G$1" pin="3"/>
<wire x1="22.86" y1="-25.4" x2="17.78" y2="-25.4" width="0.1524" layer="91"/>
<wire x1="17.78" y1="-25.4" x2="17.78" y2="-33.02" width="0.1524" layer="91"/>
<pinref part="R29" gate="G$1" pin="1"/>
<wire x1="17.78" y1="-33.02" x2="15.24" y2="-33.02" width="0.1524" layer="91"/>
</segment>
</net>
<net name="FMU_USART2_TX" class="0">
<segment>
<pinref part="R28" gate="G$1" pin="2"/>
<wire x1="5.08" y1="-25.4" x2="-2.54" y2="-25.4" width="0.1524" layer="91"/>
<label x="-17.78" y="-25.4" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_USART2_RX" class="0">
<segment>
<pinref part="R29" gate="G$1" pin="2"/>
<wire x1="5.08" y1="-33.02" x2="-2.54" y2="-33.02" width="0.1524" layer="91"/>
<label x="-17.78" y="-33.02" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$31" class="0">
<segment>
<pinref part="J8" gate="G$1" pin="4"/>
<wire x1="43.18" y1="-20.32" x2="53.34" y2="-20.32" width="0.1524" layer="91"/>
<pinref part="R30" gate="G$1" pin="2"/>
</segment>
</net>
<net name="N$32" class="0">
<segment>
<pinref part="J8" gate="G$1" pin="5"/>
<wire x1="43.18" y1="-22.86" x2="53.34" y2="-22.86" width="0.1524" layer="91"/>
<pinref part="R31" gate="G$1" pin="2"/>
<wire x1="53.34" y1="-22.86" x2="53.34" y2="-27.94" width="0.1524" layer="91"/>
</segment>
</net>
<net name="FMU_USART2_CTS" class="0">
<segment>
<pinref part="R30" gate="G$1" pin="1"/>
<wire x1="63.5" y1="-20.32" x2="73.66" y2="-20.32" width="0.1524" layer="91"/>
<label x="68.58" y="-20.32" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_USART8_TX" class="0">
<segment>
<pinref part="IC10" gate="G$1" pin="1B"/>
<wire x1="20.32" y1="55.88" x2="0" y2="55.88" width="0.1524" layer="91"/>
<label x="-5.08" y="55.88" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_USART3_TX" class="0">
<segment>
<pinref part="R24" gate="G$1" pin="2"/>
<wire x1="5.08" y1="12.7" x2="-2.54" y2="12.7" width="0.1524" layer="91"/>
<label x="-15.24" y="12.7" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_USART3_RX" class="0">
<segment>
<pinref part="R25" gate="G$1" pin="2"/>
<wire x1="5.08" y1="5.08" x2="-2.54" y2="5.08" width="0.1524" layer="91"/>
<label x="-15.24" y="5.08" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_USART2_RTS" class="0">
<segment>
<pinref part="R31" gate="G$1" pin="1"/>
<wire x1="63.5" y1="-27.94" x2="73.66" y2="-27.94" width="0.1524" layer="91"/>
<label x="68.58" y="-27.94" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$10" class="0">
<segment>
<pinref part="J9" gate="G$1" pin="1"/>
<wire x1="198.12" y1="149.86" x2="172.72" y2="149.86" width="0.1524" layer="91"/>
<pinref part="C39" gate="G$1" pin="SIGNAL/VCC_2"/>
</segment>
</net>
<net name="FMU_USART4_TX" class="0">
<segment>
<pinref part="J9" gate="G$1" pin="2"/>
<wire x1="198.12" y1="147.32" x2="177.8" y2="147.32" width="0.1524" layer="91"/>
<label x="175.26" y="147.32" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_USART4_RX" class="0">
<segment>
<pinref part="J9" gate="G$1" pin="3"/>
<wire x1="198.12" y1="144.78" x2="177.8" y2="144.78" width="0.1524" layer="91"/>
<label x="175.26" y="144.78" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_I2C1_SCL" class="0">
<segment>
<pinref part="J9" gate="G$1" pin="4"/>
<wire x1="218.44" y1="149.86" x2="236.22" y2="149.86" width="0.1524" layer="91"/>
<wire x1="236.22" y1="149.86" x2="236.22" y2="139.7" width="0.1524" layer="91"/>
<junction x="236.22" y="149.86"/>
<pinref part="R32" gate="G$1" pin="2"/>
<wire x1="236.22" y1="149.86" x2="243.84" y2="149.86" width="0.1524" layer="91"/>
<label x="238.76" y="149.86" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_I2C1_SDA" class="0">
<segment>
<pinref part="J9" gate="G$1" pin="5"/>
<wire x1="218.44" y1="147.32" x2="228.6" y2="147.32" width="0.1524" layer="91"/>
<wire x1="228.6" y1="147.32" x2="243.84" y2="147.32" width="0.1524" layer="91"/>
<wire x1="228.6" y1="147.32" x2="228.6" y2="139.7" width="0.1524" layer="91"/>
<junction x="228.6" y="147.32"/>
<pinref part="R33" gate="G$1" pin="2"/>
<label x="238.76" y="147.32" size="1.778" layer="95"/>
</segment>
</net>
<net name="VDD_SERVO" class="0">
<segment>
<pinref part="J10" gate="G$1" pin="1"/>
<wire x1="289.56" y1="180.34" x2="287.02" y2="180.34" width="0.1524" layer="91"/>
<wire x1="287.02" y1="180.34" x2="287.02" y2="177.8" width="0.1524" layer="91"/>
<pinref part="J10" gate="G$1" pin="6"/>
<wire x1="287.02" y1="177.8" x2="287.02" y2="175.26" width="0.1524" layer="91"/>
<wire x1="287.02" y1="175.26" x2="287.02" y2="172.72" width="0.1524" layer="91"/>
<wire x1="287.02" y1="172.72" x2="287.02" y2="170.18" width="0.1524" layer="91"/>
<wire x1="287.02" y1="170.18" x2="287.02" y2="167.64" width="0.1524" layer="91"/>
<wire x1="287.02" y1="167.64" x2="289.56" y2="167.64" width="0.1524" layer="91"/>
<pinref part="J10" gate="G$1" pin="2"/>
<wire x1="289.56" y1="177.8" x2="287.02" y2="177.8" width="0.1524" layer="91"/>
<junction x="287.02" y="177.8"/>
<pinref part="J10" gate="G$1" pin="3"/>
<wire x1="289.56" y1="175.26" x2="287.02" y2="175.26" width="0.1524" layer="91"/>
<junction x="287.02" y="175.26"/>
<pinref part="J10" gate="G$1" pin="4"/>
<wire x1="289.56" y1="172.72" x2="287.02" y2="172.72" width="0.1524" layer="91"/>
<junction x="287.02" y="172.72"/>
<pinref part="J10" gate="G$1" pin="5"/>
<wire x1="289.56" y1="170.18" x2="287.02" y2="170.18" width="0.1524" layer="91"/>
<junction x="287.02" y="170.18"/>
<label x="284.48" y="167.64" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="N$13" class="0">
<segment>
<pinref part="J12" gate="G$1" pin="1"/>
<pinref part="R34" gate="G$1" pin="1"/>
<wire x1="317.5" y1="147.32" x2="309.88" y2="147.32" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$18" class="0">
<segment>
<pinref part="J12" gate="G$1" pin="2"/>
<pinref part="R35" gate="G$1" pin="1"/>
<wire x1="317.5" y1="144.78" x2="309.88" y2="144.78" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$20" class="0">
<segment>
<pinref part="J12" gate="G$1" pin="3"/>
<pinref part="R36" gate="G$1" pin="1"/>
<wire x1="317.5" y1="142.24" x2="309.88" y2="142.24" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$25" class="0">
<segment>
<pinref part="J12" gate="G$1" pin="4"/>
<pinref part="R37" gate="G$1" pin="1"/>
<wire x1="317.5" y1="139.7" x2="309.88" y2="139.7" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$26" class="0">
<segment>
<pinref part="J12" gate="G$1" pin="5"/>
<pinref part="R38" gate="G$1" pin="1"/>
<wire x1="317.5" y1="137.16" x2="309.88" y2="137.16" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$29" class="0">
<segment>
<pinref part="J12" gate="G$1" pin="6"/>
<pinref part="R39" gate="G$1" pin="1"/>
<wire x1="317.5" y1="134.62" x2="309.88" y2="134.62" width="0.1524" layer="91"/>
</segment>
</net>
<net name="FMU_CH2" class="0">
<segment>
<pinref part="R35" gate="G$1" pin="2"/>
<wire x1="299.72" y1="144.78" x2="287.02" y2="144.78" width="0.1524" layer="91"/>
<label x="287.02" y="144.78" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_CH3" class="0">
<segment>
<pinref part="R36" gate="G$1" pin="2"/>
<wire x1="299.72" y1="142.24" x2="287.02" y2="142.24" width="0.1524" layer="91"/>
<label x="287.02" y="142.24" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_CH4" class="0">
<segment>
<pinref part="R37" gate="G$1" pin="2"/>
<wire x1="299.72" y1="139.7" x2="287.02" y2="139.7" width="0.1524" layer="91"/>
<label x="287.02" y="139.7" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_CH6" class="0">
<segment>
<pinref part="R39" gate="G$1" pin="2"/>
<wire x1="299.72" y1="134.62" x2="287.02" y2="134.62" width="0.1524" layer="91"/>
<label x="287.02" y="134.62" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_CH1" class="0">
<segment>
<pinref part="R34" gate="G$1" pin="2"/>
<wire x1="299.72" y1="147.32" x2="287.02" y2="147.32" width="0.1524" layer="91"/>
<label x="287.02" y="147.32" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_CH5" class="0">
<segment>
<pinref part="R38" gate="G$1" pin="2"/>
<wire x1="299.72" y1="137.16" x2="287.02" y2="137.16" width="0.1524" layer="91"/>
<label x="287.02" y="137.16" size="1.778" layer="95"/>
</segment>
</net>
<net name="SAFETY_SWITCH_IN" class="0">
<segment>
<pinref part="J13" gate="G$1" pin="1"/>
<wire x1="302.26" y1="101.6" x2="292.1" y2="101.6" width="0.1524" layer="91"/>
<pinref part="R40" gate="G$1" pin="1"/>
<wire x1="292.1" y1="101.6" x2="264.16" y2="101.6" width="0.1524" layer="91"/>
<wire x1="292.1" y1="109.22" x2="292.1" y2="101.6" width="0.1524" layer="91"/>
<junction x="292.1" y="101.6"/>
<label x="264.16" y="101.6" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$33" class="0">
<segment>
<pinref part="R41" gate="G$1" pin="2"/>
<wire x1="289.56" y1="96.52" x2="292.1" y2="96.52" width="0.1524" layer="91"/>
<wire x1="292.1" y1="96.52" x2="292.1" y2="99.06" width="0.1524" layer="91"/>
<pinref part="J13" gate="G$1" pin="2"/>
<wire x1="292.1" y1="99.06" x2="302.26" y2="99.06" width="0.1524" layer="91"/>
</segment>
</net>
<net name="LED_SAFETY" class="0">
<segment>
<pinref part="R41" gate="G$1" pin="1"/>
<wire x1="279.4" y1="96.52" x2="264.16" y2="96.52" width="0.1524" layer="91"/>
<label x="264.16" y="96.52" size="1.778" layer="95"/>
</segment>
</net>
<net name="BUZZER-" class="0">
<segment>
<pinref part="J13" gate="G$1" pin="4"/>
<wire x1="322.58" y1="101.6" x2="342.9" y2="101.6" width="0.1524" layer="91"/>
<label x="332.74" y="101.6" size="1.778" layer="95"/>
</segment>
</net>
<net name="BUZZER+" class="0">
<segment>
<pinref part="J13" gate="G$1" pin="5"/>
<wire x1="322.58" y1="99.06" x2="342.9" y2="99.06" width="0.1524" layer="91"/>
<label x="332.74" y="99.06" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_USART_RX" class="0">
<segment>
<pinref part="JP1" gate="A" pin="1"/>
<wire x1="299.72" y1="20.32" x2="281.94" y2="20.32" width="0.1524" layer="91"/>
<label x="274.32" y="20.32" size="1.778" layer="95"/>
</segment>
</net>
<net name="8266_PD" class="0">
<segment>
<pinref part="JP1" gate="A" pin="3"/>
<wire x1="299.72" y1="17.78" x2="281.94" y2="17.78" width="0.1524" layer="91"/>
<label x="274.32" y="17.78" size="1.778" layer="95"/>
</segment>
</net>
<net name="8266_GPIO2" class="0">
<segment>
<pinref part="JP1" gate="A" pin="4"/>
<wire x1="307.34" y1="17.78" x2="327.66" y2="17.78" width="0.1524" layer="91"/>
<label x="320.04" y="17.78" size="1.778" layer="95"/>
</segment>
</net>
<net name="8266_RTS" class="0">
<segment>
<pinref part="JP1" gate="A" pin="5"/>
<wire x1="299.72" y1="15.24" x2="281.94" y2="15.24" width="0.1524" layer="91"/>
<label x="274.32" y="15.24" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="JP1" gate="A" pin="9"/>
<wire x1="299.72" y1="10.16" x2="281.94" y2="10.16" width="0.1524" layer="91"/>
<label x="274.32" y="10.16" size="1.778" layer="95"/>
</segment>
</net>
<net name="8266_GPIO0" class="0">
<segment>
<pinref part="JP1" gate="A" pin="6"/>
<wire x1="307.34" y1="15.24" x2="327.66" y2="15.24" width="0.1524" layer="91"/>
<label x="320.04" y="15.24" size="1.778" layer="95"/>
</segment>
</net>
<net name="VDD_3V3_PERIPH" class="0">
<segment>
<pinref part="JP1" gate="A" pin="7"/>
<wire x1="299.72" y1="12.7" x2="281.94" y2="12.7" width="0.1524" layer="91"/>
<label x="274.32" y="12.7" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_USART1_TX" class="0">
<segment>
<pinref part="JP1" gate="A" pin="8"/>
<wire x1="307.34" y1="12.7" x2="327.66" y2="12.7" width="0.1524" layer="91"/>
<label x="320.04" y="12.7" size="1.778" layer="95"/>
</segment>
</net>
<net name="8266_CTS" class="0">
<segment>
<pinref part="JP1" gate="A" pin="10"/>
<wire x1="307.34" y1="10.16" x2="327.66" y2="10.16" width="0.1524" layer="91"/>
<label x="320.04" y="10.16" size="1.778" layer="95"/>
</segment>
</net>
</nets>
</sheet>
<sheet>
<plain>
</plain>
<instances>
<instance part="R42" gate="G$1" x="17.78" y="81.28" smashed="yes" rot="R270">
<attribute name="NAME" x="24.13" y="67.31" size="1.778" layer="95" rot="R270" align="center-left"/>
<attribute name="VALUE" x="21.59" y="67.31" size="1.778" layer="96" rot="R270" align="center-left"/>
</instance>
<instance part="R43" gate="G$1" x="30.48" y="73.66" smashed="yes" rot="R90">
<attribute name="NAME" x="28.956" y="73.66" size="1.778" layer="95" font="vector" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="32.004" y="73.66" size="1.778" layer="96" font="vector" rot="R90" align="top-center"/>
</instance>
<instance part="GND48" gate="1" x="30.48" y="58.42" smashed="yes">
<attribute name="VALUE" x="27.94" y="55.88" size="1.778" layer="96"/>
</instance>
<instance part="D2" gate="G$1" x="45.72" y="88.9" smashed="yes">
<attribute name="NAME" x="57.15" y="96.52" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="46.99" y="93.98" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="F1" gate="F1" x="22.86" y="30.48" smashed="yes">
<attribute name="NAME" x="24.765" y="33.655" size="1.778" layer="95" font="vector" align="bottom-center"/>
<attribute name="VALUE" x="24.13" y="27.686" size="1.778" layer="96" font="vector" align="top-center"/>
</instance>
<instance part="C41" gate="G$1" x="40.64" y="17.78" smashed="yes">
<attribute name="NAME" x="41.656" y="18.415" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="41.656" y="13.589" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="GND49" gate="1" x="40.64" y="7.62" smashed="yes">
<attribute name="VALUE" x="38.1" y="5.08" size="1.778" layer="96"/>
</instance>
<instance part="R44" gate="G$1" x="55.88" y="35.56" smashed="yes" rot="R90">
<attribute name="NAME" x="54.356" y="35.56" size="1.778" layer="95" font="vector" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="57.404" y="35.56" size="1.778" layer="96" font="vector" rot="R90" align="top-center"/>
</instance>
<instance part="R45" gate="G$1" x="55.88" y="20.32" smashed="yes" rot="R90">
<attribute name="NAME" x="54.356" y="20.32" size="1.778" layer="95" font="vector" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="57.404" y="20.32" size="1.778" layer="96" font="vector" rot="R90" align="top-center"/>
</instance>
<instance part="D3" gate="G$1" x="76.2" y="78.74" smashed="yes" rot="R90">
<attribute name="NAME" x="74.168" y="76.2" size="1.778" layer="95" font="vector" rot="R90"/>
<attribute name="VALUE" x="78.232" y="76.2" size="1.778" layer="96" font="vector" rot="R90" align="top-left"/>
</instance>
<instance part="GND50" gate="1" x="76.2" y="71.12" smashed="yes">
<attribute name="VALUE" x="73.66" y="68.58" size="1.778" layer="96"/>
</instance>
<instance part="LED1" gate="G$1" x="93.98" y="71.12" smashed="yes" rot="R90">
<attribute name="NAME" x="85.09" y="73.66" size="1.778" layer="95" rot="R90"/>
<attribute name="VALUE" x="87.63" y="68.58" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="R46" gate="G$1" x="93.98" y="60.96" smashed="yes" rot="R90">
<attribute name="NAME" x="92.456" y="60.96" size="1.778" layer="95" font="vector" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="95.504" y="60.96" size="1.778" layer="96" font="vector" rot="R90" align="top-center"/>
</instance>
<instance part="GND51" gate="1" x="93.98" y="50.8" smashed="yes">
<attribute name="VALUE" x="91.44" y="48.26" size="1.778" layer="96"/>
</instance>
<instance part="C42" gate="G$1" x="104.14" y="73.66" smashed="yes">
<attribute name="NAME" x="105.156" y="74.295" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="105.156" y="69.469" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="D4" gate="G$1" x="127" y="104.14" smashed="yes" rot="R180">
<attribute name="NAME" x="116.84" y="97.79" size="1.778" layer="95" rot="R180" align="center-left"/>
<attribute name="VALUE" x="127" y="100.33" size="1.778" layer="96" rot="R180" align="center-left"/>
</instance>
<instance part="F2" gate="F1" x="137.16" y="104.14" smashed="yes">
<attribute name="NAME" x="139.065" y="107.315" size="1.778" layer="95" font="vector" align="bottom-center"/>
<attribute name="VALUE" x="138.43" y="101.346" size="1.778" layer="96" font="vector" align="top-center"/>
</instance>
<instance part="F3" gate="G$1" x="132.08" y="88.9" smashed="yes">
<attribute name="NAME" x="138.43" y="95.25" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="133.35" y="92.71" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="R47" gate="G$1" x="12.7" y="-20.32" smashed="yes">
<attribute name="NAME" x="12.7" y="-18.796" size="1.778" layer="95" font="vector" align="bottom-center"/>
<attribute name="VALUE" x="12.7" y="-21.844" size="1.778" layer="96" font="vector" align="top-center"/>
</instance>
<instance part="R48" gate="G$1" x="2.54" y="-53.34" smashed="yes">
<attribute name="NAME" x="8.89" y="-46.99" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="6.35" y="-49.53" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="R49" gate="G$1" x="25.4" y="-63.5" smashed="yes">
<attribute name="NAME" x="31.75" y="-57.15" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="26.67" y="-59.69" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="D5" gate="G$1" x="53.34" y="-20.32" smashed="yes" rot="R270">
<attribute name="NAME" x="58.42" y="-24.13" size="1.778" layer="95" rot="R270" align="center-left"/>
<attribute name="VALUE" x="60.96" y="-21.59" size="1.778" layer="96" rot="R270" align="center-left"/>
</instance>
<instance part="LED2" gate="G$1" x="254" y="114.3" smashed="yes" rot="R270">
<attribute name="NAME" x="243.84" y="105.41" size="1.778" layer="95" rot="R270" align="center-left"/>
<attribute name="VALUE" x="246.38" y="105.41" size="1.778" layer="96" rot="R270" align="center-left"/>
</instance>
<instance part="R50" gate="G$1" x="266.7" y="68.58" smashed="yes" rot="R90">
<attribute name="NAME" x="265.176" y="68.58" size="1.778" layer="95" font="vector" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="268.224" y="68.58" size="1.778" layer="96" font="vector" rot="R90" align="top-center"/>
</instance>
<instance part="R51" gate="G$1" x="254" y="68.58" smashed="yes" rot="R90">
<attribute name="NAME" x="252.476" y="68.58" size="1.778" layer="95" font="vector" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="255.524" y="68.58" size="1.778" layer="96" font="vector" rot="R90" align="top-center"/>
</instance>
<instance part="R52" gate="G$1" x="241.3" y="68.58" smashed="yes" rot="R90">
<attribute name="NAME" x="239.776" y="68.58" size="1.778" layer="95" font="vector" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="242.824" y="68.58" size="1.778" layer="96" font="vector" rot="R90" align="top-center"/>
</instance>
<instance part="IC11" gate="G$1" x="223.52" y="-7.62" smashed="yes">
<attribute name="NAME" x="245.11" y="0" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="245.11" y="-2.54" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="R53" gate="G$1" x="198.12" y="-22.86" smashed="yes" rot="R270">
<attribute name="NAME" x="204.47" y="-36.83" size="1.778" layer="95" rot="R270" align="center-left"/>
<attribute name="VALUE" x="201.93" y="-36.83" size="1.778" layer="96" rot="R270" align="center-left"/>
</instance>
<instance part="C43" gate="G$1" x="213.36" y="-33.02" smashed="yes">
<attribute name="NAME" x="214.884" y="-30.099" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="214.884" y="-35.179" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="C44" gate="G$1" x="254" y="-30.48" smashed="yes">
<attribute name="NAME" x="255.016" y="-29.845" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="255.016" y="-34.671" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="C45" gate="G$1" x="269.24" y="-33.02" smashed="yes">
<attribute name="NAME" x="270.764" y="-30.099" size="1.778" layer="95" font="vector"/>
<attribute name="VALUE" x="270.764" y="-35.179" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="GND52" gate="1" x="233.68" y="-45.72" smashed="yes">
<attribute name="VALUE" x="231.14" y="-48.26" size="1.778" layer="96"/>
</instance>
<instance part="Q1" gate="G$1" x="45.72" y="-53.34" smashed="yes">
<attribute name="NAME" x="57.15" y="-49.53" size="1.778" layer="95" align="center-left"/>
<attribute name="VALUE" x="57.15" y="-52.07" size="1.778" layer="96" align="center-left"/>
</instance>
<instance part="Q2" gate="G$1" x="281.94" y="-17.78" smashed="yes" rot="MR90">
<attribute name="NAME" x="285.75" y="-6.35" size="1.778" layer="95" rot="MR90" align="center-left"/>
<attribute name="VALUE" x="283.21" y="-6.35" size="1.778" layer="96" rot="MR90" align="center-left"/>
</instance>
</instances>
<busses>
</busses>
<nets>
<net name="GND" class="0">
<segment>
<pinref part="GND48" gate="1" pin="GND"/>
<pinref part="R43" gate="G$1" pin="1"/>
<wire x1="30.48" y1="60.96" x2="30.48" y2="68.58" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="GND49" gate="1" pin="GND"/>
<pinref part="C41" gate="G$1" pin="-"/>
<wire x1="40.64" y1="10.16" x2="40.64" y2="12.7" width="0.1524" layer="91"/>
<pinref part="R45" gate="G$1" pin="1"/>
<wire x1="55.88" y1="15.24" x2="55.88" y2="10.16" width="0.1524" layer="91"/>
<wire x1="55.88" y1="10.16" x2="40.64" y2="10.16" width="0.1524" layer="91"/>
<junction x="40.64" y="10.16"/>
</segment>
<segment>
<pinref part="D3" gate="G$1" pin="A"/>
<wire x1="76.2" y1="76.2" x2="76.2" y2="73.66" width="0.1524" layer="91"/>
<pinref part="GND50" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="R46" gate="G$1" pin="1"/>
<pinref part="GND51" gate="1" pin="GND"/>
<wire x1="93.98" y1="55.88" x2="93.98" y2="53.34" width="0.1524" layer="91"/>
<wire x1="93.98" y1="53.34" x2="104.14" y2="53.34" width="0.1524" layer="91"/>
<junction x="93.98" y="53.34"/>
<pinref part="C42" gate="G$1" pin="-"/>
<wire x1="104.14" y1="53.34" x2="104.14" y2="68.58" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC11" gate="G$1" pin="GND"/>
<wire x1="223.52" y1="-10.16" x2="218.44" y2="-10.16" width="0.1524" layer="91"/>
<wire x1="218.44" y1="-10.16" x2="218.44" y2="-22.86" width="0.1524" layer="91"/>
<wire x1="218.44" y1="-22.86" x2="233.68" y2="-22.86" width="0.1524" layer="91"/>
<wire x1="233.68" y1="-22.86" x2="233.68" y2="-43.18" width="0.1524" layer="91"/>
<pinref part="R53" gate="G$1" pin="2"/>
<wire x1="198.12" y1="-40.64" x2="198.12" y2="-43.18" width="0.1524" layer="91"/>
<wire x1="198.12" y1="-43.18" x2="213.36" y2="-43.18" width="0.1524" layer="91"/>
<pinref part="C43" gate="G$1" pin="2"/>
<wire x1="213.36" y1="-43.18" x2="233.68" y2="-43.18" width="0.1524" layer="91"/>
<wire x1="213.36" y1="-35.56" x2="213.36" y2="-43.18" width="0.1524" layer="91"/>
<junction x="213.36" y="-43.18"/>
<pinref part="C45" gate="G$1" pin="2"/>
<wire x1="269.24" y1="-35.56" x2="269.24" y2="-43.18" width="0.1524" layer="91"/>
<wire x1="269.24" y1="-43.18" x2="254" y2="-43.18" width="0.1524" layer="91"/>
<junction x="233.68" y="-43.18"/>
<pinref part="C44" gate="G$1" pin="-"/>
<wire x1="254" y1="-43.18" x2="233.68" y2="-43.18" width="0.1524" layer="91"/>
<wire x1="254" y1="-35.56" x2="254" y2="-43.18" width="0.1524" layer="91"/>
<junction x="254" y="-43.18"/>
<pinref part="GND52" gate="1" pin="GND"/>
</segment>
</net>
<net name="VBUS" class="0">
<segment>
<pinref part="R43" gate="G$1" pin="2"/>
<wire x1="30.48" y1="78.74" x2="30.48" y2="86.36" width="0.1524" layer="91"/>
<wire x1="30.48" y1="86.36" x2="17.78" y2="86.36" width="0.1524" layer="91"/>
<pinref part="R42" gate="G$1" pin="1"/>
<wire x1="17.78" y1="86.36" x2="-7.62" y2="86.36" width="0.1524" layer="91"/>
<wire x1="17.78" y1="81.28" x2="17.78" y2="86.36" width="0.1524" layer="91"/>
<junction x="17.78" y="86.36"/>
<pinref part="D2" gate="G$1" pin="A2"/>
<wire x1="30.48" y1="86.36" x2="45.72" y2="86.36" width="0.1524" layer="91"/>
<junction x="30.48" y="86.36"/>
<label x="-7.62" y="86.36" size="1.778" layer="95"/>
</segment>
</net>
<net name="VBUS_VALID" class="0">
<segment>
<pinref part="R42" gate="G$1" pin="2"/>
<wire x1="17.78" y1="63.5" x2="-7.62" y2="63.5" width="0.1524" layer="91"/>
<label x="-7.62" y="63.5" size="1.778" layer="95"/>
</segment>
</net>
<net name="VDD_5V_BRICK" class="0">
<segment>
<pinref part="F1" gate="F1" pin="1"/>
<wire x1="17.78" y1="30.48" x2="-7.62" y2="30.48" width="0.1524" layer="91"/>
<label x="-7.62" y="30.48" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$36" class="0">
<segment>
<pinref part="F1" gate="F1" pin="2"/>
<wire x1="30.48" y1="30.48" x2="40.64" y2="30.48" width="0.1524" layer="91"/>
<pinref part="C41" gate="G$1" pin="+"/>
<wire x1="40.64" y1="30.48" x2="40.64" y2="20.32" width="0.1524" layer="91"/>
<wire x1="40.64" y1="45.72" x2="40.64" y2="30.48" width="0.1524" layer="91"/>
<junction x="40.64" y="30.48"/>
<wire x1="40.64" y1="45.72" x2="55.88" y2="45.72" width="0.1524" layer="91"/>
<pinref part="R44" gate="G$1" pin="2"/>
<wire x1="55.88" y1="45.72" x2="55.88" y2="40.64" width="0.1524" layer="91"/>
<pinref part="D2" gate="G$1" pin="A1"/>
<wire x1="45.72" y1="88.9" x2="40.64" y2="88.9" width="0.1524" layer="91"/>
<wire x1="40.64" y1="88.9" x2="40.64" y2="45.72" width="0.1524" layer="91"/>
<junction x="40.64" y="45.72"/>
</segment>
</net>
<net name="VDD_BRICK_VALID" class="0">
<segment>
<pinref part="R45" gate="G$1" pin="2"/>
<pinref part="R44" gate="G$1" pin="1"/>
<wire x1="55.88" y1="25.4" x2="55.88" y2="27.94" width="0.1524" layer="91"/>
<wire x1="55.88" y1="27.94" x2="55.88" y2="30.48" width="0.1524" layer="91"/>
<wire x1="55.88" y1="27.94" x2="73.66" y2="27.94" width="0.1524" layer="91"/>
<junction x="55.88" y="27.94"/>
<label x="63.5" y="27.94" size="1.778" layer="95"/>
</segment>
</net>
<net name="VDD_5V_IN" class="0">
<segment>
<pinref part="D2" gate="G$1" pin="K_1"/>
<wire x1="71.12" y1="88.9" x2="76.2" y2="88.9" width="0.1524" layer="91"/>
<pinref part="D3" gate="G$1" pin="C"/>
<wire x1="76.2" y1="88.9" x2="76.2" y2="81.28" width="0.1524" layer="91"/>
<wire x1="76.2" y1="88.9" x2="93.98" y2="88.9" width="0.1524" layer="91"/>
<junction x="76.2" y="88.9"/>
<pinref part="LED1" gate="G$1" pin="A"/>
<wire x1="93.98" y1="88.9" x2="93.98" y2="86.36" width="0.1524" layer="91"/>
<wire x1="93.98" y1="88.9" x2="104.14" y2="88.9" width="0.1524" layer="91"/>
<junction x="93.98" y="88.9"/>
<pinref part="C42" gate="G$1" pin="+"/>
<wire x1="104.14" y1="88.9" x2="104.14" y2="76.2" width="0.1524" layer="91"/>
<wire x1="104.14" y1="88.9" x2="104.14" y2="104.14" width="0.1524" layer="91"/>
<junction x="104.14" y="88.9"/>
<pinref part="D4" gate="G$1" pin="A"/>
<wire x1="104.14" y1="104.14" x2="109.22" y2="104.14" width="0.1524" layer="91"/>
<wire x1="104.14" y1="88.9" x2="132.08" y2="88.9" width="0.1524" layer="91"/>
<pinref part="F3" gate="G$1" pin="1"/>
<label x="78.74" y="88.9" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R47" gate="G$1" pin="1"/>
<wire x1="7.62" y1="-20.32" x2="-7.62" y2="-20.32" width="0.1524" layer="91"/>
<label x="-7.62" y="-20.32" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C43" gate="G$1" pin="1"/>
<wire x1="213.36" y1="-27.94" x2="213.36" y2="-7.62" width="0.1524" layer="91"/>
<pinref part="IC11" gate="G$1" pin="IN"/>
<wire x1="213.36" y1="-7.62" x2="223.52" y2="-7.62" width="0.1524" layer="91"/>
<wire x1="213.36" y1="-7.62" x2="180.34" y2="-7.62" width="0.1524" layer="91"/>
<junction x="213.36" y="-7.62"/>
<label x="180.34" y="-7.62" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$37" class="0">
<segment>
<pinref part="LED1" gate="G$1" pin="K"/>
<pinref part="R46" gate="G$1" pin="2"/>
<wire x1="93.98" y1="71.12" x2="93.98" y2="66.04" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$40" class="0">
<segment>
<pinref part="D4" gate="G$1" pin="K"/>
<pinref part="F2" gate="F1" pin="1"/>
<wire x1="124.46" y1="104.14" x2="132.08" y2="104.14" width="0.1524" layer="91"/>
</segment>
</net>
<net name="VDD_5V_RECEIVER" class="0">
<segment>
<pinref part="F2" gate="F1" pin="2"/>
<wire x1="144.78" y1="104.14" x2="162.56" y2="104.14" width="0.1524" layer="91"/>
<label x="149.86" y="104.14" size="1.778" layer="95"/>
</segment>
</net>
<net name="VDD_5V_PERIPH" class="0">
<segment>
<pinref part="F3" gate="G$1" pin="2"/>
<wire x1="149.86" y1="88.9" x2="167.64" y2="88.9" width="0.1524" layer="91"/>
<label x="154.94" y="88.9" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$30" class="0">
<segment>
<pinref part="R48" gate="G$1" pin="2"/>
<wire x1="20.32" y1="-53.34" x2="22.86" y2="-53.34" width="0.1524" layer="91"/>
<pinref part="R49" gate="G$1" pin="1"/>
<wire x1="22.86" y1="-53.34" x2="45.72" y2="-53.34" width="0.1524" layer="91"/>
<wire x1="25.4" y1="-63.5" x2="22.86" y2="-63.5" width="0.1524" layer="91"/>
<wire x1="22.86" y1="-63.5" x2="22.86" y2="-53.34" width="0.1524" layer="91"/>
<junction x="22.86" y="-53.34"/>
<pinref part="Q1" gate="G$1" pin="G"/>
</segment>
</net>
<net name="N$34" class="0">
<segment>
<pinref part="R49" gate="G$1" pin="2"/>
<wire x1="53.34" y1="-58.42" x2="53.34" y2="-63.5" width="0.1524" layer="91"/>
<wire x1="53.34" y1="-63.5" x2="43.18" y2="-63.5" width="0.1524" layer="91"/>
<pinref part="Q1" gate="G$1" pin="S"/>
</segment>
</net>
<net name="BUZZER-" class="0">
<segment>
<pinref part="D5" gate="G$1" pin="A"/>
<wire x1="53.34" y1="-43.18" x2="53.34" y2="-40.64" width="0.1524" layer="91"/>
<wire x1="53.34" y1="-40.64" x2="53.34" y2="-35.56" width="0.1524" layer="91"/>
<wire x1="53.34" y1="-40.64" x2="76.2" y2="-40.64" width="0.1524" layer="91"/>
<junction x="53.34" y="-40.64"/>
<label x="68.58" y="-40.64" size="1.778" layer="95"/>
<pinref part="Q1" gate="G$1" pin="D"/>
</segment>
</net>
<net name="BUZZER+" class="0">
<segment>
<pinref part="R47" gate="G$1" pin="2"/>
<pinref part="D5" gate="G$1" pin="K"/>
<wire x1="17.78" y1="-20.32" x2="53.34" y2="-20.32" width="0.1524" layer="91"/>
<wire x1="53.34" y1="-20.32" x2="76.2" y2="-20.32" width="0.1524" layer="91"/>
<junction x="53.34" y="-20.32"/>
<label x="68.58" y="-20.32" size="1.778" layer="95"/>
</segment>
</net>
<net name="ALARM" class="0">
<segment>
<pinref part="R48" gate="G$1" pin="1"/>
<wire x1="2.54" y1="-53.34" x2="-7.62" y2="-53.34" width="0.1524" layer="91"/>
<label x="-7.62" y="-53.34" size="1.778" layer="95"/>
</segment>
</net>
<net name="FMU_VDD_3V3" class="0">
<segment>
<pinref part="LED2" gate="G$1" pin="POLARITY"/>
<wire x1="251.46" y1="114.3" x2="251.46" y2="127" width="0.1524" layer="91"/>
<label x="251.46" y="119.38" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="N$38" class="0">
<segment>
<pinref part="LED2" gate="G$1" pin="RED"/>
<wire x1="254" y1="114.3" x2="254" y2="116.84" width="0.1524" layer="91"/>
<wire x1="254" y1="116.84" x2="266.7" y2="116.84" width="0.1524" layer="91"/>
<pinref part="R50" gate="G$1" pin="2"/>
<wire x1="266.7" y1="116.84" x2="266.7" y2="73.66" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$39" class="0">
<segment>
<pinref part="R51" gate="G$1" pin="2"/>
<pinref part="LED2" gate="G$1" pin="GREEN"/>
<wire x1="254" y1="73.66" x2="254" y2="78.74" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$41" class="0">
<segment>
<pinref part="LED2" gate="G$1" pin="BLUE"/>
<wire x1="251.46" y1="78.74" x2="241.3" y2="78.74" width="0.1524" layer="91"/>
<pinref part="R52" gate="G$1" pin="2"/>
<wire x1="241.3" y1="78.74" x2="241.3" y2="73.66" width="0.1524" layer="91"/>
</segment>
</net>
<net name="FMU_LED_BLUE" class="0">
<segment>
<pinref part="R52" gate="G$1" pin="1"/>
<wire x1="241.3" y1="63.5" x2="241.3" y2="50.8" width="0.1524" layer="91"/>
<label x="241.3" y="40.64" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="FMU_LED_GREEN" class="0">
<segment>
<pinref part="R51" gate="G$1" pin="1"/>
<wire x1="254" y1="63.5" x2="254" y2="50.8" width="0.1524" layer="91"/>
<label x="254" y="40.64" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="FMU_LED_RED" class="0">
<segment>
<pinref part="R50" gate="G$1" pin="1"/>
<wire x1="266.7" y1="63.5" x2="266.7" y2="50.8" width="0.1524" layer="91"/>
<label x="266.7" y="40.64" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="VDD_3V3_PERIPH_EN" class="0">
<segment>
<pinref part="IC11" gate="G$1" pin="EN"/>
<wire x1="223.52" y1="-12.7" x2="198.12" y2="-12.7" width="0.1524" layer="91"/>
<pinref part="R53" gate="G$1" pin="1"/>
<wire x1="198.12" y1="-12.7" x2="180.34" y2="-12.7" width="0.1524" layer="91"/>
<wire x1="198.12" y1="-22.86" x2="198.12" y2="-12.7" width="0.1524" layer="91"/>
<junction x="198.12" y="-12.7"/>
<label x="180.34" y="-12.7" size="1.778" layer="95"/>
</segment>
</net>
<net name="VDD_3V3_PERIPH" class="0">
<segment>
<pinref part="IC11" gate="G$1" pin="OUT"/>
<wire x1="248.92" y1="-10.16" x2="254" y2="-10.16" width="0.1524" layer="91"/>
<pinref part="C44" gate="G$1" pin="+"/>
<wire x1="254" y1="-10.16" x2="269.24" y2="-10.16" width="0.1524" layer="91"/>
<wire x1="269.24" y1="-10.16" x2="276.86" y2="-10.16" width="0.1524" layer="91"/>
<wire x1="254" y1="-10.16" x2="254" y2="-27.94" width="0.1524" layer="91"/>
<junction x="254" y="-10.16"/>
<pinref part="C45" gate="G$1" pin="1"/>
<wire x1="269.24" y1="-10.16" x2="269.24" y2="-27.94" width="0.1524" layer="91"/>
<junction x="269.24" y="-10.16"/>
<wire x1="269.24" y1="-10.16" x2="269.24" y2="5.08" width="0.1524" layer="91"/>
<wire x1="269.24" y1="5.08" x2="307.34" y2="5.08" width="0.1524" layer="91"/>
<label x="294.64" y="5.08" size="1.778" layer="95"/>
<pinref part="Q2" gate="G$1" pin="S"/>
</segment>
</net>
<net name="VDD_3V3_SPEKTRUM" class="0">
<segment>
<wire x1="292.1" y1="-10.16" x2="307.34" y2="-10.16" width="0.1524" layer="91"/>
<label x="294.64" y="-10.16" size="1.778" layer="95"/>
<pinref part="Q2" gate="G$1" pin="D"/>
</segment>
</net>
<net name="SPEKTRUM_POWER" class="0">
<segment>
<wire x1="281.94" y1="-17.78" x2="281.94" y2="-20.32" width="0.1524" layer="91"/>
<wire x1="281.94" y1="-20.32" x2="307.34" y2="-20.32" width="0.1524" layer="91"/>
<label x="294.64" y="-20.32" size="1.778" layer="95"/>
<pinref part="Q2" gate="G$1" pin="G"/>
</segment>
</net>
</nets>
</sheet>
</sheets>
</schematic>
</drawing>
<compatibility>
<note version="6.3" minversion="6.2.2" severity="warning">
Since Version 6.2.2 text objects can contain more than one line,
which will not be processed correctly with this version.
</note>
<note version="8.2" severity="warning">
Since Version 8.2, EAGLE supports online libraries. The ids
of those online libraries will not be understood (or retained)
with this version.
</note>
<note version="8.3" severity="warning">
Since Version 8.3, EAGLE supports URNs for individual library
assets (packages, symbols, and devices). The URNs of those assets
will not be understood (or retained) with this version.
</note>
<note version="8.3" severity="warning">
Since Version 8.3, EAGLE supports the association of 3D packages
with devices in libraries, schematics, and board files. Those 3D
packages will not be understood (or retained) with this version.
</note>
</compatibility>
</eagle>
